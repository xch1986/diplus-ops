<?php
$p='/data/adb/modules/diplus-keepalive/diplus-daemon.sh';
$s=file_get_contents($p);
$s=str_replace('diplus-daemon v5.1 - Magisk daemon','diplus-daemon v5.3 - Magisk daemon',$s);
$s=str_replace('=== diplus-daemon v5.1 start','=== diplus-daemon v5.3 start',$s);
// fuse 段: 加开机宽限
$old_fuse='  # ===== 内部存储 fuse 自愈 v2 (2026-10-01): SELinux放行+重挂+bind视图, 带冷却 =====
  if ! ls /storage/emulated/0/vandiplus/ >/dev/null 2>&1; then';
$new_fuse='  # ===== 内部存储 fuse 自愈 v3 (2026-10-02): 开机宽限+SELinux放行+重挂+bind+冷却 =====
  UP=$(cut -d. -f1 /proc/uptime 2>/dev/null)
  if [ "${UP:-0}" -lt 240 ]; then
    : # 开机宽限期: 不碰存储, 避免干扰系统启动导致中控黑屏
  elif ! ls /storage/emulated/0/vandiplus/ >/dev/null 2>&1; then';
if(strpos($s,$old_fuse)!==false){ $s=str_replace($old_fuse,$new_fuse,$s); echo "FUSE_V3 OK
"; } else { echo "FUSE_V3 NOTFOUND
"; }
// setenforce 后加确认日志
$old_se='        setenforce 0 2>/dev/null
      fi
      sm unmount emulated 2>/dev/null; sleep 2; sm mount emulated 2>/dev/null';
$new_se='        setenforce 0 2>/dev/null
        echo "$(date) SELinux状态: $(getenforce 2>/dev/null)" >> $LOG
      fi
      sm unmount emulated 2>/dev/null; sleep 2; sm mount emulated 2>/dev/null';
if(strpos($s,$old_se)!==false){ $s=str_replace($old_se,$new_se,$s); echo "SELOG OK
"; } else { echo "SELOG NOTFOUND
"; }
// SD 段: 去掉 vold 重启
$old_vold='      # 2) 可移动块设备在但未挂载: 重启 vold
      REMOV=$(ls /sys/block/ 2>/dev/null | while read b; do r=$(cat /sys/block/$b/removable 2>/dev/null); [ "$r" = "1" ] && echo yes && break; done)
      if [ "$REMOV" = "yes" ]; then
        echo "$(date) SD可移动设备在, 重启vold重扫" >> $LOG
        stop vold; sleep 1; start vold
        sleep 5
      else';
$new_vold='      # 2) 可移动块设备在但未挂载: 不重启vold(会打断内部存储+可致中控黑屏), 只USB重扫
      REMOV=$(ls /sys/block/ 2>/dev/null | while read b; do r=$(cat /sys/block/$b/removable 2>/dev/null); [ "$r" = "1" ] && echo yes && break; done)
      if [ "$REMOV" = "yes" ]; then
        echo "$(date) SD可移动设备在但未挂载, 触发USB重扫(不重启vold)" >> $LOG
        for h in /sys/class/scsi_host/host*; do echo "- - -" > $h/scan 2>/dev/null; done
        sleep 5
      else';
if(strpos($s,$old_vold)!==false){ $s=str_replace($old_vold,$new_vold,$s); echo "SD_NOVOLD OK
"; } else { echo "SD_NOVOLD NOTFOUND
"; }
// SD 段: 加300s冷却
$old_sd='  # ---- SD 检查(85D5-14FD 记录仪USB存储 / AlarmVideo 任一) ----
  SDOK=""
  [ -d /storage/85D5-14FD ] && SDOK=1
  if [ -z "$SDOK" ]; then
    echo "$(date) SD未挂载, 尝试恢复" >> $LOG';
$new_sd='  # ---- SD 检查(85D5-14FD 记录仪USB存储), 带300s冷却 ----
  SDOK=""
  [ -d /storage/85D5-14FD ] && SDOK=1
  if [ -z "$SDOK" ]; then
    SLAST=/data/local/tmp/.sd_last
    NOW=$(date +%s)
    if [ -f $SLAST ] && [ $(( NOW - $(cat $SLAST) )) -lt 300 ]; then
      SDOK="cd"
    else
      date +%s > $SLAST
    fi
  fi
  if [ -z "$SDOK" ]; then
    echo "$(date) SD未挂载, 尝试恢复" >> $LOG';
if(strpos($s,$old_sd)!==false){ $s=str_replace($old_sd,$new_sd,$s); echo "SD_COOLDOWN OK
"; } else { echo "SD_COOLDOWN NOTFOUND
"; }
file_put_contents($p,$s);
echo "SAVED
";
