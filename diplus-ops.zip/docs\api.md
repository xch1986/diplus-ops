# Web API 清单

> 全部 API 位于 `www/api/`，经 nginx(8018) 提供。未授权接口需登录态（`users/login.php` 下发 cookie）。

## 告警推送

| 接口 | 说明 |
|---|---|
| `alarm_poll.php?mins=3` | 告警轮询（crontab 每分钟调用），命中阈值推送钉钉/企业微信 |
| `alarm.php` | 告警事件查询/触发处理 |

## 哨兵视频

| 接口 | 说明 |
|---|---|
| `get_video_list_all.php` | 视频列表（按日期/类型/事件筛选） |
| `get_video_dates.php` | 有视频的日期列表 |
| `get_video_info.php` | 单视频信息 |
| `get_video_file.php` | 视频文件下载/播放 |
| `video_stream_file.php` / `video_stream_api.php` | 视频流 |
| `get_recorder_snapshot.php` | 记录仪快照 |
| `get_next_video_data.php` | 下一个视频数据（轮播） |
| `delete_file.php` | 删除文件 |
| `clean_files.php` | 批量清理文件 |

## 行驶数据

| 接口 | 说明 |
|---|---|
| `save_driving_data.php` | 写入行驶数据 |
| `sum_tripList.php` | 行程列表 |
| `sum_tripInfo.php` | 行程详情 |
| `sum_monthlyTrip.php` | 月里程汇总 |
| `sum_trend_day.php` / `sum_trend_year.php` | 日/年趋势 |
| `sum_elecCharging.php` | 充电统计 |
| `sum_tracking.php` | 轨迹 |
| `sum_set_price.php` | 价格设置 |

## 设置

| 接口 | 说明 |
|---|---|
| `settings_general.php` | 通用设置（阈值、账号、推送开关） |
| `settings_msg.php` | 推送消息模板 |
| `settings_tracking.php` | 轨迹设置 |
| `settings_maint.php` | 维护提醒 |
| `settings_diparams.php` | 迪加参数 |
| `settings_cmd.php` | 命令下发 |
| `settings_update.php` | 设置更新 |
| `set_diplus_config.php?config=xiaodi\|trigger` | 回写迪加配置文件（inotify 监听触发） |

## 系统/工具

| 接口 | 说明 |
|---|---|
| `frp.php` / `sakurafrp.php` / `easytier.php` | 隧道状态/切换 |
| `openlist.php` / `ol_start.php` | OpenList 控制 |
| `rdweb.php` | 远程桌面 |
| `send_cmd.php` / `send_msg.php` | 命令/消息下发 |
| `broadcast.php` | 广播 |
| `get_params.php` | 参数读取 |
| `index.php` | API 索引 |
| `maint_reminder.php` | 保养提醒 |

## 用户

| 接口 | 说明 |
|---|---|
| `users/login.php` | 登录（口令校验 → cookie） |
| `users/logout.php` | 登出 |

## 数据库（SQLite `db/db.db`）

- `config`（key/value）：全局配置、推送模板（`trigger_alarm_shake`/`trigger_alarm_vibrate` 等，占位符 `{motionGyro}`/`{motionG}`）
- 业务表：行程/充电/趋势/告警记录等，由对应 API 自动建表
