<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '获取行程数据失败！未登录系统。';
    returnJson($ajson);
}
$date = $_GET["date"] ?? date('Y-m-d');
$dateFrom = $_GET["dateFrom"] ?? '';
$dateTo = $_GET["dateTo"] ?? '';

$dbPath = '/storage/emulated/0/vandiplus/db/van_bm_db';
$conn = db_conn($err, $dbPath);
if (!$conn) {
    $ajson['message'] = "打开数据库失败！$err";
    returnJson($ajson);
}

$p = [];
$aWhere = [ 'mileage_end > mileage_start' ];
if (!$dateFrom || !$dateTo) {
    $aWhere[] = "date(time_end / 1000, 'unixepoch', 'localtime') = :date";
    $p[':date'] = $date;
} else {
    $aWhere[] = "date(time_end / 1000, 'unixepoch', 'localtime') BETWEEN :dateFrom AND :dateTo";
    $p[':dateFrom'] = $dateFrom;
    $p[':dateTo'] = $dateTo;
}
$strWhere = implode(' AND ', $aWhere);
// DISTINCT 单个字段只适用于sqlite, 不适用于mysql
$sql = "SELECT SUM(mileage_end - mileage_start) / 10.0 AS mileage,
    (MAX(mileage_end) - MIN(mileage_start)) / 10.0 AS totalMileage,
    SUM(evMileage_end - evMileage_start) / 10.0 AS evMileage,
    (MAX(evMileage_end) - MIN(evMileage_start)) / 10.0 AS totalEvMileage,
    SUM(travelTime) AS travelTime,
    ROUND(SUM(mileage_end - mileage_start) / SUM(travelTime) * 360, 2) AS avgSpeed,
    COUNT(time_end) AS travelCnt,
    COUNT(DISTINCT date(time_end / 1000, 'unixepoch', 'localtime')) AS travelDays,
    SUM(mileage_end - mileage_start) / COUNT(time_end) / 10.0 AS avgMileage,
    ROUND(SUM(travelTime) / COUNT(time_end)) AS avgTime,
    ROUND(SUM(elecCon_end - elecCon_start), 2) AS elecCon,
    ROUND((MAX(elecCon_end) - MIN(elecCon_start)) * 10) / 10 AS totalElecCon,
    ROUND(SUM(fuelCon_end - fuelCon_start), 2) AS fuelCon,
    ROUND((MAX(fuelCon_end) - MIN(fuelCon_start)) * 10) / 10 AS totalFuelCon
    FROM TripInfo
    WHERE $strWhere
";
$data = db_query_row($conn, $sql, $p);
$ajson['data'] = $data;


$p = [];
$aWhere = [ 'power > prePower' ];
if (!$dateFrom || !$dateTo) {
    $aWhere[] = "date(time / 1000, 'unixepoch', 'localtime') = :date";
    $p[':date'] = $date;
} else {
    $aWhere[] = "date(time / 1000, 'unixepoch', 'localtime') BETWEEN :dateFrom AND :dateTo";
    $p[':dateFrom'] = $dateFrom;
    $p[':dateTo'] = $dateTo;
}
$strWhere = implode(' AND ', $aWhere);
$sql = "SELECT ROUND((MAX(`power`) - MIN(prePower)) * 10) / 10 AS totalElecCharged,
    COUNT(*) AS elecChargeCnt
    FROM ChargingLog
    WHERE $strWhere
";
$data = db_query_row($conn, $sql, $p);
if ($data) {
    $ajson['data'] = array_merge($ajson['data'], $data);
}

$conn0 = db_conn();
$ajson['data']['fuel_price'] = (float) readSettings($conn0, 'global', 'fuel_price');
$ajson['data']['elec_price'] = (float) readSettings($conn0, 'global', 'elec_price');

$ajson['success'] = 1;
$ajson['message'] = '行程数据获取成功！';
returnJson($ajson);
?>