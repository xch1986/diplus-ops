<?php
require_once '../includes/phpshare.php';

// $login = login();

// 禁用所有输出缓冲并清理缓冲区
while (ob_get_level()) ob_end_clean();

$key = $_GET['key'] ?? '';
$key = str_replace(' ', '+', $key); // php会把base64中的+解码成空格，这里替换回来
$filePath = base64_decode($key);
// php-fpm 无法 stat sdcard 视频文件(权限), is_file 会误报 404;
// 改为纯字符串前缀校验, 文件存在性由 nginx(root) X-Accel-Redirect 处理
if (strpos($filePath, '/storage/') !== 0) {
    header('HTTP/1.1 404 Not Found');
    exit;
}

// 由 nginx(root) 直接发送文件, 支持 Range/206, 解决 USB 视频 php-fpm 无读权限问题
$download = isset($_GET['download']);
if ($download) {
    $fname = basename($filePath);
    header('Content-Disposition: attachment; filename="' . str_replace('"', '', $fname) . '"');
}
header('Content-Type: video/mp4');
header('X-Accel-Redirect: /internal-video/' . substr($filePath, strlen('/storage/')));
exit;
?>