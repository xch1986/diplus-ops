<script setup>
import echarts from '/includes/vue-components/echarts.vue';

const route = VueRouter.useRoute();
const date = Vue.ref(new Date(route.query.date ?? new Date().Format('YYYY-01-01')));
const data = Vue.ref({});
const isMobile = Vue.ref(window.innerWidth < 550);

const getElecChargingData = async () => {
    const res = await axios({
        url: 'api/sum_elecCharging.php',
        method: 'get',
        params: {
            dateFrom: date.value.Format('YYYY-01-01'),
            dateTo: date.value.Format('YYYY-12-31')
        }
    });
    data.value = res.data.data;
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }   
}
getElecChargingData();

const sumData = Vue.computed(() => {
    let sum = {
        elecCharged: 0,
        elecCost: 0,
        mileage: 0,
        elecChargedPer100: 0
    };
    if (!data.value.elecChargingData?.length) return sum;
    for (const row of data.value.elecChargingData) {
        sum.elecCharged += row.elecCharged;
        sum.mileage += row.mileage;
    }
    sum.elecCost = Math.round(sum.elecCharged * data.value.elec_price);
    sum.elecChargedPer100 = Math.round(sum.elecCharged / sum.mileage * 1000) / 10;
    return sum;
});

const setYear = (val) => {
    if (val === 0) {
        date.value = new Date();
    } else {
        // 直接setFullYear修改不会触发watch，这里转一下再赋值
        const d = new Date(date.value.toDateString());
        d.setFullYear(d.getFullYear() + val);
        date.value = d;
    }
}

Vue.watch(() => date.value, () => {
    getElecChargingData();
    selectedData.value = null;
});

const chart_option = Vue.computed(() => {
	if (!data.value.elecChargingData) return {};
    for (let row of data.value.elecChargingData) {
        row.cost = Math.round(row.elecCharged * data.value.elec_price * 100) / 100;
        row.elecChargedPer100 = Math.round(row.elecCharged / row.mileage * 1000) / 10;
    }
	const min = date.value.Format('YYYY-01-01');
    const max = date.value.Format('YYYY-12-01');

    return {
		legend: {},
		grid: {
			left: '0',
			right: '0',
			containLabel: true
		},
		tooltip : {
            trigger: 'item',
            formatter: (params) => {
                let tips = `${new Date(params.value.mon).Format('YYYY年MM月')}<br/>`;
                tips += `充电度数: ${params.value.elecCharged}<br/>`;
                tips += `充电费用: ${params.value.cost}<br/>`;
                tips += `耗电度数: ${params.value.elecCon}<br/>`;
                tips += `百公里充电: ${params.value.elecChargedPer100}`;
                return tips;
            }
        },
		dataset: {
            source: data.value.elecChargingData,
            dimensions: [
                { name: 'mon', type: 'time' },
                'elecCharged',
                'cost',
                'elecCon',
                'elecChargedPer100',
                'batteryCapc'
            ]
		},
        xAxis: {
            type: 'time',
            min: min,
            max: max,
            axisLabel: {
                formatter: '{MM}月',
                interval: 0
            },
            axisPointer: {
                label: {
                    formatter: function(params) {
                        return params.value;
                    }
                }
            }
        },
		yAxis: [
			{
				type: 'value',
			},
			{
				type: 'value',
                splitLine: {
                    show: false
                }
			}
		],
		series: [
            {
                name: '充电度数',
                type: 'bar',
                barMaxWidth: 10,
                encode: { x: 'mon', y: 'elecCharged' },
            },
            {
                name: '充电费用',
                type: 'line',
                yAxisIndex: 1,
                encode: { x: 'mon', y: 'cost' },
            },
            {
                name: '耗电度数',
                type: 'bar',
                barMaxWidth: 10,
                encode: { x: 'mon', y: 'elecCon' },
            },
            {
                name: '百公里充电',
                type: 'line',
                yAxisIndex: 1,
                encode: { x: 'mon', y: 'elecChargedPer100' },
            },
            {
                name: '估算电池容量',
                type: 'line',
                yAxisIndex: 1,
                encode: { x: 'mon', y: 'batteryCapc' },
            }
		]
	};
});

const selectedData = Vue.ref();
const onClickChart = async (params) => {
    selectedData.value = params.data;
}
const showMonthlyTrip = (row) => {
    router.push({
        path: '/monthlyTrip',
        query: {
            date: row.mon,
        }
    });
}
</script>

<template>
    <div class="tab-head">
        <el-space size="large" class="tab-head-left">
            <div class="tab-head-title">充电统计</div>
        </el-space>
        <el-space size="large">
            <el-button type="primary" plain @click="setYear(-1)"><</el-button>
            <el-date-picker v-model="date" type="year" :editable="false" style="width: 120px" format="YYYY年"/>
            <el-button type="primary" plain @click="setYear(1)">></el-button>
        </el-space>
    </div>
    <Teleport to=".tab-head-left" :disabled="isMobile">
        <el-space :style="isMobile ? 'margin-bottom: 20px' : ''">
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.elecCharged }}
                </el-text> <el-text>度</el-text>
            </div>
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.elecCost }}
                </el-text> <el-text>元</el-text>
            </div>
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.mileage }}
                </el-text> <el-text>公里</el-text>
            </div>
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.elecChargedPer100 }}
                </el-text> <el-text>度/百公里</el-text>
            </div>
        </el-space>
    </Teleport>

	<div class="slide" style="margin-bottom: 10px">
		<echarts :option="chart_option" :on="{ event: 'click', callback: onClickChart }"/>
	</div>


    <el-card v-if="selectedData" body-class="el-card-body-class">
        <template #header>
            <div class="flex-space-between">
                <div>{{ new Date(selectedData.mon).Format('YYYY年MM月') }}</div>
                <el-button type="primary" text @click="showMonthlyTrip(selectedData)">
                    详情
                </el-button>
            </div>
        </template>
        <div class="flex-flex-start" style="gap: 20px">
            <el-statistic title="充电次数" :value="selectedData.elecChargeCnt"/>
            <el-statistic title="充电度数" :value="selectedData.elecCharged"/>
            <el-statistic title="充电费用" :value="selectedData.elecCharged * data.elec_price" :precision="2"/>
            <el-statistic title="耗电度数" :value="selectedData.elecCon" :precision="1"/>
            <el-statistic title="行驶里程" :value="selectedData.mileage" :precision="1"/>
            <el-statistic title="百公里充电度数" :value="selectedData.elecCharged / selectedData.mileage * 100" :precision="1"/>
            <el-statistic title="百公里充电费用" :value="selectedData.elecCharged * data.elec_price / selectedData.mileage * 100" :precision="2"/>
        </div>
    </el-card>
</template>

<style>
@media screen and (max-width: 600px) {
    .el-card-body-class {
        padding-left: 10px;
        padding-right: 10px;
    }
}
</style>
<style scoped>
.echarts {
    height: 600px !important;
}
@media screen and (max-height: 800px) {
    .echarts {
        height: 400px !important;
    }
}
</style>