<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'formData' => [], 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}
$action = @$_GET['action'] ?? '';
if (!$action) {
    $ajson['message'] = '缺少参数';
    returnJson($ajson);
}

// 添加环境变量，否则command -v xxx 等命令不能返回正确结果
putenv('PATH=/data/data/com.termux/files/usr/bin:' . getenv('PATH'));
$home = $_ENV['HOME'];

$conn = db_conn();

$post = json_decode_x(file_get_contents('php://input'));
if ($action == 'saveData' && $post) {
    writeSettings($conn, 'easytier', 'easytierOn', $post['easytierOn'] ?: 0);
    writeSettings($conn, 'easytier', 'et_hostname', $post['et_hostname']);
    writeSettings($conn, 'easytier', 'et_ipv4', $post['et_ipv4']);
    writeSettings($conn, 'easytier', 'et_network_name', $post['et_network_name']);
    writeSettings($conn, 'easytier', 'et_network_secret', $post['et_network_secret']);
    $et_pear = implode(';', $post['et_peer']);
    writeSettings($conn, 'easytier', 'et_peer', $et_pear);
    writeSettings($conn, 'easytier', 'et_params', $post['et_params']);

    $ajson['message'] = '数据保存成功！';
    $ajson['success'] = 1;
    returnJson($ajson);
}

if ($action == 'getStatusData' || $action == 'getData') {
    $file_path = "$home/easytier/easytier-core";
    $ajson['data']['et_installed'] = false;
    $ajson['data']['et_version'] = '0';
    if (file_exists($file_path)) {
        $ajson['data']['et_installed'] = true;
        exec("$file_path --version", $output);
        if ($output) {
            $arr = explode(' ', end($output));
            $ajson['data']['et_version'] = end($arr);
        }
    }
    unset($output);

    exec('pgrep -f easytier-core', $output);
    $ajson['data']['et_is_running'] = count($output) > 1;
    $ajson['data']['net_peers'] = $ajson['data']['et_is_running'] ? getEasytierPeers() : [];
    $ajson['success'] = 1;
    if ($action == 'getStatusData') {
        returnJson($ajson);
    }
}

if ($action == 'getData') {
    $returnData = [];
    $returnData['easytierOn'] = readSettings($conn, 'easytier', 'easytierOn') == 1;
    $returnData['et_hostname'] = readSettings($conn, 'easytier', 'et_hostname');
    $returnData['et_ipv4'] = readSettings($conn, 'easytier', 'et_ipv4');
    $returnData['et_network_name'] = readSettings($conn, 'easytier', 'et_network_name');
    $returnData['et_network_secret'] = readSettings($conn, 'easytier', 'et_network_secret');
    $returnData['et_peer'] = explode(';', readSettings($conn, 'easytier', 'et_peer'));
    $returnData['et_params'] = readSettings($conn, 'easytier', 'et_params');
    $ajson['formData'] = $returnData;
    $ajson['success'] = 1;
    returnJson($ajson);
}


if ($action == 'stop' || $action == 'restart') {
    exec('pgrep -f easytier-core', $output);
    if ($output && count($output) > 1) {
        unset($output);
        exec('pkill -f easytier-core', $output);
        if ($output) {
            $ajson['message'] = "停止 easytier 进程时发生错误。".implode("\n", $output);
            returnJson($ajson);
        }
    }
    $ajson['data']['et_is_running'] = false;
    $ajson['data']['net_peers'] = $ajson['data']['et_is_running'] ? getEasytierPeers() : [];
    if ($action == 'stop') {
        $ajson['message'] = "easytier 已停止运行";
        $ajson['success'] = 1;
        returnJson($ajson);
    }
}

if ($action == 'start' || $action == 'restart') {
    $file_path = "$home/easytier/easytier-core";
    $script_path = "$home/boot/easytier.sh";
    if (!file_exists($file_path)) {
        $ajson['message'] = "easytier 启动失败，程序未安装";
        $ajson['data']['et_is_running'] = false;
        returnJson($ajson);
    }
    exec("bash $script_path", $output, $return_var);
    if ($return_var !== 0) {
        $ajson['message'] = "启动 easytier 时发生错误";
        $ajson['data']['et_is_running'] = false;
        returnJson($ajson);
    }

    unset($output);
    exec('pgrep -f easytier-core', $output);
    if (!$output || count($output) < 2) {
        $ajson['message'] = "easytier 启动失败";
        $ajson['data']['et_is_running'] = false;
        returnJson($ajson);
    }

    $ajson['data']['et_is_running'] = true;
    $ajson['data']['net_peers'] = $ajson['data']['et_is_running'] ? getEasytierPeers() : [];
    $ajson['message'] = "easytier 启动成功";
    $ajson['success'] = 1;
    returnJson($ajson);
}

$ajson['message'] = "执行成功";
$ajson['success'] = 1;
returnJson($ajson);


function getEasytierPeers() {
    $home = "/data/data/com.termux/files/home";
    $cmd = "$home/easytier/easytier-cli peer";
    exec($cmd, $output);
    if (!$output || count($output) < 3) return [];

    $pattern = "/\s*\│\s*/";
    $arr = preg_split($pattern, $output[1]);
    if (count($arr) < 9) return [];
    $header = [];
    foreach ($arr as $index => $item) {
        if ($item) {
            $header[$item] = $index;
        }
    }

    $peers = [];
    for ($i = 3; $i < count($output); $i ++) {
        $arr = preg_split($pattern, $output[$i]);
        if (count($arr) < 9) continue;
        $peers[] = [
            'ipv4' => $arr[$header['ipv4']] ?? '',
            'hostname' => $arr[$header['hostname']] ?? '',
            'cost' => $arr[$header['cost']] ?? '',
            'lat_ms' => is_numeric(@$arr[$header['lat_ms']]) ? round($arr[$header['lat_ms']]) : @$arr[$header['lat_ms']],
            'loss_rate' => is_numeric(@$arr[$header['loss_rate']]) ? round($arr[$header['loss_rate']], 1) : @$arr[$header['loss_rate']],
            'rx_bytes' => $arr[$header['rx_bytes']] ?? '',
            'tx_bytes' => $arr[$header['tx_bytes']] ?? '',
            'tunnel_proto' => $arr[$header['tunnel_proto']] ?? '',
            'nat_type' => $arr[$header['nat_type']] ?? '',
            'version' => $arr[$header['version']] ?? ''
        ];
    }
    return $peers;
}
?>