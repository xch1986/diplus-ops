#!/data/data/com.termux/files/usr/bin/bash
# frpc.sh v5 - 双视角pidof + 锁文件(新鲜度600s且PID存活)防重
export PATH=/data/data/com.termux/files/usr/bin:$PATH
export HOME=/data/data/com.termux/files/home
export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib
LOCK=$HOME/frp/frpc.pid

if [ -n "$(su -c 'pidof frpc' 2>/dev/null)" ]; then
  exit 0
fi
if [ -f "$LOCK" ]; then
  OLD=$(date -r "$LOCK" +%s 2>/dev/null)
  NOW=$(date +%s)
  LOCKPID=$(cat "$LOCK" 2>/dev/null)
  # 锁新鲜 且 锁内PID存活 -> 已有frpc在跑，跳过
  if [ -n "$OLD" ] && [ -n "$LOCKPID" ] && [ $(( NOW - OLD )) -lt 600 ] && kill -0 "$LOCKPID" 2>/dev/null; then
    exit 0
  fi
  # 锁过期或PID已死 -> 删旧锁，允许重新拉起
  rm -f "$LOCK"
fi
appOn=$(su -c "sqlite3 $HOME/db/db.db \"select value from config where key='appOn'\"" 2>/dev/null)
if [ -n "$appOn" ] && [ "$appOn" != "1" ]; then
  exit 0
fi
nohup frpc -c $HOME/frp/frpc.toml >> $HOME/frp/frpc.log 2>&1 &
echo $! > $LOCK