#!/system/bin/sh
# start_daemon - crontab 保活入口 (2026-09-30 v2): PID文件+进程名校验, 防重启后PID复用误判
LOCK=/data/local/tmp/diplus-daemon.pid
DP=$(cat $LOCK 2>/dev/null)
if [ -n "$DP" ] && grep -q diplus-daemon /proc/$DP/cmdline 2>/dev/null; then
  exit 0
fi
rm -f $LOCK
export PATH=/data/data/com.termux/files/usr/bin:$PATH
export HOME=/data/data/com.termux/files/home
export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib
setsid /system/bin/sh -c 'export PATH=/data/data/com.termux/files/usr/bin:$PATH; export HOME=/data/data/com.termux/files/home; export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib; nohup bash /data/adb/modules/diplus-keepalive/diplus-daemon.sh >> /data/data/com.termux/files/home/daemon.log 2>&1 &'
