<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once __DIR__.'/../includes/phpshare.php';
require_once __DIR__.'/../includes/db.php';
require_once __DIR__.'/../includes/diplus_config.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];

$conn = db_conn();
$DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
$config = $_GET['config'] ?? getArgs('config');


// 小迪扩展
if (!$config || $config == 'xiaodi') {
    $save_param_interval = readSettings($conn, 'diplus', 'save_param_interval') ?: 5;
    $res = setXDSaveDrivingData($save_param_interval, $DIPLUS_AUTH);
    if ($res) {
        $ajson['message'] .= '小迪扩展保存车况数据设置成功！';
    } else {
        $ajson['message'] .= '小迪扩展保存车况数据设置失败！';
    }
}


// 迪加自动化
if (!$config || $config == 'trigger') {

    // 监听车况数据
    $diplus_params = json_decode_x(readSettings($conn, 'diplus', 'diplus_params'));
    $res = setTriggerSaveParams($diplus_params, $DIPLUS_AUTH);
    if ($res) {
        $ajson['message'] .= '监听车况数据自动化设置成功！';
    } else {
        $ajson['message'] .= '监听车况数据自动化设置失败！';
    }

    // 行驶轨迹记录
    $trigger_for_tracking = readSettings($conn, 'diplus', 'trigger_for_tracking') == 1;
    if ($trigger_for_tracking) {
        $res = setTriggerTracking($DIPLUS_AUTH);
        if ($res) {
            $ajson['message'] .= '行驶轨迹自动化设置成功！';
        } else {
            $ajson['message'] .= '行驶轨迹自动化设置失败！';
        }
    }

    // 有人靠近报警
    $trigger_alarm_person = readSettings($conn, 'diplus', 'trigger_alarm_person');
    if ($trigger_alarm_person == 1) { // 2.8.1版以前数据
        $trigger_alarm_person = [
            'enable' => true,
            'reliability' => 30,
            'min' => 10000,
            'text' => '有人靠近车辆(可信度{AI识别人可信度})'
        ];
    } else {
        $trigger_alarm_person = json_decode_x($trigger_alarm_person);
    }
    if ($trigger_alarm_person && @$trigger_alarm_person['enable']) {
        $res = setTriggerAlarmPerson($trigger_alarm_person, $DIPLUS_AUTH);
        if ($res) {
            $ajson['message'] .= '有人靠近报警自动化设置成功！';
        } else {
            $ajson['message'] .= '有人靠近报警自动化设置失败！';
        }
    }

    // 有车经过报警
    $trigger_alarm_car = readSettings($conn, 'diplus', 'trigger_alarm_car');
    if ($trigger_alarm_car == 1) { // 2.8.1版以前数据
        $trigger_alarm_car = [
            'enable' => true,
            'reliability' => 30,
            'min' => 10000,
            'text' => '有车经过(可信度{AI识别车可信度})'
        ];
    } else {
        $trigger_alarm_car = json_decode_x($trigger_alarm_car);
    }
    if ($trigger_alarm_car && @$trigger_alarm_car['enable']) {
        $res = setTriggerAlarmCar($trigger_alarm_car, $DIPLUS_AUTH);
        if ($res) {
            $ajson['message'] .= '有车经过报警自动化设置成功！';
        } else {
            $ajson['message'] .= '有车经过报警自动化设置失败！';
        }
    }
}


$ajson['message'] = $ajson['message'] ?: '没有需要设置的迪加配置！';
$ajson['success'] = 1;
returnJson($ajson);

// 获取命令行参数
function getArgs($argName) {
    if (!$_SERVER['argv']) {
        return $argName ? '' : [];
    }
    $args = [];
    foreach ($_SERVER['argv'] as $index => $arg) {
        if ($index > 0 && strpos($arg, '=') > 0) {
            $arr = explode('=', $arg, 2);
            $args[$arr[0]] = $arr[1];
        }
    }
    return $argName ? $args[$argName] ?? '' : $args;
}
?>