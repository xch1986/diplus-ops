#!/bin/bash
home="/data/data/com.termux/files/home"
SCRIPT_NAME=$(basename "$0")


# 监听迪加小迪扩展配置文件，当检测到被(迪加小程序)修改时，将配置重新写入
XIAODI_FILE="/storage/emulated/0/vandiplus/config/xiaodi.conf"
if pgrep -f "inotifywait -m -e modify $XIAODI_FILE" > /dev/null; then
    echo "inotifywait 正在监听 $XIAODI_FILE。 "
else
    nohup inotifywait -m -e modify $XIAODI_FILE | while read -r event; do
        php "$home/www/api/set_diplus_config.php" config=xiaodi

        # 清空PHP自身修改配置文件触发的事件，否则会无限死循环!!!
        while read -r -t 0.1 _; do :; done
    done > /dev/null 2>&1 &
fi


# 监听迪加自动化配置文件，当检测到被(迪加小程序)修改时，将配置重新写入
TRIGGER_FILE="/storage/emulated/0/vandiplus/config/trigger.conf"
if pgrep -f "inotifywait -m -e modify $TRIGGER_FILE" > /dev/null; then
    echo "inotifywait 正在监听 $TRIGGER_FILE。 "
else
    nohup inotifywait -m -e modify $TRIGGER_FILE | while read -r event; do
        php "$home/www/api/set_diplus_config.php" config=trigger

        # 清空PHP自身修改配置文件触发的事件，否则会无限死循环!!!
        while read -r -t 0.1 _; do :; done
    done > /dev/null 2>&1 &
fi

