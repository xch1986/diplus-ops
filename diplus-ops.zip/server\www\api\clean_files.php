<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once __DIR__.'/../includes/phpshare.php';
require_once __DIR__.'/../includes/db.php';
// phph直接运行此脚本必须设置时区
date_default_timezone_set('Asia/Shanghai');

$ajson = [ 'success' => 0, 'message' => '' ];

$conn = db_conn();

// 移动迪加哨兵/记录仪视频到SD卡
$move_files_to_sd = readSettings($conn, 'global', 'move_files_to_sd') == 1;
if ($move_files_to_sd) {
    $srcDir = '/storage/emulated/0/AlarmVideo';
    $desDir = '/storage/sdcard/Recorder/Normal';

    $ret = moveFiles("$srcDir/R", "$desDir/R");
    if ($ret !== true) {
        $ajson['message'] .= "移动迪加记录仪视频失败！$ret";
    } else {
        $ajson['message'] .= "迪加记录仪视频移动成功！";
        $ajson['success'] += 1;
    }

    $ret = moveFiles("$srcDir/A", "$desDir/A");
    if ($ret !== true) {
        $ajson['message'] .= "移动迪加哨兵视频失败！$ret";
    } else {
        $ajson['message'] .= "迪加哨兵视频移动成功！";
        $ajson['success'] += 1;
    }
}

// 清理迪加录屏视频
$days_clean_screen_record = (int)readSettings($conn, 'global', 'days_clean_screen_record');
if ($days_clean_screen_record > 0) {
    $dateStr = date('Ymd', strtotime("-$days_clean_screen_record days"));
    $sDir = '/storage/emulated/0/AlarmVideo/S';
    $files = scandir($sDir);
    foreach ($files as $file) {
        $path = "$sDir/$file";
        if ($file == '.' || $file == '..' || !is_dir($path) || !preg_match('/^\d{8}$/', $file)) {
            continue;
        }
        
        if ($file < $dateStr) {
            $cmd = "rm -rf " . escapeshellarg($path);
            $output = shell_exec($cmd);
            if ($output === null) {
                $ajson['message'] .= "{$path}已删除。";
                $ajson['success'] += 1;
            } else {
                $ajson['message'] .= "{$path}删除失败{$output}。";
            }
        }
    }
}

returnJson($ajson);


function moveFiles($srcDir, $desDir) {
    if (!file_exists($desDir)) {
        mkdir($desDir, 0777, true);
    }
    $cmd = "cp -R -f -v $srcDir/. $desDir/";  
    exec($cmd, $output, $return_var);
    if ($return_var !== 0) {
        return "复制文件失败！" . implode(" ", $output);
    }
    exec("rm -rf $srcDir/*");
    return true;
}
?>
