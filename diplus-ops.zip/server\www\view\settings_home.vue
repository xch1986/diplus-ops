<script setup>
function onIframeLoad(e) {
    try {
        var doc = e.target.contentDocument;
        if (!doc || !doc.head) return;
        var st = doc.createElement('style');
        // 隐藏首页自带的那列菜单(外壳已有外层菜单), 内容拉满
        st.textContent = '#app > .el-menu{display:none !important;} body{max-width:100% !important; padding:0 !important;} .main{max-width:100% !important; padding:0 !important; margin:0 !important;} .router-page{padding:0 !important; border:none !important;}';
        doc.head.appendChild(st);
    } catch (err) {}
}
</script>

<template>
    <iframe src="/" width="100%" style="border: none" class="page-iframe home-iframe" @load="onIframeLoad"></iframe>
</template>

<style scoped>
.home-iframe {
    width: 100%;
    height: calc(100vh - 76px);
}
@media (max-width: 767px) {
    .home-iframe {
        height: 100vh;
    }
}
</style>
