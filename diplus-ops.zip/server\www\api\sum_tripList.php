<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '获取行程数据失败！未登录系统。';
    returnJson($ajson);
}

// 获取电价油价
$conn = db_conn();
$fuel_price = (float) readSettings($conn, 'global', 'fuel_price');
$elec_price = (float) readSettings($conn, 'global', 'elec_price');
$conn = null;

// 从迪加数据库获取行程
$date = $_GET["date"] ?? date('Y-m-d');
$dbPath = '/storage/emulated/0/vandiplus/db/van_bm_db';
$conn = db_conn($err, $dbPath);
if (!$conn) {
    $ajson['message'] = "打开数据库失败！$err";
    returnJson($ajson);      
}

$p = [];
$aWhere = [
    'mileage_end > mileage_start',
    "date(time_end / 1000, 'unixepoch', 'localtime') = :date"
];
$p[':date'] = $date;
$strWhere = implode(' AND ', $aWhere);
$sql = "SELECT time_start,
    time_end,
    travelTime,
    (mileage_end - mileage_start) / 10.0 AS mileage,
    ROUND(elecCon_end - elecCon_start, 2) AS elecCon,
    ROUND(fuelCon_end - fuelCon_start, 2) AS fuelCon
    FROM TripInfo
    WHERE $strWhere
";
$data = db_query_all($conn, $sql, $p);
foreach ($data as &$row) {
    $row['elecCost'] = round($row['elecCon'] * $elec_price, 2);
    $row['fuelCost'] = round($row['fuelCon'] * $fuel_price, 2);
}
unset($row);
$ajson['data']['tripList'] = $data;


$dbPath = '/storage/emulated/0/Termux/db.db';
$conn1 = db_conn($err, $dbPath);

// 获取起点终点坐标/最高速度等
foreach ($ajson['data']['tripList'] as &$row) {
    $p = [
        ':time_start' => $row['time_start'],
        ':time_end' => $row['time_end']
    ];
    $sql = "SELECT MAX(speed) AS max_speed FROM driving_data WHERE `timestamp` BETWEEN :time_start AND :time_end";
    $r = db_query_row($conn1, $sql, $p);
    if ($r) {
        $row['max_speed'] = json_decode_x($r['max_speed']);
    }
    $sql = "SELECT location FROM driving_data 
        WHERE `timestamp` = (SELECT MIN(`timestamp`) FROM driving_data WHERE `timestamp` BETWEEN :time_start AND :time_end)";
    $r = db_query_row($conn1, $sql, $p);
    if ($r) {
        $row['position_start'] = json_decode_x($r['location']);
    }
    $sql = "SELECT location FROM driving_data 
        WHERE `timestamp` = (SELECT MAX(`timestamp`) FROM driving_data WHERE `timestamp` BETWEEN :time_start AND :time_end)";
    $r = db_query_row($conn1, $sql, $p);
    if ($r) {
        $row['position_end'] = json_decode_x($r['location']);
    }
}
unset($row);
$conn1 = null;

$ajson['success'] = 1;
$ajson['message'] = '行程数据获取成功！';
returnJson($ajson);
?>