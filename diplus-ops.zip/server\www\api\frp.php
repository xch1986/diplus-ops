<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}
$action = @$_GET['action'] ?? '';
if (!$action) {
    $ajson['message'] = '缺少参数';
    returnJson($ajson);
}


// 添加环境变量，否则command -v xxx 等命令不能返回正确结果
putenv('PATH=/data/data/com.termux/files/usr/bin:' . getenv('PATH'));

$home = $_ENV['HOME'];

$conn = db_conn();

$post = json_decode_x(file_get_contents('php://input'));
if ($action == 'saveData' && $post) {
    writeSettings($conn, 'frp', 'frpOn', $post['frpOn'] ?: 0);
    $frpConfig = file_get_contents("$home/frp/frpc.toml");
    if ($post['frp_config'] != $frpConfig) {
        file_put_contents("$home/frp/frpc.toml", $post['frp_config']);
    }

    // 启用开关联动：开启且配置有效时自动启动 Frpc；关闭时自动停止 Frpc
    if ($post['frpOn']) {
        if (trim((string)@$post['frp_config']) == '') {
            $ajson['message'] = '已保存，但配置文件为空，未启动Frp。请填写配置后重新保存。';
            $ajson['success'] = 1;
            returnJson($ajson);
        }
        unset($output);
        exec('command -v frpc', $output);
        if (!$output) {
            $ajson['message'] = '已保存，但Frpc未安装，无法启动。';
            $ajson['data']['frp_is_running'] = false;
            $ajson['success'] = 1;
            returnJson($ajson);
        }
        // 配置可能已变更，先停掉旧进程，再以新配置启动
        unset($output);
        exec('su -c "pkill -f \'frpc -c\'"', $output);
        $script_path = "$home/boot/frpc.sh";
        unset($output);
        exec("bash $script_path", $output, $return_var);
        if ($return_var !== 0) {
            $ajson['message'] = '已保存，但启动Frpc时发生错误。';
            $ajson['data']['frp_is_running'] = false;
            $ajson['success'] = 1;
            returnJson($ajson);
        }
        unset($output);
        exec('su -c "pidof frpc"', $output);
        if (!$output || count($output) < 2) {
            $ajson['message'] = '已保存，但Frpc启动失败，请检查配置文件。';
            $ajson['data']['frp_is_running'] = false;
            $ajson['success'] = 1;
            returnJson($ajson);
        }
        $ajson['data']['frp_is_running'] = true;
        $ajson['message'] = '数据保存成功，Frpc 已启动！';
        $ajson['success'] = 1;
        returnJson($ajson);
    } else {
        unset($output);
        exec('su -c "pkill -f \'frpc -c\'"', $output);
        $ajson['data']['frp_is_running'] = false;
        $ajson['message'] = '数据保存成功，Frpc 已停止。';
        $ajson['success'] = 1;
        returnJson($ajson);
    }
}


if ($action == 'getData') {
    $returnData = [];
    $returnData['frpOn'] = readSettings($conn, 'frp', 'frpOn') == 1;
    $returnData['frp_config'] = file_get_contents("$home/frp/frpc.toml");
    $returnData['frp_installed'] = false;
    $returnData['frp_version'] = '0';
    unset($output);
    exec('command -v frpc', $output);
    if ($output) {
        $returnData['frp_installed'] = true;
        unset($output);
        exec("frpc --version", $output);
        if ($output) {
            $arr = explode(' ', end($output));
            $returnData['frp_version'] = end($arr);
        }
    }
    unset($output);
    // php中运行pgrep -f xxx时，即使没有符合的进程也会返回一个pid，即 sh -c pgrep -f xxx 进程
    exec('su -c "pidof frpc"', $output);
    $returnData['frp_is_running'] = count($output) > 0;

    $ajson['data'] = $returnData;
    $ajson['success'] = 1;
    returnJson($ajson);
}


if ($action == 'stop' || $action == 'restart') {
    exec('su -c "pidof frpc"', $output);
    if ($output && count($output) > 0) {
        unset($output);
        exec('su -c "pkill -f \'frpc -c\'"', $output);
        if ($output) {
            $ajson['message'] = "停止 Frpc 进程时发生错误。".implode("\n", $output);
            returnJson($ajson);
        }
    }
    $ajson['data']['frp_is_running'] = false;
    if ($action == 'stop') {
        $ajson['message'] = "Frpc 已停止运行";
        $ajson['success'] = 1;
        returnJson($ajson);
    }
}


if ($action == 'start' || $action == 'restart') {
    unset($output);
    exec('command -v frpc', $output);
    if (!$output) {
        $ajson['message'] = "Frpc 启动失败，程序未安装";
        $ajson['data']['frp_is_running'] = false;
        returnJson($ajson);
    }
    $script_path = "$home/boot/frpc.sh";
    exec("bash $script_path", $output, $return_var);
    if ($return_var !== 0) {
        $ajson['message'] = "启动 Frpc 时发生错误";
        $ajson['data']['frp_is_running'] = false;
        returnJson($ajson);
    }

    unset($output);
    exec('su -c "pidof frpc"', $output);
    if (!$output || count($output) < 2) {
        $ajson['message'] = "Frpc 启动失败";
        $ajson['data']['frp_is_running'] = false;
        returnJson($ajson);
    }

    $ajson['data']['frp_is_running'] = true;
    $ajson['message'] = "Frpc 启动成功";
    $ajson['success'] = 1;
    returnJson($ajson);
}

$ajson['message'] = "执行成功";
$ajson['success'] = 1;
returnJson($ajson);
?>