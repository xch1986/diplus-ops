<?php
$p='/data/adb/modules/diplus-keepalive/diplus-daemon.sh';
$s=file_get_contents($p);
// 2a) fuse 自愈升级
$old_fuse='  # 内部存储 fuse 自愈: 下电后 /storage/emulated/0 视图丢失 (行驶数据源不可读)
  if ! ls /storage/emulated/0/Termux/ >/dev/null 2>&1; then
    echo "$(date) 内部存储fuse异常, 重挂emulated" >> $LOG
    sm unmount emulated 2>/dev/null; sleep 2; sm mount emulated 2>/dev/null
    sleep 5
  fi';
$new_fuse='  # ===== 内部存储 fuse 自愈 v2 (2026-10-01): SELinux放行+重挂+bind视图, 带冷却 =====
  if ! ls /storage/emulated/0/vandiplus/ >/dev/null 2>&1; then
    FLAST=/data/local/tmp/.fuse_last
    NOW=$(date +%s)
    if [ ! -f $FLAST ] || [ $(( NOW - $(cat $FLAST) )) -ge 120 ]; then
      date +%s > $FLAST
      echo "$(date) 内部存储异常, 尝试恢复" >> $LOG
      if [ "$(getenforce 2>/dev/null)" = "Enforcing" ] && dumpsys mount 2>/dev/null | grep -q "emulated unmountable"; then
        echo "$(date) emulated卷不可挂载, 临时放行SELinux" >> $LOG
        setenforce 0 2>/dev/null
      fi
      sm unmount emulated 2>/dev/null; sleep 2; sm mount emulated 2>/dev/null
      sleep 8
      if ! ls /storage/emulated/0/vandiplus/ >/dev/null 2>&1 && ls /mnt/runtime/full/emulated/0/ >/dev/null 2>&1; then
        echo "$(date) user层视图缺失, bind完整视图" >> $LOG
        mkdir -p /storage/emulated/0 2>/dev/null
        mount --bind /mnt/runtime/full/emulated/0 /storage/emulated/0 2>/dev/null
        sleep 2
      fi
      if ls /storage/emulated/0/vandiplus/ >/dev/null 2>&1; then
        echo "$(date) 内部存储恢复OK" >> $LOG
      else
        echo "$(date) 内部存储恢复失败" >> $LOG
      fi
    fi
  fi';
if(strpos($s,$old_fuse)!==false){ $s=str_replace($old_fuse,$new_fuse,$s); echo "FUSE_PATCH OK
"; } else { echo "FUSE_PATCH NOTFOUND
"; }
// 2b) 加 8988 保活 (crond 段之后)
$old_cron='  # crond 保活(推送触发): 车机重启后模块版不拉起crond, 推送会停
  if [ -z "$(pidof crond)" ]; then
    echo "$(date) 拉起crond" >> $LOG
    /data/data/com.termux/files/usr/bin/crond -i
    sleep 2
  fi';
$new_cron=$old_cron.'
  # ===== 8988 数据口保活 (2026-10-01): 迪加app被系统禁用/杀掉后自动恢复, 带冷却 =====
  if ! curl -s -o /dev/null --max-time 3 http://127.0.0.1:8988/ 2>/dev/null; then
    DLAST=/data/local/tmp/.dija_last
    NOW=$(date +%s)
    if [ ! -f $DLAST ] || [ $(( NOW - $(cat $DLAST) )) -ge 300 ]; then
      date +%s > $DLAST
      echo "$(date) 8988不在, 恢复迪加app" >> $LOG
      pm enable com.van.diplus 2>/dev/null
      am startservice -n com.van.diplus/.service.MainService 2>/dev/null
      am startservice -n com.van.diplus/.service.SignedLogicHostService 2>/dev/null
      am start -n com.van.diplus/.activity.NaviActivity 2>/dev/null
    fi
  fi';
if(strpos($s,$old_cron)!==false){ $s=str_replace($old_cron,$new_cron,$s); echo "DIJA_PATCH OK
"; } else { echo "DIJA_PATCH NOTFOUND
"; }
// 2c) boot_diag 调用 (start 行后)
$old_start='echo "=== diplus-daemon v5.1 start $(date) ===
" >> $LOG';
$old_start=str_replace('
',"\n",$old_start);
$s=str_replace('echo "=== diplus-daemon v5.1 start $(date) ===
" >> $LOG','echo "=== diplus-daemon v5.2 start $(date) ===
" >> $LOG
  sh /data/local/tmp/boot_diag.sh >/dev/null 2>&1 &',$s);
file_put_contents($p,$s);
echo "SAVED
";
