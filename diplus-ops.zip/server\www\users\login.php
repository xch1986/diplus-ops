<?php
require_once '../includes/jwt.php';
require_once '../includes/db.php';

$tips = "请输入用户名和密码";
$userId = '';
if ($_POST) {
	$conn = db_conn();
	$USER_ID = readSettings($conn, 'global', 'USER_ID');
	$USER_PASSWORD = readSettings($conn, 'global', 'USER_PASSWORD');
	$conn = null;
	$userId = @$_POST['userId'];
	$userPwd = @$_POST['userPwd'];
	if ($userPwd == "") {
		$tips = "请输入用户名和密码!";
	} else {
		if ($userId != $USER_ID || $userPwd != $USER_PASSWORD) {
			$tips = "用户名或密码错误!";
		} else {
			// 登录成功，刷新cookie
			$time = time();
			$expTime = $time + 172800; // 2天
			$token = array(
				'iat' => $time,
				'exp' => $expTime,
				'userId' => $USER_ID
			);
			$access_token = JWT::getToken($token);
			setcookie('access_token', $access_token, $expTime, '/');
			$backurl = @$_GET['backurl'] ?: '/';
			header("Location: $backurl", false, 302);
			exit;
		}
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
	<meta http-equiv="Pragma" content="no-cache"/>
	<meta http-equiv="Expires" content="0"/>
	<title>用户登录</title>
	<link rel="stylesheet" href="/includes/site.css"/>
	<style>
		form input {
			width: 100%;
			max-width: 250px;
			text-align: center;
		}
		.input-div {
			margin: 30px auto;
		}
		.small-window {
			background-color: white;
			text-align: center;
		}
		.title {
			border-top-left-radius: inherit;
			border-top-right-radius: inherit;
			text-align: center;
			font-size: 1.2em;
			font-weight: bold;
			background-image: linear-gradient(to bottom, #07d, #5cf);
			color: white;
			padding: 10px
		}
		.content {
			padding: 10px;
		}
		.login-button {
			width: 100%;
			margin: auto;
			font-size: 1em;
		}
		#bottom-div {
			font-size: 0.9em;
		}
		@keyframes bganimation {
            0%{
                background-position: 0% 50%;
            }
            50%{
                background-position: 100% 50%;
            }
            100%{
                background-position: 0% 50%;
            }
        }
		@media screen and (min-width: 500px) {
			body {
				height: 100vh;
				justify-content: center;
				align-items: center;
				display: flex;
				/* background-image: linear-gradient(to bottom, #fbc2eb, #a6c1ee); */
				background-image: linear-gradient(45deg, #2c3e50,#27ae60,#2980b9,#e74c3c,#8e44ad);
            	background-size: 400%;
            	animation: bganimation 15s infinite;
			}
			.small-window {
				width: 100%;
				max-width: 450px;
				border-radius: 10px;
				box-shadow: 0px 0px 7px 0px #555;
			}
			.content {
				padding: 40px;
			}
		}
	</style>
</head>

<body>
	<div class="small-window">
		<div class="title">登 录 系 统</div>
		<div class="content">
			<form action="" method="post" id="form1" autocomplete="off">
				<div class="input-div">
					<input id="userId" name="userId"
						type="text"
						value="<?php echo $userId?>"
						placeholder="用户名"
					/>
				</div>
				<div class="input-div">
					<input name="userPwd" type="password" placeholder="** 密码 **"/>
				</div>
				<p style="color:red" id="tips"><?php echo $tips?></p>

				<div class="button-bar">
					<button type="submit" class="blue-btn login-button">登&nbsp;&nbsp;录</button>
				</div>
			</form>
		</div>
	</div>
</body>
</html>