<script setup>
import elSelectX from '/includes/vue-components/el-select-x.vue';

// ==================== 原版 Frp ====================
const frpForm = Vue.ref({});
const getFrpData = async () => {
    const res = await axios({
        url: 'api/frp.php',
        method: 'get',
        params: { action: 'getData' }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) gotoLogin();
        return;
    }
    frpForm.value = res.data.data;
}
getFrpData();
const frpFormRef = Vue.ref();
const submitFrp = async () => {
    const res = await axios({
        url: 'api/frp.php',
        method: 'post',
        params: { action: 'saveData' },
        data: frpForm.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) gotoLogin();
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getFrpData();
}

// ==================== easytier ====================
const etForm = Vue.ref({});
const etData = Vue.ref({});
const getEtData = async () => {
    const res = await axios({
        url: 'api/easytier.php',
        method: 'get',
        params: { action: 'getData' }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) gotoLogin();
        return;
    }
    etForm.value = res.data.formData;
    etData.value = res.data.data;
}
getEtData();
const etFormRef = Vue.ref();
const submitEt = async () => {
    const res = await axios({
        url: 'api/easytier.php',
        method: 'post',
        params: { action: 'saveData' },
        data: etForm.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) gotoLogin();
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getEtData();
}
const etPearOptions = [
    { value: 'tcp://public.easytier.top:11010', label: '官方-广东 tcp://public.easytier.top:11010' },
    { value: 'tcp://public.easytier.cn:11010', label: '官方 tcp://public.easytier.cn:11010' },
    { value: 'tcp://et.gbc.moe:11010', label: '浙江宁波 tcp://et.gbc.moe:11010' },
    { value: 'tcp://turn.sc.629957.xyz:11010', label: '四川成都 tcp://turn.sc.629957.xyz:11010' },
    { value: 'tcp://103.194.107.246:11010', label: '中国香港 tcp://103.194.107.246:11010' },
    { value: 'tcp://119.23.65.180:11010', label: '广东深圳 tcp://119.23.65.180:11010' },
    { value: 'tcp://et.993555.xyz:11010', label: '浙江金华 tcp://et.993555.xyz:11010' },
    { value: 'turn.bj.629957.xyz:11010', label: '中国北京 tcp://turn.bj.629957.xyz:11010' },
];
let interval = setInterval(async () => {
    const res = await axios({
        url: 'api/easytier.php',
        method: 'get',
        params: { action: 'getStatusData' }
    });
    if (res.data.success < 1) {
        if (res.data.success == -1) gotoLogin();
        return;
    }
    etData.value = res.data.data;
}, 5000);
Vue.onUnmounted(() => {
    clearInterval(interval);
    interval = null;
});

// ==================== 樱花 Frp ====================
const sakuraForm = Vue.ref({});
const getSakuraData = async () => {
    const res = await axios({
        url: 'api/sakurafrp.php',
        method: 'get',
        params: { action: 'getData' }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) gotoLogin();
        return;
    }
    sakuraForm.value = res.data.data;
}
getSakuraData();
const sakuraFormRef = Vue.ref();
const submitSakura = async () => {
    const res = await axios({
        url: 'api/sakurafrp.php',
        method: 'post',
        params: { action: 'saveData' },
        data: sakuraForm.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) gotoLogin();
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getSakuraData();
}

// ==================== 通用操作(启停/重启) ====================
const reloadMap = { frp: getFrpData, easytier: getEtData, sakurafrp: getSakuraData };
const saveMap = { frp: submitFrp, easytier: submitEt, sakurafrp: submitSakura };
const appi = async (appName, action) => {
	const res = await axios({
		url: `api/${appName}.php`,
		method: 'get',
		params: { action: action }
	});
	if (res.data.success < 1) {
		ElementPlus.ElMessage.error(res.data.message);
		if (res.data.success == -1) gotoLogin();
		return;
	}
	ElementPlus.ElMessage.success(res.data.message);
	if (reloadMap[appName]) reloadMap[appName]();
}
const appiAction = async (appName, action) => {
	if (saveMap[appName]) await saveMap[appName]();
	await appi(appName, action);
}
const appiStop = async (appName) => {
	let res = await ElementPlus.ElMessageBox
		.confirm("如你正在远程连接车机，停止网络后可能会失去连接。确定要停止吗？")
		.catch(() => {});
	if (res != 'confirm') return;
	appiAction(appName, 'stop');
}

// ==================== frp 启用开关联动 ====================
const onFrpSwitch = async (checked) => {
    if (checked) {
        // 开启：配置已填则保存并自动启动（后端联动）；配置为空仅展开配置区提示填写
        if (!frpForm.value.frp_config || !frpForm.value.frp_config.trim()) {
            ElementPlus.ElMessage.warning('请先填写 frp 配置文件，再点保存即可启动 Frpc');
            return;
        }
        await submitFrp();
    } else {
        // 关闭：确认后停止 Frpc 并保存关闭状态
        let res = await ElementPlus.ElMessageBox
            .confirm("关闭启用开关将停止 Frpc，若正在远程连接车机可能失去连接。确定要停止吗？", "提示", { type: 'warning' })
            .catch(() => {});
        if (res != 'confirm') {
            frpForm.value.frpOn = true; // 取消则弹回开启状态
            return;
        }
        await appi('frp', 'stop');
        frpForm.value.frpOn = false;
        await submitFrp();
    }
}

// ==================== 选项卡 ====================
const activeTab = Vue.ref('frp');
const saveActive = async () => {
	if (saveMap[activeTab.value]) await saveMap[activeTab.value]();
}
</script>

<template>
    <el-tabs v-model="activeTab" type="border-card">
        <el-tab-pane label="原版 Frp" name="frp">
            <el-form ref="frpFormRef" :model="frpForm" label-width="auto" label-position="top">
                <div class="tab-head">
                    <div class="tab-head-title">原版 Frp</div>
                    <div>
                        <el-switch v-model="frpForm.frpOn" active-text="启用" @change="onFrpSwitch"/>
                    </div>
                </div>
                <div>
                    <el-form-item prop="frp_config" label="配置文件">
                        <el-input v-model="frpForm.frp_config" type="textarea" :rows="12"/>
                    </el-form-item>
                    <div class="info-div">
                        <el-link type="primary" href="https://github.com/fatedier/frp" target="_blank">Frp项目主页</el-link>:
                        A fast reverse proxy to help you expose a local server behind a NAT or firewall to the internet.
                    </div>
                    <div class="info-div">
                        <el-text type="warning">配置文件修改后需要重启Frp才能生效！</el-text>
                    </div>
                    <div class="button-bar">
                        <el-button type="danger" @click="appiStop('frp')" :disabled="!frpForm.frp_is_running">停止Frp</el-button>
                        <el-button type="success" @click="appiAction('frp', 'start')" :disabled="frpForm.frp_is_running || !frpForm.frp_installed">启动Frp</el-button>
                        <el-button type="primary" @click="appiAction('frp', 'restart')" :disabled="!frpForm.frp_is_running">重启Frp</el-button>
                        <div>
                            <el-text v-if="!frpForm.frp_installed">frpc 未安装</el-text>
                            <el-text v-else>版本: {{ frpForm.frp_version }}</el-text>
                        </div>
                        <img v-if="frpForm.frp_is_running" src="/media/running1.gif" style="height:50px">
                        <div v-else class="iconfont icon-running" style="font-size: 1.8em; color: gray"></div>
                    </div>
                </div>
            </el-form>
        </el-tab-pane>

        <el-tab-pane label="Lucky" name="lucky">
            <div class="tab-head">
                <div class="tab-head-title">Lucky + ipv6</div>
            </div>
            <iframe src="/r/lucky/" width="100%" height="900px" style="border: none" class="page-iframe"></iframe>
        </el-tab-pane>

        <el-tab-pane label="easytier" name="easytier">
            <el-form ref="etFormRef" :model="etForm" label-width="auto" label-position="top">
                <div class="tab-head">
                    <div class="tab-head-title">easytier 虚拟网</div>
                    <div>
                        <el-switch v-model="etForm.easytierOn" active-text="启用"/>
                    </div>
                </div>
                <div v-if="etForm.easytierOn">
                    <div class="inline-form-items">
                        <el-form-item prop="et_hostname" label="虚拟网主机名">
                            <el-input v-model="etForm.et_hostname" />
                        </el-form-item>
                        <el-form-item prop="et_ipv4">
                            <template #label>
                                车机虚拟网IP
                                <el-tooltip placement="top-start" content="如: 172.20.0.18, 车机/手机/电脑的虚拟IP不能重复">
                                    <span class="iconfont icon-question-circle tooltip"></span>
                                </el-tooltip>
                            </template>
                            <el-input v-model="etForm.et_ipv4"/>
                        </el-form-item>
                    </div>
                    <div class="inline-form-items">
                        <el-form-item prop="et_network_name">
                            <template #label>
                                虚拟网络名称
                                <el-tooltip placement="top-start" content="车机/手机/电脑必须一样填写">
                                    <span class="iconfont icon-question-circle tooltip"></span>
                                </el-tooltip>
                            </template>
                            <el-input v-model="etForm.et_network_name"/>
                        </el-form-item>
                        <el-form-item prop="et_network_secret">
                            <template #label>
                                虚拟网络密码
                                <el-tooltip placement="top-start" content="车机/手机/电脑必须一样填写">
                                    <span class="iconfont icon-question-circle tooltip"></span>
                                </el-tooltip>
                            </template>
                            <el-input v-model="etForm.et_network_secret"/>
                        </el-form-item>
                    </div>
                    <div class="inline-form-items">
                        <el-form-item prop="et_peer">
                            <template #label>
                                组网服务器
                                <el-tooltip placement="top-start" content="车机/手机/电脑一样填写，更多公共服务器查询easytier官网">
                                    <span class="iconfont icon-question-circle tooltip"></span>
                                </el-tooltip>
                            </template>
                            <el-select-x v-model="etForm.et_peer" :options="etPearOptions" allow-create multiple/>
                        </el-form-item>
                        <el-form-item prop="et_params">
                            <template #label>
                                附加命令行参数
                                <el-tooltip placement="top-start" content="自动添加 --no-listener --no-tun --bind-device false, 其它参考easytier官网">
                                    <span class="iconfont icon-question-circle tooltip"></span>
                                </el-tooltip>
                            </template>
                            <el-input v-model="etForm.et_params"/>
                        </el-form-item>
                    </div>

                    <div class="info-div">
                        <el-link type="primary" href="https://easytier.cn" target="_blank">easytier官网</el-link>:
                        一个简单、安全、去中心化的内网穿透 VPN 组网方案，开源、免费
                    </div>
                    <div class="info-div">
                        <el-text type="warning">设置修改后需要重启easytier才能生效！</el-text>
                    </div>

                    <div class="button-bar">
                        <el-button type="danger" @click="appiStop('easytier')" :disabled="!etData.et_is_running">停止网络</el-button>
                        <el-button type="success" @click="appiAction('easytier', 'start')" :disabled="etData.et_is_running || !etData.et_installed">运行网络</el-button>
                        <el-button type="primary" @click="appiAction('easytier', 'restart')" :disabled="!etData.et_is_running">重启easytier</el-button>
                        <div>
                            <el-text v-if="!etData.et_installed">easytier 未安装</el-text>
                            <el-text v-else>版本: {{ etData.et_version }}</el-text>
                        </div>
                        <img v-if="etData.et_is_running" src="/media/running1.gif" style="height:50px">
                        <div v-else class="iconfont icon-running" style="font-size: 1.8em;color: gray"></div>
                    </div>

                    <div class="slide">
                        <el-table :data="etData.net_peers">
                            <el-table-column prop="ipv4" label="设备虚拟网ip" :min-width="140"/>
                            <el-table-column prop="hostname" label="设备主机名" :min-width="120" show-overflow-tooltip/>
                            <el-table-column prop="cost" label="路由" :min-width="100"/>
                            <el-table-column prop="lat_ms" label="延迟(ms)" :min-width="100"/>
                            <el-table-column prop="loss_rate" label="丢包率(%)" :min-width="100"/>
                            <el-table-column prop="rx_bytes" label="下载" :min-width="120"/>
                            <el-table-column prop="tx_bytes" label="上传" :min-width="120"/>
                            <el-table-column prop="version" label="easytier版本" :min-width="150"/>
                        </el-table>
                    </div>
                </div>
            </el-form>
        </el-tab-pane>

        <el-tab-pane label="樱花 Frp" name="sakurafrp">
            <el-form ref="sakuraFormRef" :model="sakuraForm" label-width="auto" label-position="top">
                <div class="tab-head">
                    <div class="tab-head-title">樱花 Frp</div>
                    <div>
                        <el-switch v-model="sakuraForm.sakurafrpOn" active-text="启用"/>
                    </div>
                </div>
                <div v-if="sakuraForm.sakurafrpOn">
                    <el-form-item prop="sakurafrp_config" label="樱花Frp配置参数">
                        <el-input v-model="sakuraForm.sakurafrp_config"/>
                    </el-form-item>

                    <div class="info-div">
                        1. <el-link type="primary" href="https://www.natfrp.com" target="_blank">樱花Frp官网</el-link>:
                        基于Frp二次开发，不需要自己的服务器，限量免费
                    </div>
                    <div class="info-div">
                        2. 可从 <el-link type="primary" href="https://www.natfrp.com/tunnel" target="_blank">樱花Frp隧道列表</el-link>
                        页面复制配置参数，格式为: <el-text type="warning">访问密码:隧道ID1,隧道ID2</el-text>...。
                    </div>
                    <div class="info-div">
                        3. 微信有可能会拦截樱花Frp的网址，如果无法从微信中打开，建议尝试更换服务器或者改用easytier/原版Frp/lucky(ipv6动态域名)等远程方案。
                    </div>
                    <div class="info-div">
                        4. <el-text type="warning">参数修改后需要重启樱花Frp才能生效！</el-text>
                    </div>

                    <div class="button-bar">
                        <el-button type="danger" @click="appiStop('sakurafrp')" :disabled="!sakuraForm.sakurafrp_is_running">停止Frp</el-button>
                        <el-button type="success" @click="appiAction('sakurafrp', 'start')" :disabled="sakuraForm.sakurafrp_is_running || !sakuraForm.sakurafrp_version">启动Frp</el-button>
                        <el-button type="primary" @click="appiAction('sakurafrp', 'restart')" :disabled="!sakuraForm.sakurafrp_is_running">重启Frp</el-button>
                        <div>
                            <el-text v-if="sakuraForm.sakurafrp_version == 0">樱花Frp 未安装</el-text>
                            <el-text v-else>版本: {{ sakuraForm.sakurafrp_version }}</el-text>
                        </div>
                        <img v-if="sakuraForm.sakurafrp_is_running" src="/media/running1.gif" style="height:50px">
                        <div v-else class="iconfont icon-running" style="font-size: 1.8em;color: gray"></div>
                    </div>
                </div>
            </el-form>
        </el-tab-pane>
    </el-tabs>

    <page-footer>
        <el-button type="primary" style="width:150px" @click="saveActive()">保 存</el-button>
    </page-footer>
</template>

<style scoped>
.tooltip {
    color: orangered;
    cursor: pointer;
}
@media (max-width: 767px) {
    .page-iframe {
        height: calc(100vh - 130px) !important;
    }
}
</style>
