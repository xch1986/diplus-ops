<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}

$conn = db_conn();
$action = $_GET['action'] ?? '';
$stopHours = (int)@$_GET['stopHours'];
if ($action == 'stopAlarm') {
    $no_alarm_before = $stopHours == 0 ? 0 : (time() + $stopHours * 3600) * 1000;
    writeSettings($conn, 'global', 'no_alarm_before', $no_alarm_before);
    $ajson['data']['no_alarm_before'] = $no_alarm_before;
    $ajson['success'] = 1;
    returnJson($ajson);
}


$show_stop_alaram_btn = readSettings($conn, 'global', 'show_stop_alaram_btn');
$show_stop_alaram_btn = $show_stop_alaram_btn == '' || $show_stop_alaram_btn == 1;
$ajson['data'] = [
    'filebrowser_url' => readSettings($conn, 'global', 'filebrowser_url'),
    'cover_filename' => readSettings($conn, 'global', 'cover_filename') ?: 'byd.jpg',
    'diplus_cmd' => json_decode_x(readSettings($conn, 'diplus', 'diplus_cmd')),
    'diplus_params' => json_decode_x(readSettings($conn, 'diplus', 'diplus_params')),
    'preset_params' => json_decode_x(readSettings($conn, 'diplus', 'preset_params')),
    'autorefresh_params' => readSettings($conn, 'global', 'autorefresh_params') == 1,
    'maint' => json_decode_x(readSettings($conn, 'global', 'maint')),
    'show_stop_alaram_btn' => $show_stop_alaram_btn,
    'no_alarm_before' => (int)readSettings($conn, 'global', 'no_alarm_before')
];

$ajson['message'] = "获取数据成功！";
$ajson['success'] = 1;
returnJson($ajson);
?>