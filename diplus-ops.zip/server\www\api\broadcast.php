<?php
header('Content-type: text/html; charset=utf-8');
require_once 'includes/phpshare.php';
$login = login();

$cmd = "播报{车内温度}"; 
$command = 'am broadcast -a "com.byd.NotifyService.intentUIDeal" --es "resultDealType" "TEXT_RECEIVE" --es "resultDealViewText" "'.$cmd.'"';
echo $command."<br/>"; 
$output = [];
$return_code = 0; 
exec($command, $output, $return_code); 

if ($return_code === 0) {
    echo "命令执行成功，输出为：<br>"; 
} else {
    echo "命令执行失败，返回值为：$return_code";
}
foreach ($output as $line) {
    echo htmlspecialchars($line) . "<br>"; 
}
?>