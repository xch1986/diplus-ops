#!/bin/bash

home="/data/data/com.termux/files/home"
db_path="$home/db/db.db"

appOn=""
if [ -f "$db_path" ] && command -v sqlite3 >/dev/null 2>&1; then
    appOn=$(sqlite3 "$db_path" "SELECT data FROM settings WHERE app='openlist' AND param='openlistOn'" 2>/dev/null | head -1)
fi
if [ -n "$appOn" ] && [ "$appOn" != "1" ]; then
    echo "openlist 未启用"
    pkill -f "openlist server" 2>/dev/null
    exit
fi

if pgrep -f "openlist server" > /dev/null; then
    echo "openlist 正在运行。"
    exit
fi

echo "启动 openlist ..."
export PATH=/data/data/com.termux/files/usr/bin:$PATH
export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib
setsid nohup /data/data/com.termux/files/usr/bin/openlist server > "$home/openlist.log" 2>&1 &
sleep 1
