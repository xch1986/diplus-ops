<script setup>
const formData = Vue.ref({});
const getData = async () => {
    const res = await axios({
        url: 'api/frp.php',
        method: 'get',
        params: {
            action: 'getData'
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value = res.data.data;
}
getData();

const formRef = Vue.ref();
const rules = Vue.ref({ required: true, trigger: 'blur', message: '此项不能为空' });
const submitForm = async () => {
    const valid = await formRef.value.validate((valid) => { return valid });
    if (!valid) {
        ElementPlus.ElMessageBox.alert("请确认表单填写完整再提交！");
        return;
    }
    const res = await axios({
        url: 'api/frp.php',
        method: 'post',
        params: {
            action: 'saveData'
        },
        data: formData.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getData();
}

const appi = async (appName, action) => {
	const res = await axios({
		url: `api/${appName}.php`,
		method: 'get',
		params: {
			action: action 
		}
	});
	if (res.data.success < 1) {
		ElementPlus.ElMessage.error(res.data.message);
		if (res.data.success == -1) {
			gotoLogin();
		}
		return;
	}
	ElementPlus.ElMessage.success(res.data.message);
	getData();
}
const appiAction = async (appName, action) => {
	await submitForm();
	await appi(appName, action);
}
const appiStop = async (appName) => {
	let res = await ElementPlus.ElMessageBox
		.confirm("如你正在远程连接车机，停止网络后可能会失去连接。确定要停止吗？")
		.catch(() => {});
	if (res != 'confirm') return;
	appiAction(appName, 'stop');
}
</script>

<template>
    <el-form ref="formRef" :model="formData" label-width="auto" label-position="top">
        <div class="tab-head">
            <div class="tab-head-title">原版 Frp</div>
            <div>
                <el-switch v-model="formData.frpOn" active-text="启用"/>
            </div>
        </div>

        <div v-if="formData.frpOn">
            <el-form-item prop="frp_config" label="配置文件">
                <el-input v-model="formData.frp_config" type="textarea" :rows="12"/>
            </el-form-item>

            <div class="info-div">
                <el-link type="primary" href="https://github.com/fatedier/frp" target="_blank">Frp项目主页</el-link>:
                A fast reverse proxy to help you expose a local server behind a NAT or firewall to the internet.
            </div>
            <div class="info-div">
                <el-text type="warning">配置文件修改后需要重启Frp才能生效！</el-text>
            </div>

            <div class="button-bar">
                <el-button type="danger" @click="appiStop('frp')" :disabled="!formData.frp_is_running">
                    停止Frp
                </el-button>
                <el-button
                    type="success"
                    @click="appiAction('frp', 'start')"
                    :disabled="formData.frp_is_running || !formData.frp_installed"
                >
                    启动Frp
                </el-button>
                <el-button type="primary" @click="appiAction('frp', 'restart')" :disabled="!formData.frp_is_running">
                    重启Frp
                </el-button>
                <div>
                    <el-text v-if="!formData.frp_installed">frpc 未安装</el-text>
                    <el-text v-else>版本: {{ formData.frp_version }}</el-text>
                </div>
                <img v-if="formData.frp_is_running" src="/media/running1.gif" style="height:50px">
                <div v-else class="iconfont icon-running" style="font-size: 1.8em; color: gray"></div>
            </div>
        </div>
    </el-form>

    <page-footer>
        <el-button type="primary" style="width:150px" @click="submitForm()">保 存</el-button>
    </page-footer>
</template>

<style scoped>
</style>