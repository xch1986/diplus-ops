#!/bin/bash
sleep 300

home="/data/data/com.termux/files/home"
db_path="$home/db/db.db"
move_files_to_sd=$(sqlite3 "$db_path" "SELECT data FROM settings WHERE app = 'global' AND param = 'move_files_to_sd'")
days_clean_screen_record=$(sqlite3 "$db_path" "SELECT data FROM settings WHERE app = 'global' AND param = 'days_clean_screen_record'")
if [[ "$move_files_to_sd" == "1" || "$days_clean_screen_record" -gt 0 ]]; then
    echo "移动/清理迪加视频文件..."
    php "$home/www/api/clean_files.php"
fi
