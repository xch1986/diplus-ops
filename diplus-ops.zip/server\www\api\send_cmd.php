<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = [ 'success' => 0, 'message' => '', 'data' => [] ];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '指令发送失败！未登录系统。';
    returnJson($ajson);
}

$cmd = $_GET['cmd'] ?? '';
if (!$cmd) {
    $ajson['message'] = '指令不能为空！';
    returnJson($ajson);
}
$cmd = str_replace('\n', "\n", $cmd);

$conn = db_conn();
$DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
$url = "http://localhost:8988/api/sendCmd";
$url .= "?cmd=".urlencode($cmd);
$url .= "&auth=".urlencode($DIPLUS_AUTH);
$context = stream_context_create([
    'http' => [
        'timeout' => 5
    ]
]);
$res = json_decode_x(@file_get_contents($url, false, $context));
if (!$res || $res['success'] !== true) {
    $ajson['message'] = '指令发送失败！';
    returnJson($ajson);
}

$ajson['success'] = 1;
$ajson['message'] = "指令发送成功！";
returnJson($ajson);
?>
