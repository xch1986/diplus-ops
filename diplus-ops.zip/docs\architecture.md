# 架构详解

## 1. 系统组成

```
┌───────────────────────────────────────────────────────────────┐
│ BYD DiLink 车机 (Android, root: Magisk)                        │
│                                                               │
│  ┌─ Termux (com.termux) ───────────────────────────────────┐  │
│  │  home/                                                    │  │
│  │  ├── www/        PHP 前端 + API（nginx root）            │  │
│  │  ├── nginx/      nginx.conf 等                           │  │
│  │  ├── php/        php.ini                                 │  │
│  │  ├── db/         db.db (SQLite: 配置/推送模板/业务数据)   │  │
│  │  ├── boot/       frpc.sh openlist.sh lucky.sh 等开机脚本 │  │
│  │  ├── frp/        frpc.toml + frpc.log + frpc.pid         │  │
│  │  └── boot_diag.log / daemon.log / alarm_*.txt            │  │
│  └────────────────────────────────────────────────────────────┘  │
│                                                               │
│  ┌─ Magisk 模块 /data/adb/modules/diplus-keepalive/ ───────┐  │
│  │  service.sh          开机入口 (pm enable termux → watchdog)│ │
│  │  diplus-watchdog.sh  看门狗 v2 (60s 循环)                │  │
│  │  diplus-daemon.sh    守护 daemon v5.3 (30s 自愈循环)     │  │
│  │  module.prop         模块元信息                          │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                               │
│  ┌─ 迪加 app (com.van.diplus) ─────────────────────────────┐  │
│  │  哨兵录制/行驶数据 → /storage/emulated/0/vandiplus/      │  │
│  │  数据口 8988 (SignedLogicHostService)                    │  │
│  └───────────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────────┘
```

## 2. 网络拓扑

- 车机通过 **UFI 热点**（192.168.43.1）上网，车机 IP `192.168.43.170`
- Termux 服务全部监听 `127.0.0.1`（nginx 8018 / openlist 5244 / lucky 16601 / sshd 8022）
- **frpc** 将以上端口经 frps 服务器（`cqwintech.cn:7000` 等，自建）映射到公网
- 告警推送：crond 每分钟调 `alarm_poll.php` → 钉钉/企业微信机器人

## 3. 数据流

### 哨兵告警
```
迪加 app 录制事件(晃动/振动)
  → 触发 /storage/emulated/0/vandiplus/config/ 配置文件更新
  → inotifywait 监听(diplus_config.sh) → set_diplus_config.php 回写
  → 迪加写入推送记录(含 motionGyro/motionG 强度)
  → crond → alarm_poll.php 每分轮询 → 命中阈值 → 钉钉/企业微信推送
```

### 行驶数据
```
迪加 app → /storage/emulated/0/vandiplus/ 数据
  → save_driving_data.php 入库 (db.db)
  → sum_*.php 汇总 → Web 图表展示 (sum.html)
```

## 4. 守护链（防失联核心）

```
开机 → Magisk service.sh
       └─(20s)→ watchdog (oom=-1000, nice=-20)
                  └─(60s 检查)→ daemon (oom=-1000, nice=-20)
                                 └─(30s 循环)
                                    ├─ nginx 不在 → 拉起
                                    ├─ php-fpm 不在/502 → 拉起/重建
                                    ├─ frpc 不在 → 拉起
                                    ├─ openlist 不在 → 拉起
                                    ├─ lucky 不在 → 拉起
                                    ├─ crond 不在 → 拉起
                                    ├─ 8988 迪加口不在 → 恢复 app(300s冷却)
                                    ├─ 内部存储 fuse 异常 → 自愈(开机240s宽限+120s冷却)
                                    └─ SD 未挂载 → USB/SCSI 重扫(300s冷却,不重启vold)
```

crontab（root）另做兜底：daemon 死 → 每分钟由 `start_daemon.sh` 拉起。
