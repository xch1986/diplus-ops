#!/system/bin/sh
# diplus-watchdog v2 - 常驻守护 diplus-daemon (60s, 拉起+抗杀) (2026-09-30: PID+进程名校验)
export PATH=/data/data/com.termux/files/usr/bin:$PATH
export HOME=/data/data/com.termux/files/home
export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib
LOG=$HOME/daemon.log
WLOCK=/data/local/tmp/diplus-watchdog.pid
if [ -f "$WLOCK" ]; then
  WP=$(cat $WLOCK 2>/dev/null)
  if [ -n "$WP" ] && grep -q diplus-watchdog /proc/$WP/cmdline 2>/dev/null; then
    exit 0
  fi
fi
rm -f $WLOCK
echo $$ > $WLOCK
echo -1000 > /proc/$$/oom_score_adj 2>/dev/null
renice -n -20 -p $$ 2>/dev/null
echo "=== diplus-watchdog v2 start $(date) ===" >> $LOG
while true; do
  DP=$(cat /data/local/tmp/diplus-daemon.pid 2>/dev/null)
  if [ -z "$DP" ] || ! grep -q diplus-daemon /proc/$DP/cmdline 2>/dev/null; then
    echo "$(date) watchdog: daemon不在, 拉起" >> $LOG
    rm -f /data/local/tmp/diplus-daemon.pid
    setsid /system/bin/sh -c 'export PATH=/data/data/com.termux/files/usr/bin:$PATH; export HOME=/data/data/com.termux/files/home; export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib; nohup bash /data/adb/modules/diplus-keepalive/diplus-daemon.sh >> /data/data/com.termux/files/home/daemon.log 2>&1 &'
    sleep 8
    DP=$(cat /data/local/tmp/diplus-daemon.pid 2>/dev/null)
  fi
  if [ -n "$DP" ] && grep -q diplus-daemon /proc/$DP/cmdline 2>/dev/null; then
    echo -1000 > /proc/$DP/oom_score_adj 2>/dev/null
    renice -n -20 -p $DP 2>/dev/null
  fi
  sleep 60
done
