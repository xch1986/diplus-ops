<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}
$action = @$_GET['action'] ?? '';
if (!$action) {
    $ajson['message'] = '缺少参数';
    returnJson($ajson);
}

// 添加环境变量，否则command -v xxx 等命令不能返回正确结果
putenv('PATH=/data/data/com.termux/files/usr/bin:' . getenv('PATH'));
$home = $_ENV['HOME'];

$conn = db_conn();

$post = json_decode_x(file_get_contents('php://input'));
if ($action == 'saveData' && $post) {
    writeSettings($conn, 'sakurafrp', 'sakurafrpOn', $post['sakurafrpOn'] ?: 0);
    writeSettings($conn, 'sakurafrp', 'sakurafrp_config', $post['sakurafrp_config']);

    $ajson['message'] = '数据保存成功！';
    $ajson['success'] = 1;
    returnJson($ajson);
}


if ($action == 'getData') {
    $returnData = [];
    $returnData['sakurafrpOn'] = readSettings($conn, 'sakurafrp', 'sakurafrpOn') == 1;
    $returnData['sakurafrp_config'] = readSettings($conn, 'sakurafrp', 'sakurafrp_config');
    $file_path = "$home/sakurafrp/frpc";
    $returnData['sakurafrp_version'] = 0;
    if (file_exists($file_path)) {
        exec("$file_path --version", $output);
        if ($output) {
            $arr = explode(' ', end($output));
            $returnData['sakurafrp_version'] = end($arr);
        }
    }
    unset($output);
    exec('pgrep -f "frpc -f"', $output);
    $returnData['sakurafrp_is_running'] = count($output) > 1;

    $ajson['data'] = $returnData;
    $ajson['success'] = 1;
    returnJson($ajson);
}


if ($action == 'stop' || $action == 'restart') {
    exec('pgrep -f "frpc -f"', $output);
    if ($output && count($output) > 1) {
        unset($output);
        exec('pkill -f "frpc -f"', $output);
        if ($output) {
            $ajson['message'] = "停止 樱花Frp 进程时发生错误。".implode("\n", $output);
            returnJson($ajson);
        }
    }
    $ajson['data']['sakurafrp_is_running'] = false;
    if ($action == 'stop') {
        $ajson['message'] = "樱花Frp 已停止运行";
        $ajson['success'] = 1;
        returnJson($ajson);
    }
}


if ($action == 'start' || $action == 'restart') {
    $file_path = "$home/sakurafrp/frpc";
    $script_path = "$home/boot/sakurafrp.sh";
    if (!file_exists($file_path)) {
        $ajson['message'] = "樱花Frp 启动失败，程序未安装";
        $ajson['data']['sakurafrp_is_running'] = false;
        returnJson($ajson);
    }
    exec("bash $script_path", $output, $return_var);
    if ($return_var !== 0) {
        $ajson['message'] = "启动 樱花Frp 时发生错误";
        $ajson['data']['sakurafrp_is_running'] = false;
        returnJson($ajson);
    }

    unset($output);
    exec('pgrep -f "frpc -f"', $output);
    if (!$output || count($output) < 2) {
        $ajson['message'] = "樱花Frp 启动失败";
        $ajson['data']['sakurafrp_is_running'] = false;
        returnJson($ajson);
    }

    $ajson['data']['sakurafrp_is_running'] = true;
    $ajson['message'] = "樱花Frp 启动成功";
    $ajson['success'] = 1;
    returnJson($ajson);
}

$ajson['message'] = "执行成功";
$ajson['success'] = 1;
returnJson($ajson);
?>