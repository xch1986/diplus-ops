<?php
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

if (isset($_COOKIE[session_name()]))
	setcookie(session_name(), '', time()-3600, '/'); //remove PHPSESSID from browser

ob_start();
setcookie('access_token', '', time()-3600, '/');
ob_end_flush();

$url = @$_GET['url'] ?: '/';
header("Location: $url", false, 302);
exit;
?>