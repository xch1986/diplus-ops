#!/system/bin/sh
# diplus keepalive - Magisk module service.sh (boot phase, root)
# v2 2026-09-28: 开机先确保 Termux 未被禁用(enabled=0 会导致进程被杀全服务停, 2026-09-25失联根因)
(
  sleep 20
  pm enable com.termux 2>/dev/null
  setsid /system/bin/sh -c 'export PATH=/data/data/com.termux/files/usr/bin:$PATH; export HOME=/data/data/com.termux/files/home; export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib; nohup sh /data/adb/modules/diplus-keepalive/diplus-watchdog.sh >> /data/data/com.termux/files/home/daemon.log 2>&1 &'
) &
