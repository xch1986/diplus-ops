<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$dateFrom = $_GET["dateFrom"] ?? '';
$dateTo = $_GET["dateTo"] ?? '';
$login = login(false);
if (!$login || !$dateFrom || !$dateTo) {
    $ajson['success'] = -1;
    $ajson['message'] = '获取数据充电失败！未登录系统。';
    returnJson($ajson);
}

$dbPath = '/storage/emulated/0/vandiplus/db/van_bm_db';
$conn = db_conn($err, $dbPath);
if (!$conn) {
    $ajson['message'] = "打开数据库失败！$err";
    returnJson($ajson);
}

$p = [];
$aWhere = [ 'power > prePower' ];
$aWhere[] = "date(`time` / 1000, 'unixepoch', 'localtime') BETWEEN :dateFrom AND :dateTo";
$p[':dateFrom'] = $dateFrom;
$p[':dateTo'] = $dateTo;

$strWhere = implode(' AND ', $aWhere);
$sql = "SELECT strftime('%Y-%m-01', `time` / 1000, 'unixepoch', 'localtime') AS mon,
    COUNT(`power`) AS elecChargeCnt,
    ROUND(MAX(`power`) - MIN(prePower), 1) AS elecCharged,
    ROUND((MAX(`power`) - MIN(prePower)) / SUM(elecPer_end - elecPer_start) * 100, 1) AS batteryCapc,
    ROUND((MAX(mileage) - MIN(preMileage)) / 10, 1) AS mileage,
    ROUND((MAX(evMileage) - MIN(preEvMileage)) / 10, 1) AS evMileage,
    ROUND(MAX(elecCon) - MIN(preElecCon), 1) AS elecCon
    FROM ChargingLog
    WHERE $strWhere
    GROUP BY mon
";

$data = db_query_all($conn, $sql, $p);
if (!$data) {
    $ajson['message'] = '获取充电数据失败！';
    returnJson($ajson);    
}
$ajson['data']['elecChargingData'] = $data;

$conn0 = db_conn();
$ajson['data']['fuel_price'] = (float) readSettings($conn0, 'global', 'fuel_price');
$ajson['data']['elec_price'] = (float) readSettings($conn0, 'global', 'elec_price');

$ajson['success'] = 1;
$ajson['message'] = '充电获数据取成功！';
returnJson($ajson);
?>