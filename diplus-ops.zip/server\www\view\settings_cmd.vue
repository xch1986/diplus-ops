<script setup>
import elSelectX from '/includes/vue-components/el-select-x.vue';
import sortable from '/includes/vue-components/sortable/sortable.vue';

const formData = Vue.ref({});
const getData = async () => {
    const res = await axios({
        url: 'api/settings_cmd.php',
        method: 'get'
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value = res.data.data;
}
getData();

const formRef = Vue.ref();
const rules = Vue.ref({ required: true, trigger: 'blur', message: '此项不能为空' });
const submitForm = async () => {
    const valid = await formRef.value.validate((valid) => { return valid });
    if (!valid) {
        ElementPlus.ElMessageBox.alert("请确认表单填写完整再提交！");
        return;
    }
    const res = await axios({
        url: 'api/settings_cmd.php',
        method: 'post',
        data: formData.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getData();
}
const buttonTypeOptions = [
    {
        label: '蓝色',
        value: 'primary'
    },
    {
        label: '绿色',
        value: 'success'
    },
    {
        label: '黄色',
        value: 'warning'
    },
    {
        label: '红色',
        value: 'danger'
    },
    {
        label: '灰色',
        value: 'info'
    }
];

const addCmd = () => {
    const len = formData.value.diplus_cmd?.length;
    const row = {
        uid: uid(),
        label: '自定义按钮' + (len + 1),
        buttonType: 'primary',
        command: ''
    }
    if (!len) {
        formData.value.diplus_cmd = [];
    }
    formData.value.diplus_cmd.push(row);
}
const deleteCmd = (index) => {
    formData.value.diplus_cmd.splice(index, 1);
}
</script>

<template>
    <div class="tab-head">
        <div class="tab-head-title">远程控车</div>
    </div>

    <el-form ref="formRef" :model="formData" label-width="auto" label-position="top">
        <el-collapse>
            <sortable v-model="formData.diplus_cmd" handle=".collapse-title">
                <el-collapse-item v-for="(row, index) in formData.diplus_cmd" :key="row.uid" :name="row.uid">
                    <template #title>
                        <el-text class="collapse-title">{{ row.label }}</el-text>
                    </template>
                    <div class="inline-form-items">
                        <el-form-item label="按钮名称" :prop="`diplus_cmd[${index}].label`" :rules="rules">
                            <el-input v-model="row.label"/>
                        </el-form-item>
                        <el-form-item label="按钮颜色" :prop="`diplus_cmd[${index}].buttonType`" :rules="rules">
                            <el-select-x v-model="row.buttonType" :options="buttonTypeOptions" :clearable="false"/>
                        </el-form-item>
                        <el-form-item :prop="`diplus_cmd[${index}].needConfirm`" label="二次确认">
                            <el-checkbox v-model="row.needConfirm" label="发送指令前弹窗提醒，确认后再执行" />
                        </el-form-item>
                    </div>
                    <el-form-item label="远程小迪指令" :prop="`diplus_cmd[${index}].command`" :rules="rules">
                        <el-input v-model="row.command" type="textarea" :autosize="{ maxRows: 6 }"/>
                    </el-form-item>

                    <div class="collapse-footer">
                        <el-button type="success" @click="submitForm">保存</el-button>
                        <el-button type="danger"  @click="deleteCmd(index)">删除</el-button>
                    </div>
                </el-collapse-item>
            </sortable>
        </el-collapse>
    </el-form>

    <div style="margin-top: 30px">
        <el-text tag="div">
            1. 远程空车功能依赖于迪加APP，需要车机安装迪加 1.3.7b6 及以上版本。
        </el-text>
        <el-text tag="div">
            2. 添加常用的远程小迪指令，指令按钮将显示在系统首页。多条指令用逗号,分隔，或者每行一条指令。
        </el-text>
    </div>

    <page-footer>
        <el-button type="primary" style="width:150px" @click="submitForm()">保 存</el-button>
        <el-button type="success" plain @click="addCmd">+ 添加按钮</el-button>
    </page-footer>
</template>

<style scoped>
.collapse-title {
    font-weight: bold;
}
.collapse-footer {
    margin-top: 20px;
    display: flex;
    justify-content: right;
    gap: 20px;
}
</style>