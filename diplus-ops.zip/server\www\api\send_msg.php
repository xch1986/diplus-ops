<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';
require_once '../includes/wechat.php';
require_once '../includes/dingding.php';

$ajson = ['success' => 0, 'message' => ''];

// 非本地访问需验证身份
if ($_SERVER['HTTP_HOST'] != 'localhost:8018' && $_SERVER['HTTP_HOST'] != '127.0.0.1:8018') {
	$login = login(false);
	if (!$login) {
		$ajson['success'] = -1;
		$ajson['message'] = '未登录系统。';
		returnJson($ajson);
	}
}

$conn = db_conn();
$msgTo = readSettings($conn, 'global', 'msgTo');
if (!in_array($msgTo, ['wechat', 'dingding'])) {
  	$ajson['message'] = "发送信息失败！未启用接收报警信息。";
	returnJson($ajson);
}

$time = $_POST['time'] ?? date('Y-m-d H:i:s');
$text = $_POST['text'] ?? '';
$text = str_replace('\n', "\n", $text);
$content = "$time\n$text";

if ($msgTo == 'wechat') {
	$WECHAT_MSG = readSettings($conn, 'global', 'WECHAT_MSG');
	$msgData = [
		"msgtype" => "text",
		"text" => [
			"content" => $content
		]
	];
	$ret = sendToWechatGroup($WECHAT_MSG, $msgData);
	if ($ret !== true) {
		$ajson['message'] = "发送信息失败！$ret";
	} else {
		$ajson['success'] = 1;
		$ajson['message'] = "信息发送成功！";
	}
	returnJson($ajson);
}


if ($msgTo == 'dingding') {
	$content = str_replace("\n", "\n\n", $content);
	$DINGDING_MSG = readSettings($conn, 'global', 'DINGDING_MSG');
	$DINGDING_MSG_SECRET = readSettings($conn, 'global', 'DINGDING_MSG_SECRET');
	$msgData = [
		"msgtype" => "markdown", 
		"markdown" => [
			"title" => $time,
			"text" => $content
		]
	];
	$ret = sendToDingdingGroup($DINGDING_MSG, $DINGDING_MSG_SECRET, $msgData);
	if ($ret !== true) {
		$ajson['message'] = "发送信息失败！$ret";
	} else {
		$ajson['success'] = 1;
		$ajson['message'] = "信息发送成功！";
	}
	returnJson($ajson);
}


$ajson['message'] = "未发送任何信息！";
returnJson($ajson);
?>
