<script>
export default {
    // 定义name包含keep-alive，离开本页面再次返回时不刷新页面
    // 只在onActivated中更新数据
    name: 'sum_monthlyTrip_keep-alive'
}
</script>
<script setup>
import { GPS, getLocalAddress, loadAMap } from '/includes/map.js';
import echarts from '/includes/vue-components/echarts.vue';
import tripInfoCard from '/includes/vue-components/trip-info-card.vue';

const route = VueRouter.useRoute();
const date = Vue.ref(new Date(route.query.date ?? new Date().Format('YYYY-MM-01')));
const data = Vue.ref({});
const sumData = Vue.ref({});
const isMobile = Vue.ref(window.innerWidth < 550);

const getMonthlyTrip = async () => {
    const res = await axios({
        url: 'api/sum_monthlyTrip.php',
        method: 'get',
        params: {
            dateFrom: date.value.Format('YYYY-MM-01'),
            dateTo: new Date(date.value.getFullYear(), date.value.getMonth() + 1, 0).Format('YYYY-MM-DD')
        }
    });

    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    data.value = res.data.data;
}
const getSumData = async () => {
    const res = await axios({
        url: 'api/sum_tripInfo.php',
        method: 'get',
        params: {
            dateFrom: date.value.Format('YYYY-MM-01'),
            dateTo: new Date(date.value.getFullYear(), date.value.getMonth() + 1, 0).Format('YYYY-MM-DD')
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    sumData.value = res.data.data;
}


const setMonth = (val) => {
    if (val === 0) {
        date.value = new Date();
    } else {
        // 直接setMonth修改不会触发watch，这里转一下再赋值
        const d = new Date(date.value.toDateString());
        d.setMonth(d.getMonth() + val);
        date.value = d;
    }
}

// 只有keep-alive的页面生命周期中有onActivated
Vue.onActivated(() => {
    getMonthlyTrip();
    getSumData();
});

Vue.watch(() => date.value, () => {
    getMonthlyTrip();
    getSumData();
    selectedDate.value = null;
});

const chart_option = Vue.computed(() => {
	if (!data.value.monthlyTrip) return {};
    for (let row of data.value.monthlyTrip) {
        row.hevMileage = Math.round(Math.max(0, row.mileage - row.evMileage) * 10) / 10;
        row.elecConPer100 = Math.round(row.elecCon / row.mileage * 1000) / 10;
        row.cost = Math.round((row.elecCon * data.value.elec_price + row.fuelCon * data.value.fuel_price) * 100) / 100;
    }
    let d = new Date(date.value.toDateString());
	const min = d.Format('YYYY-MM-01');
    const max = new Date(d.getFullYear(), d.getMonth() + 1, 0).Format('YYYY-MM-DD');

    return {
		legend: {},
		grid: {
			left: '0',
			right: '0',
			containLabel: true
		},
		tooltip : {
            trigger: 'item',
            formatter: (params) => {
                let tips = `${new Date(params.value.travelDate).Format('YYYY年M月D日')}<br/>`;
                tips += `纯电里程: ${params.value.evMileage}<br/>`;
                tips += `混动里程: ${params.value.hevMileage}<br/>`;
                tips += `油电费用: ${params.value.cost}<br/>`;
                tips += `百公里电耗: ${params.value.elecConPer100}`;
                return tips;
            }
        },
		dataset: {
            source: data.value.monthlyTrip,
            dimensions: [
                { name: 'travelDate', type: 'time' },
                'evMileage',
                'hevMileage',
                'cost',
                'elecConPer100'
            ]
		},
        xAxis: {
            type: 'time',
            min: min,
            max: max,
            axisLabel: {
                formatter: '{dd}',
                interval: 0
            },
            axisPointer: {
                label: {
                    formatter: function(params) {
                        return params.value;
                    }
                }
            }
        },
		yAxis: [
			{
				type: 'value',
				name: '公里'
			},
			{
				type: 'value',
				name: '元',
                splitLine: {
                    show: false
                }
			}
		],
		series: [
            {
                name: '纯电里程',
                type: 'bar',
                barMaxWidth: 10,
                stack: 'total',
                encode: { x: 'travelDate', y: 'evMileage' },
                itemStyle: {
                    color: '#67C23A'
                }
            },
            {
                name: '混动里程',
                type: 'bar',
                barMaxWidth: 10,
                stack: 'total',
                encode: { x: 'travelDate', y: 'hevMileage' },
                itemStyle: {
                    color: 'orangered'
                }
            },
            {
                name: '油电费用',
                type: 'line',
                yAxisIndex: 1,
                encode: { x: 'travelDate', y: 'cost' },
                lineStyle: {
                    color: 'orange',
                    width: 4
                }
            },
            {
                name: '百公里电耗',
                type: 'line',
                yAxisIndex: 1,
                encode: { x: 'travelDate', y: 'elecConPer100' },
                lineStyle: {
                    color: '#409EFF',
                    width: 4
                }
            }
		]
	};
});

const selectedDate = Vue.ref();
const tripList = Vue.ref({});
const onClickChart = async (params) => {
    selectedDate.value = params.data.travelDate;
    const res = await axios({
        url: 'api/sum_tripList.php',
        method: 'get',
        params: {
            date: selectedDate.value
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    tripList.value = res.data.data;

    const AMap = await loadAMap(['AMap.Geocoder']);   
    for (const row of tripList.value.tripList) {
        if (row.position_start?.longitude) {
            // WGS84坐标转GCJ-02坐标
            const gpsPoint = GPS.gcj_encrypt(row.position_start.latitude, row.position_start.longitude);
            const long = Math.round(gpsPoint.lon * 1000000) / 1000000;
            const lat = Math.round(gpsPoint.lat * 1000000) / 1000000;
            row.gcj_location_start = { long: long, lat: lat };
            row.address_start = await getLocalAddress(AMap, [ long, lat ]);
        }
        if (row.position_end?.longitude) {
            // WGS84坐标转GCJ-02坐标
            const gpsPoint = GPS.gcj_encrypt(row.position_end.latitude, row.position_end.longitude);
            const long = Math.round(gpsPoint.lon * 1000000) / 1000000;
            const lat = Math.round(gpsPoint.lat * 1000000) / 1000000;
            row.gcj_location_end = { long: long, lat: lat };
            row.address_end = await getLocalAddress(AMap, [ long, lat ]);
        }
    }
}
</script>

<template>
    <div class="tab-head">
        <el-space size="large" class="tab-head-left">
            <div class="tab-head-title">月行程</div>
        </el-space>
        <el-space size="large">
            <el-button type="primary" plain @click="setMonth(-1)"><</el-button>
            <el-date-picker v-model="date" type="month" :editable="false" style="width: 150px" format="YYYY年M月"/>
            <el-button type="primary" plain @click="setMonth(1)">></el-button>
        </el-space>
    </div>
    <Teleport to=".tab-head-left" :disabled="isMobile">
        <el-space :style="isMobile ? 'margin-bottom: 20px' : ''">
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.mileage || 0 }}
                </el-text> <el-text>公里</el-text>
            </div>
            <div>
                <el-text type="warning" size="large">
                    {{ Math.round((sumData.elecCon * sumData.elec_price + sumData.fuelCon * sumData.fuel_price) * 100) / 100 }}
                </el-text> <el-text>元</el-text>
            </div>
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.mileage ? Math.round(sumData.totalFuelCon / sumData.mileage * 1000) / 10 : 0 }}
                </el-text> <el-text>L/百公里</el-text>
            </div>
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.mileage ? Math.round(sumData.totalElecCon / sumData.mileage * 1000) / 10 : 0 }}
                </el-text> <el-text>度/百公里</el-text>
            </div>
        </el-space>
    </Teleport>

	<div class="slide" style="margin-bottom: 10px">
		<echarts :option="chart_option" :on="{ event: 'click', callback: onClickChart }"/>
	</div>


    <div v-if="selectedDate" class="selected-date">
        {{ new Date(selectedDate).Format('YYYY月MM月DD日') }}
    </div>
    <div v-if="selectedDate" class="container">
        <trip-info-card
            v-for="(row, index) in tripList.tripList"
            :key="index"
            :data="row"
        />
    </div>
</template>

<style scoped>
.selected-date {
    font-weight: bold;
    color: #E6A23C;
    padding: 10px;
}
.echarts {
    min-width: 600px;
    height: 600px !important;
}
@media screen and (max-height: 800px) {
    .echarts {
        height: 400px !important;
    }
}
.container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 40px;
    width: 100%;
    margin-bottom: 40px;
}
.container .trip-info-card {
    position: relative;
}
</style>