<script setup>
import elSelectX from '/includes/vue-components/el-select-x.vue';

const formData = Vue.ref({});
const getData = async () => {
    const res = await axios({
        url: 'api/settings_maint.php',
        method: 'get',
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value = res.data.data;
}
getData();

const formRef = Vue.ref();
const rules = Vue.ref({ required: true, trigger: 'blur', message: '此项不能为空' });
const submitForm = async () => {
    const valid = await formRef.value.validate((valid) => { return valid });
    if (!valid) {
        ElementPlus.ElMessageBox.alert("请确认表单填写完整再提交！");
        return;
    }

    if ((formData.value.show_maint || formData.value.send_maint_noti)
        && !formData.value.month_interval
        && !formData.value.mileage_interval
    ) {
        ElementPlus.ElMessageBox.alert("如需保养提醒，保养时间、里程间隔至少需要设置1项！");
        return;
    }

    const res = await axios({
        url: 'api/settings_maint.php',
        method: 'post',
        data: formData.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getData();
}
const findTripInfo = async (val) => {
    const res = await axios({
        url: 'api/settings_maint.php',
        method: 'get',
        params: {
            action: 'getTripInfo',
            date: formData.value.lastest_date
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value.lastest_mileage = res.data.data.mileage;
    ElementPlus.ElMessage.success('已自动填写最近保养里程信息，请核对！');
}
</script>

<template>
    <div class="tab-head">
        <div class="tab-head-title">维护保养</div>
    </div>

    <el-form ref="formRef" :model="formData" label-width="auto" label-position="top">
        <el-card header="保养设置">
            <div class="inline-form-items">
                <el-form-item prop="month_interval">
                    <template #label>
                        保养周期(月)
                        <el-tooltip placement="top-start" content="如不需要按周期提醒请设为0">
                            <span class="iconfont icon-question-circle tooltip"></span>
                        </el-tooltip>
                    </template>
                    <el-input-number v-model="formData.month_interval" :min="0"/>
                </el-form-item>
                <el-form-item prop="mileage_interval">
                    <template #label>
                        保养总里程间隔(公里)
                        <el-tooltip placement="top-start" content="如不需要按里程提醒请设为0">
                            <span class="iconfont icon-question-circle tooltip"></span>
                        </el-tooltip>
                    </template>
                    <el-input-number v-model="formData.mileage_interval" :min="0"/>
                </el-form-item>
            </div>
            <el-form-item prop="show_maint">
                <el-switch v-model="formData.show_maint" active-text="在首页显示保养提醒" />
            </el-form-item>
            <el-form-item prop="send_maint_noti">
                <el-switch v-model="formData.send_maint_noti" active-text="提前10天或100公里发送保养提醒到微信/钉钉" />
                <el-text v-if="formData.noti_sent">({{ formData.noti_sent }} 已发送提醒)</el-text>
            </el-form-item>
        </el-card>
        <el-card header="上次保养数据">
            <el-text tag="div" style="margin-bottom: 30px">每次完成保养后请在这里输入保养日期和里程，这样才能正确提醒下次保养。</el-text>
            <div class="inline-form-items">
                <el-form-item prop="lastest_date" label="保养日期" :rules="formData.month_interval ? rules : null">
                    <el-date-picker v-model="formData.lastest_date" value-format="YYYY-MM-DD" :editable="false" @change="findTripInfo"/>
                </el-form-item>
                <el-form-item prop="lastest_mileage" label="总里程(公里)" :rules="formData.mileage_interval ? rules : null">
                    <el-input-number v-model="formData.lastest_mileage" :min="0"/>
                </el-form-item>
            </div>
        </el-card>
    </el-form>
   
    <page-footer>
        <el-button type="primary" style="width:150px" @click="submitForm()">保 存</el-button>
    </page-footer>
</template>

<style scoped>
.el-card {
    margin-bottom: 30px;
}
.tooltip {
    color: orangered;
    cursor: pointer;
}
</style>