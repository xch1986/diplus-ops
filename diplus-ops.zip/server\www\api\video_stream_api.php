<?php
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$login = login();

$key = @$_GET['key'];
if (empty($key)) {
    http_response_code(400);
    die("Key is required.");
}

$conn = db_conn();
$DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
$conn = null;

$apiUrl = "http://localhost:8988/api/videoStream?key=$key&auth=".urlencode($DIPLUS_AUTH);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, false); // 直接输出到浏览器
curl_setopt($ch, CURLOPT_HEADER, false); // 不输出 header
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); // 设置连接超时为 5 秒

// 设置最低传输速度为 1024 字节/秒，持续 10 秒
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 1024);
curl_setopt($ch, CURLOPT_LOW_SPEED_TIME, 5);

// 获取客户端的 Range 头
if (isset($_SERVER['HTTP_RANGE'])) {
    $range = $_SERVER['HTTP_RANGE'];
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Range: $range"]);
}

// 设置从 API 获取的 header
curl_setopt($ch, CURLOPT_HEADERFUNCTION, function($curl, $header) {
    // 将 API 返回的 header 转发给客户端
    header($header);
    return strlen($header);
});

curl_exec($ch);

if (curl_errno($ch)) {
    http_response_code(500);
    die("Failed to fetch video stream.");
}

curl_close($ch);
?>

