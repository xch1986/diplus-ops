<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';
require_once '../includes/diplus_config.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];

$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}
$conn = db_conn();

$post = json_decode_x(file_get_contents('php://input'));
if ($post) {
    $DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
    $trigger_for_tracking = $post['trigger_for_tracking'] ?: 0;
    if ($trigger_for_tracking) {
        $res = setTriggerTracking($DIPLUS_AUTH);
        if (!$res) {
            $ajson['message'] .= '设置自动化失败！';
        }
    } else {
        $res = enableTriggerTracking(false, $DIPLUS_AUTH);
        if (!$res) {
            $ajson['message'] .= '关闭自动化失败！';
        }
    }
    
    writeSettings($conn, 'global', 'snapshot', $post['snapshot']);
    writeSettings($conn, 'diplus', 'trigger_for_tracking', $trigger_for_tracking);

	$ajson['message'] .= '数据保存成功！';
    $ajson['success'] = 1;
    returnJson($ajson);
}


$returnData = [];
$returnData['snapshot'] = readSettings($conn, 'global', 'snapshot') ?: 'diplus';
$returnData['trigger_for_tracking'] = readSettings($conn, 'diplus', 'trigger_for_tracking') == 1;
$ajson['data'] = $returnData;
$ajson['success'] = 1;
returnJson($ajson);
?>