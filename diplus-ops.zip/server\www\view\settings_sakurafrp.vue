<script setup>
const formData = Vue.ref({});
const getData = async () => {
    const res = await axios({
        url: 'api/sakurafrp.php',
        method: 'get',
        params: {
            action: 'getData'
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value = res.data.data;
}
getData();

const formRef = Vue.ref();
const rules = Vue.ref({ required: true, trigger: 'blur', message: '此项不能为空' });
const submitForm = async () => {
    const valid = await formRef.value.validate((valid) => { return valid });
    if (!valid) {
        ElementPlus.ElMessageBox.alert("请确认表单填写完整再提交！");
        return;
    }
    const res = await axios({
        url: 'api/sakurafrp.php',
        method: 'post',
        params: {
            action: 'saveData'
        },
        data: formData.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getData();
}

const appi = async (appName, action) => {
	const res = await axios({
		url: `api/${appName}.php`,
		method: 'get',
		params: {
			action: action 
		}
	});
	if (res.data.success < 1) {
		ElementPlus.ElMessage.error(res.data.message);
		if (res.data.success == -1) {
			gotoLogin();
		}
		return;
	}
	ElementPlus.ElMessage.success(res.data.message);
	getData();
}
const appiAction = async (appName, action) => {
	await submitForm();
	await appi(appName, action);
}
const appiStop = async (appName) => {
	let res = await ElementPlus.ElMessageBox
		.confirm("如你正在远程连接车机，停止网络后可能会失去连接。确定要停止吗？")
		.catch(() => {});
	if (res != 'confirm') return;
	appiAction(appName, 'stop');
}
</script>

<template>
    <el-form ref="formRef" :model="formData" label-width="auto" label-position="top">
        <div class="tab-head">
            <div class="tab-head-title">樱花 Frp</div>
            <div>
                <el-switch v-model="formData.sakurafrpOn" active-text="启用"/>
            </div>
        </div>

        <div v-if="formData.sakurafrpOn">
            <el-form-item prop="sakurafrp_config" label="樱花Frp配置参数" :rules="rules">
                <el-input v-model="formData.sakurafrp_config"/>
            </el-form-item>

            <div class="info-div">
                1. <el-link type="primary" href="https://www.natfrp.com" target="_blank">樱花Frp官网</el-link>:
                基于Frp二次开发，不需要自己的服务器，限量免费
            </div>
            <div class="info-div">
                2. 可从 <el-link type="primary" href="https://www.natfrp.com/tunnel" target="_blank">樱花Frp隧道列表</el-link>
                页面复制配置参数，格式为: <el-text type="warning">访问密码:隧道ID1,隧道ID2</el-text>...。
            </div>
            <div class="info-div">
                3. 微信有可能会拦截樱花Frp的网址，如果无法从微信中打开，建议尝试更换服务器或者改用easytier/原版Frp/lucky(ipv6动态域名)等远程方案。
            </div>
            <div class="info-div">
                4. <el-text type="warning">参数修改后需要重启樱花Frp才能生效！</el-text>
            </div>

            <div class="button-bar">
                <el-button type="danger" @click="appiStop('sakurafrp')" :disabled="!formData.sakurafrp_is_running">
                    停止Frp
                </el-button>
                <el-button
                    type="success"
                    @click="appiAction('sakurafrp', 'start')"
                    :disabled="formData.sakurafrp_is_running || !formData.sakurafrp_version"
                >
                    启动Frp
                </el-button>
                <el-button type="primary" @click="appiAction('sakurafrp', 'restart')" :disabled="!formData.sakurafrp_is_running">
                    重启Frp
                </el-button>
                <div>
                    <el-text v-if="formData.sakurafrp_version == 0">樱花Frp 未安装</el-text>
                    <el-text v-else>版本: {{ formData.sakurafrp_version }}</el-text>
                </div>
                <img v-if="formData.sakurafrp_is_running" src="/media/running1.gif" style="height:50px">
                <div v-else class="iconfont icon-running" style="font-size: 1.8em;color: gray"></div>
            </div>
        </div>
    </el-form>

    <page-footer>
        <el-button type="primary" style="width:150px" @click="submitForm()">保 存</el-button>
    </page-footer>
</template>

<style scoped>
</style>