<script>
export default {
    // 定义name包含keep-alive，离开本页面再次返回时不刷新页面
    // 只在onActivated中更新数据
    name: 'sum_tripInfo_keep-alive'
}
</script>
<script setup>
import { GPS, loadAMap, getAddress, shortenAddress } from '/includes/map.js';
import tripInfoCard from '/includes/vue-components/trip-info-card.vue';

const route = VueRouter.useRoute();
const date = Vue.ref(route.query.date ? new Date(route.query.date) : new Date());
const data = Vue.ref({});
const sumData = Vue.ref({});
const isMobile = Vue.ref(window.innerWidth < 550);

const dateFormat = Vue.computed(() => {
    if (date.value.getFullYear() == new Date().getFullYear()) {
        return 'M月D日';
    } else {
        return 'YYYY年M月D日';
    }
});
const getTripList = async () => {
    const res = await axios({
        url: 'api/sum_tripList.php',
        method: 'get',
        params: {
            date: date.value.Format('YYYY-MM-DD')
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    data.value = res.data.data;

    const AMap = await loadAMap(['AMap.Geocoder']);
    for (const row of data.value.tripList) {
        let address_start, address_end;
        if (row.position_start?.longitude) {
            // WGS84坐标转GCJ-02坐标
            const gpsPoint = GPS.gcj_encrypt(row.position_start.latitude, row.position_start.longitude);
            const long = Math.round(gpsPoint.lon * 1000000) / 1000000;
            const lat = Math.round(gpsPoint.lat * 1000000) / 1000000;
            row.gcj_location_start = { long: long, lat: lat };
            address_start = await getAddress(AMap, [ long, lat ]);
            address_start = address_start.regeocode.formattedAddress;
        }
        if (row.position_end?.longitude) {
            // WGS84坐标转GCJ-02坐标
            const gpsPoint = GPS.gcj_encrypt(row.position_end.latitude, row.position_end.longitude);
            const long = Math.round(gpsPoint.lon * 1000000) / 1000000;
            const lat = Math.round(gpsPoint.lat * 1000000) / 1000000;
            row.gcj_location_end = { long: long, lat: lat };
            address_end = await getAddress(AMap, [ long, lat ]);
            address_end = address_end.regeocode.formattedAddress;
        }
        if (address_start || address_end) {
            [ row.address_start, row.address_end ] = shortenAddress(address_start, address_end);
        }
    }
}

const getSumData = async () => {
    const res = await axios({
        url: 'api/sum_tripInfo.php',
        method: 'get',
        params: {
            date: date.value.Format('YYYY-MM-DD')
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    sumData.value = res.data.data;
}

const setDate = (val) => {
    if (val === 0) {
        date.value = new Date();
    } else {
        // 直接setDate修改不会触发watch，这里转一下再赋值
        const d = new Date(date.value.toDateString());
        d.setDate(d.getDate() + val);
        date.value = d;
    }
}

// 只有keep-alive的页面生命周期中有onActivated
Vue.onActivated(() => {
    getTripList();
    getSumData();
});

Vue.watch(() => date.value, () => {
    getTripList();
    getSumData();
});
</script>

<template>
    <div class="tab-head">
        <el-space size="large" class="tab-head-left">
            <div class="tab-head-title">日行程</div>
        </el-space>
        <el-space size="large">
            <el-button type="primary" plain @click="setDate(-1)"><</el-button>
            <el-date-picker v-model="date" :editable="false" style="width: 150px" :format="dateFormat"/>
            <el-button type="primary" plain @click="setDate(1)">></el-button>
        </el-space>
    </div>
    <Teleport to=".tab-head-left" :disabled="isMobile">
        <el-space :style="isMobile ? 'margin-bottom: 20px' : ''">
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.mileage || 0}}
                </el-text> <el-text>公里</el-text>
            </div>
            <div>
                <el-text type="warning" size="large">
                    {{ Math.round((sumData.elecCon * sumData.elec_price + sumData.fuelCon * sumData.fuel_price) * 100) / 100 }}
                </el-text> <el-text>元</el-text>
            </div>
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.mileage ? Math.round(sumData.totalFuelCon / sumData.mileage * 1000) / 10 : 0 }}
                </el-text> <el-text>L/百公里</el-text>
            </div>
            <div>
                <el-text type="warning" size="large">
                    {{ sumData.mileage ? Math.round(sumData.totalElecCon / sumData.mileage * 1000) / 10 : 0 }}
                </el-text> <el-text>度/百公里</el-text>
            </div>
        </el-space>
    </Teleport>

    <div class="container">
        <trip-info-card
            v-for="(row, index) in data.tripList"
            :key="index"
            :data="row"
        />
    </div>
</template>

<style scoped>
.container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 40px;
    width: 100%;
    margin-bottom: 40px;
}
.container .trip-info-card {
    position: relative;
}
</style>