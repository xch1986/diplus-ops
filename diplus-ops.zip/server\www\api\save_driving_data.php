<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';
require_once '../includes/driving_data_params.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];

// 非本地访问需验证身份
if ($_SERVER['HTTP_HOST'] != 'localhost:8018' && $_SERVER['HTTP_HOST'] != '127.0.0.1:8018') {
	$login = login(false);
	if (!$login) {
		$ajson['success'] = -1;
		$ajson['message'] = '未登录系统。';
		returnJson($ajson);
	}
}
$timestamp = $_GET['timestamp'] ?? time() * 1000;

$conn = db_conn();
$DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
$diplus_params = json_decode_x(readSettings($conn, 'diplus', 'diplus_params'));
$PARAMS = array_merge(['timestamp' => $timestamp], $DRIVING_DATA_PARAMS);

$aText = [];
foreach ($PARAMS as $key => $param) {
    $aText[] = "$key|$param";
}

$params = array_map(
    fn($v) => mb_substr($v, 1, mb_strlen($v, 'utf-8') - 2, 'utf-8'),
    $DRIVING_DATA_PARAMS
);
$FIXED_DRIVING_PARAMS = array_values($params);

$custom_params = [];
foreach ($diplus_params as $row) {
    $name = @$row['name'];
    // 排除内置固定要保存的参数
    if ((@$row['save'] || @$row['monitor']) && !in_array($name, $FIXED_DRIVING_PARAMS)) {
        $custom_params[$row['name']] = $row['dataType'] === 'number' ? "{".$name."}" : "[$name]";
    }
}
foreach ($custom_params as $key => $param) {
    $aText[] = "$key|$param";
}

$text = implode('|!|', $aText);
$url = "http://localhost:8988/api/getDiPars";
$url .= "?text=".urlencode($text);
$url .= "&auth=".urlencode($DIPLUS_AUTH);
$context = stream_context_create([
    'http' => [
        'timeout' => 5
    ]
]);
$res = @file_get_contents($url, false, $context);
$d = json_decode_x($res);
$data = [];
if (@$d['success'] === true || !empty($d['val'])) {
    $params = explode('|!|', $d['val']);
    foreach ($params as $r) {
        $arr = explode('|', $r, 2);
        if (count($arr) === 2 && $arr[0]) {
            $data[$arr[0]] = $arr[1];
        }
    }
}
if (!$data) {
    $ajson['message'] = "获取行驶数据失败！";
    returnJson($ajson);    
}

$arr = explode(',', $data['location']);
$data['location'] = [
    'longitude' => (float)$arr[0],
    'latitude' => (float)@$arr[1],
    'bearing' => (float)@$arr[2],
    'altitude' => (float)@$arr[3]
];

foreach ($custom_params as $key => &$param) {
    $param = isset($data[$key]) ? $data[$key] : '';
}
unset($param);

$keys = array_keys($PARAMS);
$fields = implode(',', array_map(fn($v): string => "`$v`", $keys));
$values = implode(',',array_map(fn($v): string => ":$v", $keys));
$fields .= ',`custom`';
$values .= ',:custom';
$sql = "INSERT INTO driving_data ($fields) VALUES ($values)";
$p = [
    ':timestamp' => $timestamp,
    ':location' => json_encode_x($data['location']),
    ':mileage' => @$data['mileage'] ? $data['mileage'] * 1 : 0,
    ':speed' => @$data['speed'] ? $data['speed'] * 1 : 0,
    ':gear' => @$data['gear'],
    ':brake_depth' => @$data['brake_depth'] ? $data['brake_depth'] * 1 : 0,
    ':accelerator_depth' => @$data['accelerator_depth'] ? $data['accelerator_depth'] * 1 : 0,
    ':lane_keep_status' => @$data['lane_keep_status'],
    ':cruise_switch' => @$data['cruise_switch'],
    ':acc_status' => @$data['acc_status'],
    ':tire_pressure_fl' => @$data['tire_pressure_fl'] ? $data['tire_pressure_fl'] * 1 : 0,
    ':tire_pressure_fr' => @$data['tire_pressure_fr'] ? $data['tire_pressure_fr'] * 1 : 0,
    ':tire_pressure_rl' => @$data['tire_pressure_rl'] ? $data['tire_pressure_rl'] * 1 : 0,
    ':tire_pressure_rr' => @$data['tire_pressure_rr'] ? $data['tire_pressure_rr'] * 1 : 0,
    ':low_beam' => @$data['low_beam'],
    ':high_beam' => @$data['high_beam'],
    ':total_power_consumption' => @$data['total_power_consumption'] ? $data['total_power_consumption'] * 1 : 0,
    ':battery_percent' => @$data['battery_percent'] ? $data['battery_percent'] * 1 : 0,
    ':total_fuel_consumption' => @$data['total_fuel_consumption'] ? $data['total_fuel_consumption'] * 1 : 0,
    ':fuel_percent' => @$data['fuel_percent'] ? $data['fuel_percent'] * 1 : 0,
    ':custom' => json_encode_x($custom_params)
];

$termux_dir = '/storage/emulated/0/Termux';
$conn2 = db_conn($err, "$termux_dir/db.db");

// 车辆静止且里程无变化时跳过（避免驻车垃圾点，20260929 恢复触发后加入）
$sqlChk = "SELECT mileage FROM driving_data ORDER BY rowid DESC LIMIT 1";
$rChk = db_query_row($conn2, $sqlChk);
$lastMile = $rChk ? ($rChk['mileage'] * 1) : -1;
$curSpeed = (float)@$data['speed'];
$curMile = (float)@$data['mileage'];
if ($curSpeed <= 0 && $lastMile >= 0 && $curMile == $lastMile) {
    $ajson['success'] = 1;
    $ajson['message'] = '车辆静止，跳过保存';
    returnJson($ajson);
}

$ret = db_exec($conn2, $sql, $p, $err);
if (!$ret) {
    $ajson['message'] = "保存行驶数据失败！$err";
    returnJson($ajson);
}

// 清理2年前的数据
$date = date('Y-m-d', strtotime('-2 years'));
$sql = "DELETE FROM driving_data WHERE date(`timestamp` / 1000, 'unixepoch', 'localtime') < $date";
db_exec($conn2, $sql);
$conn2 = null;

$ajson['success'] = 1;
$ajson['message'] = '行驶数据保存成功！';
returnJson($ajson);
?>
