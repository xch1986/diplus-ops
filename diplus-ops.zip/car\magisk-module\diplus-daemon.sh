#!/data/data/com.termux/files/usr/bin/bash
# diplus-daemon v5.3 - Magisk daemon (root, 30s, 502探测, openlist termux, frpc锁刷新, SD自动重挂, crond保活, fuse自愈)
# v5.1 2026-09-29: 合并 v4(crond+fuse自愈) + v5(USB hub断电处理), 记录仪为USB存储非mmcblk
export PATH=/data/data/com.termux/files/usr/bin:$PATH
export HOME=/data/data/com.termux/files/home
export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib
LOG=$HOME/daemon.log
LOCK=/data/local/tmp/diplus-daemon.pid
if [ -f "$LOCK" ]; then
  LP=$(cat $LOCK 2>/dev/null)
  if [ -n "$LP" ] && kill -0 $LP 2>/dev/null && cat /proc/$LP/cmdline 2>/dev/null | grep -q diplus-daemon.sh; then
    exit 0
  fi
fi
echo $$ > $LOCK
echo "=== diplus-daemon v5.3 start $(date) ===" >> $LOG
while true; do
  if ! curl -s -o /dev/null --max-time 3 http://127.0.0.1:8018/ 2>/dev/null; then
    echo "$(date) 拉起nginx" >> $LOG
    rm -f /data/data/com.termux/files/usr/tmp/nginx.pid
    /data/data/com.termux/files/usr/bin/nginx -c $HOME/nginx/nginx.conf >> $LOG 2>&1
    sleep 3
  fi
  if [ -z "$(pidof php-fpm)" ]; then
    echo "$(date) 拉起php-fpm" >> $LOG
    rm -f /data/data/com.termux/files/usr/var/run/php-fpm.pid /data/data/com.termux/files/usr/var/run/php-fpm.sock
    /data/data/com.termux/files/usr/bin/php-fpm -y /data/data/com.termux/files/usr/etc/php-fpm.conf -D --allow-to-run-as-root >> $LOG 2>&1
    sleep 3
  fi
  if [ "$(curl -s -o /dev/null -w %{http_code} --max-time 5 http://127.0.0.1:8018/api/settings_general.php 2>/dev/null)" = "502" ]; then
    echo "$(date) php-fpm 502异常, 重建" >> $LOG
    pkill php-fpm 2>/dev/null
    sleep 2
    rm -f /data/data/com.termux/files/usr/var/run/php-fpm.pid /data/data/com.termux/files/usr/var/run/php-fpm.sock
    /data/data/com.termux/files/usr/bin/php-fpm -y /data/data/com.termux/files/usr/etc/php-fpm.conf -D --allow-to-run-as-root >> $LOG 2>&1
    sleep 3
  fi
  FRPCPID=$(pidof frpc 2>/dev/null | head -1)
  if [ -z "$FRPCPID" ]; then
    echo "$(date) 拉起frpc" >> $LOG
    bash $HOME/boot/frpc.sh >> $LOG 2>&1
    sleep 3
  else
    echo "$FRPCPID" > $HOME/frp/frpc.pid 2>/dev/null
  fi
  if ! curl -s -o /dev/null --max-time 3 http://127.0.0.1:5244/ 2>/dev/null; then
    echo "$(date) 拉起openlist" >> $LOG
    run-as com.termux sh -c "export PATH=$PATH; export HOME=$HOME; export LD_LIBRARY_PATH=$LD_LIBRARY_PATH; nohup bash $HOME/boot/openlist.sh > $HOME/openlist.log 2>&1 &" >> $LOG 2>&1
    sleep 3
  fi
  if ! curl -s -o /dev/null --max-time 3 http://127.0.0.1:16601/ 2>/dev/null; then
    echo "$(date) 拉起lucky" >> $LOG
    bash $HOME/boot/lucky.sh >> $LOG 2>&1
    sleep 3
  fi
  # crond 保活(推送触发): 车机重启后模块版不拉起crond, 推送会停
  if [ -z "$(pidof crond)" ]; then
    echo "$(date) 拉起crond" >> $LOG
    /data/data/com.termux/files/usr/bin/crond -i
    sleep 2
  fi
  # ===== 8988 数据口保活 (2026-10-01): 迪加app被系统禁用/杀掉后自动恢复, 带冷却 =====
  if ! curl -s -o /dev/null --max-time 3 http://127.0.0.1:8988/ 2>/dev/null; then
    DLAST=/data/local/tmp/.dija_last
    NOW=$(date +%s)
    if [ ! -f $DLAST ] || [ $(( NOW - $(cat $DLAST) )) -ge 300 ]; then
      date +%s > $DLAST
      echo "$(date) 8988不在, 恢复迪加app" >> $LOG
      pm enable com.van.diplus 2>/dev/null
      am startservice -n com.van.diplus/.service.MainService 2>/dev/null
      am startservice -n com.van.diplus/.service.SignedLogicHostService 2>/dev/null
      am start -n com.van.diplus/.activity.NaviActivity 2>/dev/null
    fi
  fi
  # ===== 内部存储 fuse 自愈 v3 (2026-10-02): 开机宽限+SELinux放行+重挂+bind+冷却 =====
  UP=$(cut -d. -f1 /proc/uptime 2>/dev/null)
  if [ "${UP:-0}" -lt 240 ]; then
    : # 开机宽限期: 不碰存储, 避免干扰系统启动导致中控黑屏
  elif ! ls /storage/emulated/0/vandiplus/ >/dev/null 2>&1; then
    FLAST=/data/local/tmp/.fuse_last
    NOW=$(date +%s)
    if [ ! -f $FLAST ] || [ $(( NOW - $(cat $FLAST) )) -ge 120 ]; then
      date +%s > $FLAST
      echo "$(date) 内部存储异常, 尝试恢复" >> $LOG
      if [ "$(getenforce 2>/dev/null)" = "Enforcing" ] && dumpsys mount 2>/dev/null | grep -q "emulated unmountable"; then
        echo "$(date) emulated卷不可挂载, 临时放行SELinux" >> $LOG
        setenforce 0 2>/dev/null
        echo "$(date) SELinux状态: $(getenforce 2>/dev/null)" >> $LOG
      fi
      sm unmount emulated 2>/dev/null; sleep 2; sm mount emulated 2>/dev/null
      sleep 8
      if ! ls /storage/emulated/0/vandiplus/ >/dev/null 2>&1 && ls /mnt/runtime/full/emulated/0/ >/dev/null 2>&1; then
        echo "$(date) user层视图缺失, bind完整视图" >> $LOG
        mkdir -p /storage/emulated/0 2>/dev/null
        mount --bind /mnt/runtime/full/emulated/0 /storage/emulated/0 2>/dev/null
        sleep 2
      fi
      if ls /storage/emulated/0/vandiplus/ >/dev/null 2>&1; then
        echo "$(date) 内部存储恢复OK" >> $LOG
      else
        echo "$(date) 内部存储恢复失败" >> $LOG
      fi
    fi
  fi
  # ---- SD 检查(85D5-14FD 记录仪USB存储), 带300s冷却 ----
  SDOK=""
  [ -d /storage/85D5-14FD ] && SDOK=1
  if [ -z "$SDOK" ]; then
    SLAST=/data/local/tmp/.sd_last
    NOW=$(date +%s)
    if [ -f $SLAST ] && [ $(( NOW - $(cat $SLAST) )) -lt 300 ]; then
      SDOK="cd"
    else
      date +%s > $SLAST
    fi
  fi
  if [ -z "$SDOK" ]; then
    echo "$(date) SD未挂载, 尝试恢复" >> $LOG
    # 1) USB hub 可能被系统省电断电(usb_pwr_en=0): 切 host 模式重新上电
    if ! ls /sys/bus/usb/devices/1-1 >/dev/null 2>&1; then
      echo "$(date) USB设备不在, 切host模式重新上电hub" >> $LOG
      echo host > /sys/devices/platform/soc/4e00000.ssusb/mode 2>/dev/null
      sleep 6
    fi
    SDOK2=""
    [ -d /storage/85D5-14FD ] && SDOK2=1
    if [ -n "$SDOK2" ]; then
      echo "$(date) SD重挂成功(模式切换后)" >> $LOG
    else
      # 2) 可移动块设备在但未挂载: 不重启vold(会打断内部存储+可致中控黑屏), 只USB重扫
      REMOV=$(ls /sys/block/ 2>/dev/null | while read b; do r=$(cat /sys/block/$b/removable 2>/dev/null); [ "$r" = "1" ] && echo yes && break; done)
      if [ "$REMOV" = "yes" ]; then
        echo "$(date) SD可移动设备在但未挂载, 触发USB重扫(不重启vold)" >> $LOG
        for h in /sys/class/scsi_host/host*; do echo "- - -" > $h/scan 2>/dev/null; done
        sleep 5
      else
        # 3) 无设备: USB 重扫 + SCSI
        echo "$(date) SD块设备不存在, 触发USB重扫" >> $LOG
        echo 0 > /sys/bus/usb/devices/usb1/authorized 2>/dev/null
        echo 0 > /sys/bus/usb/devices/usb2/authorized 2>/dev/null
        sleep 2
        echo 1 > /sys/bus/usb/devices/usb1/authorized 2>/dev/null
        echo 1 > /sys/bus/usb/devices/usb2/authorized 2>/dev/null
        for h in /sys/class/scsi_host/host*; do echo "- - -" > $h/scan 2>/dev/null; done
        sleep 5
      fi
    fi
    SDOK3=""
    [ -d /storage/85D5-14FD ] && SDOK3=1
    if [ -n "$SDOK3" ]; then
      echo "$(date) SD重挂成功" >> $LOG
    else
      echo "$(date) SD恢复失败(可能需物理重插/记录仪上电)" >> $LOG
    fi
  fi
  sleep 30
done
