<script setup>
import elSelectX from '/includes/vue-components/el-select-x.vue';

const formData = Vue.ref({});
const data = Vue.ref({});
const getData = async () => {
    const res = await axios({
        url: 'api/easytier.php',
        method: 'get',
        params: {
            action: 'getData'
        }
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value = res.data.formData;
    data.value = res.data.data;
}
getData();

const etPearOptions = [
    { value: 'tcp://public.easytier.top:11010', label: '官方-广东 tcp://public.easytier.top:11010' },
    { value: 'tcp://public.easytier.cn:11010', label: '官方 tcp://public.easytier.cn:11010' },
    { value: 'tcp://et.gbc.moe:11010', label: '浙江宁波 tcp://et.gbc.moe:11010' },
    { value: 'tcp://turn.sc.629957.xyz:11010', label: '四川成都 tcp://turn.sc.629957.xyz:11010' },
    { value: 'tcp://103.194.107.246:11010', label: '中国香港 tcp://103.194.107.246:11010' },
    { value: 'tcp://119.23.65.180:11010', label: '广东深圳 tcp://119.23.65.180:11010' },
    { value: 'tcp://et.993555.xyz:11010', label: '浙江金华 tcp://et.993555.xyz:11010' },
    { value: 'turn.bj.629957.xyz:11010', label: '中国北京 tcp://turn.bj.629957.xyz:11010' },
];

const formRef = Vue.ref();
const rules = Vue.ref({ required: true, trigger: 'blur', message: '此项不能为空' });
const submitForm = async () => {
    const valid = await formRef.value.validate((valid) => { return valid });
    if (!valid) {
        ElementPlus.ElMessageBox.alert("请确认表单填写完整再提交！");
        return;
    }
    const res = await axios({
        url: 'api/easytier.php',
        method: 'post',
        params: {
            action: 'saveData'
        },
        data: formData.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getData();
}

const appi = async (appName, action) => {
	const res = await axios({
		url: `api/${appName}.php`,
		method: 'get',
		params: {
			action: action 
		}
	});
	if (res.data.success < 1) {
		ElementPlus.ElMessage.error(res.data.message);
		if (res.data.success == -1) {
			gotoLogin();
		}
		return;
	}
	ElementPlus.ElMessage.success(res.data.message);
	getData();
}
const appiAction = async (appName, action) => {
	await submitForm();
	await appi(appName, action);
}
const appiStop = async (appName) => {
	let res = await ElementPlus.ElMessageBox
		.confirm("如你正在远程连接车机，停止网络后可能会失去连接。确定要停止吗？")
		.catch(() => {});
	if (res != 'confirm') return;
	appiAction(appName, 'stop');
}
let interval = setInterval(async () => {
    const res = await axios({
        url: 'api/easytier.php',
        method: 'get',
        params: {
            action: 'getStatusData'
        }
    });
    if (res.data.success < 1) {
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    data.value = res.data.data;
}, 5000);
Vue. onUnmounted(() => {
    clearInterval(interval);
    interval = null;
});
</script>

<template>
    <el-form ref="formRef" :model="formData" label-width="auto" label-position="top">
        <div class="tab-head">
            <div class="tab-head-title">easytier 虚拟网</div>
            <div>
                <el-switch v-model="formData.easytierOn" active-text="启用"/>
            </div>
        </div>
        <div v-if="formData.easytierOn">
            <div class="inline-form-items">
                <el-form-item prop="et_hostname" label="虚拟网主机名">
                    <el-input v-model="formData.et_hostname" />
                </el-form-item>
                <el-form-item prop="et_ipv4" :rules="rules">
                    <template #label>
                        车机虚拟网IP
                        <el-tooltip placement="top-start" content="如: 172.20.0.18, 车机/手机/电脑的虚拟IP不能重复">
                            <span class="iconfont icon-question-circle tooltip"></span>
                        </el-tooltip>
                    </template>
                    <el-input v-model="formData.et_ipv4"/>
                </el-form-item>
            </div>
            <div class="inline-form-items">
                <el-form-item prop="et_network_name" :rules="rules">
                    <template #label>
                        虚拟网络名称
                        <el-tooltip placement="top-start" content="车机/手机/电脑必须一样填写">
                            <span class="iconfont icon-question-circle tooltip"></span>
                        </el-tooltip>
                    </template>
                    <el-input v-model="formData.et_network_name"/>
                </el-form-item>
                <el-form-item prop="et_network_secret" :rules="rules">
                    <template #label>
                        虚拟网络密码
                        <el-tooltip placement="top-start" content="车机/手机/电脑必须一样填写">
                            <span class="iconfont icon-question-circle tooltip"></span>
                        </el-tooltip>
                    </template>
                    <el-input v-model="formData.et_network_secret"/>
                </el-form-item>
            </div>
            <div class="inline-form-items">
                <el-form-item prop="et_peer" :rules="rules">
                    <template #label>
                        组网服务器
                        <el-tooltip placement="top-start" content="车机/手机/电脑一样填写，更多公共服务器查询easytier官网">
                            <span class="iconfont icon-question-circle tooltip"></span>
                        </el-tooltip>
                    </template>
                    <el-select-x v-model="formData.et_peer" :options="etPearOptions" allow-create multiple/>
                </el-form-item>
                <el-form-item prop="et_params">
                    <template #label>
                        附加命令行参数
                        <el-tooltip placement="top-start" content="自动添加 --no-listener --no-tun --bind-device false, 其它参考easytier官网">
                            <span class="iconfont icon-question-circle tooltip"></span>
                        </el-tooltip>
                    </template>
                    <el-input v-model="formData.et_params"/>
                </el-form-item>
            </div>

            <div class="info-div">
                <el-link type="primary" href="https://easytier.cn" target="_blank">easytier官网</el-link>:
                一个简单、安全、去中心化的内网穿透 VPN 组网方案，开源、免费
            </div>
            <div class="info-div">
                <el-text type="warning">设置修改后需要重启easytier才能生效！</el-text>
            </div>
            
            <div class="button-bar">
                <el-button type="danger" @click="appiStop('easytier')" :disabled="!data.et_is_running">
                    停止网络
                </el-button>
                <el-button
                    type="success"
                    @click="appiAction('easytier', 'start')"
                    :disabled="data.et_is_running || !data.et_installed"
                >
                    运行网络
                </el-button>
                <el-button type="primary" @click="appiAction('easytier', 'restart')" :disabled="!data.et_is_running">
                    重启easytier
                </el-button>
                <div>
                    <el-text v-if="!data.et_installed">easytier 未安装</el-text>
                    <el-text v-else>版本: {{ data.et_version }}</el-text>
                </div>
                <img v-if="data.et_is_running" src="/media/running1.gif" style="height:50px">
                <div v-else class="iconfont icon-running" style="font-size: 1.8em;color: gray"></div>
            </div>

            <div class="slide">
                <el-table :data="data.net_peers">
                    <el-table-column prop="ipv4" label="设备虚拟网ip" :min-width="140"/>
                    <el-table-column prop="hostname" label="设备主机名" :min-width="120" show-overflow-tooltip/>
                    <el-table-column prop="cost" label="路由" :min-width="100"/>
                    <el-table-column prop="lat_ms" label="延迟(ms)" :min-width="100"/>
                    <el-table-column prop="loss_rate" label="丢包率(%)" :min-width="100"/>
                    <el-table-column prop="rx_bytes" label="下载" :min-width="120"/>
                    <el-table-column prop="tx_bytes" label="上传" :min-width="120"/>
                    <el-table-column prop="version" label="easytier版本" :min-width="150"/>
                </el-table>
            </div>
        </div>
    </el-form>

    <page-footer>
        <el-button type="primary" style="width:150px" @click="submitForm()">保 存</el-button>
    </page-footer>
</template>

<style scoped>
.tooltip {
    color: orangered;
    cursor: pointer;
}
</style>