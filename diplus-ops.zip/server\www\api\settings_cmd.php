<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}

$conn = db_conn();
$post = json_decode_x(file_get_contents('php://input'));
if ($post) {
    $diplus_cmd = $post['diplus_cmd'];
    foreach ($diplus_cmd as &$row) {
        $row['command'] = str_replace("\n", ',', $row['command']);
    }
    unset($row);
    $json = json_encode_x($diplus_cmd);
    writeSettings($conn, 'diplus', 'diplus_cmd', $json);

	$ajson['message'] = '数据保存成功！';
    $ajson['success'] = 1;
    returnJson($ajson);
}


$returnData = [];
$diplus_cmd = json_decode_x(readSettings($conn, 'diplus', 'diplus_cmd'));
foreach ($diplus_cmd as &$row) {
    $row['command'] = str_replace(',', "\n", $row['command']);
}
unset($row);
$returnData['diplus_cmd'] = $diplus_cmd;

$ajson['data'] = $returnData;
$ajson['success'] = 1;
returnJson($ajson);

?>