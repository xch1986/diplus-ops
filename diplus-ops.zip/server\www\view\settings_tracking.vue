<script setup>
const formData = Vue.ref({});
const getData = async () => {
    const res = await axios({
        url: 'api/settings_tracking.php',
        method: 'get',
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    formData.value = res.data.data;
}
getData();

const formRef = Vue.ref();
const rules = Vue.ref({ required: true, trigger: 'blur', message: '此项不能为空' });
const submitForm = async () => {
    const valid = await formRef.value.validate((valid) => { return valid });
    if (!valid) {
        ElementPlus.ElMessageBox.alert("请确认表单填写完整再提交！");
        return;
    }
    const res = await axios({
        url: 'api/settings_tracking.php',
        method: 'post',
        data: formData.value
    });
    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    ElementPlus.ElMessage.success(res.data.message);
    getData();
}
</script>

<template>
    <div class="tab-head">
        <div class="tab-head-title">行驶轨迹</div>
    </div>

    <el-form ref="formRef" :model="formData" label-width="auto" label-position="top">
        <el-card header="系统设置">
            <el-form-item prop="snapshot" label="行驶轨迹地图显示视频截图">
                <el-radio-group v-model="formData.snapshot">
                    <el-radio value="diplus">优先显示迪加记录仪视频截图</el-radio>
                    <el-radio value="byd">优先显示原车记录仪视频截图</el-radio>
                </el-radio-group>
            </el-form-item>
        </el-card>

        <el-card header="迪加自动化设置">
            <div style="margin-bottom: 20px">
                <el-text tag="div">
                    显示行驶轨迹需要借助迪加自动化触发保存车辆位置信息。
                    选择自动设置迪加自动化，将在迪加中添加多条以Termux开头的自动化配置，配置内容仅在车机迪加APP中可见，迪加服务小程序中看不到这些配置。
                </el-text>
            </div>

            <el-form-item prop="trigger_for_tracking">
                <el-switch v-model="formData.trigger_for_tracking" active-text="自动设置迪加自动化"/>
            </el-form-item>
        </el-card>
    </el-form>

    <page-footer>
        <el-button type="primary" style="width:150px" @click="submitForm()">保 存</el-button>
    </page-footer>
</template>

<style scoped>
.el-card {
    margin-bottom: 30px;
}
.tooltip {
    color: orangered;
    cursor: pointer;
}
</style>