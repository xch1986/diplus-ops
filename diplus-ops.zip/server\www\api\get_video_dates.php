<?php
// https://apifox.com/apidoc/shared-c3ce5ff5-754f-438c-aef2-055d85aa0391
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '获取视频目录失败！未登录系统。';
    returnJson($ajson);
}

$startTime = $_GET["startTime"] ?? 0;
$endTime = $_GET["endTime"] ?? 0;
$type = $_GET["type"] ?? 0;
/**
 * $type
 * 0 - 熄火哨兵
 * 1 - 全景记录仪
 * 2 - 原车行车记录仪
 * 3 - 迪加录屏
 * 4-* - 自定义文件夹
 */

$conn = db_conn();
$ajson['data']['video_brightness'] = readSettings($conn, 'global', 'video_brightness') * 1 ?: 0;
$ajson['data']['cover_filename'] = readSettings($conn, 'global', 'cover_filename') ?: 'byd.jpg';
$videolist_show_snapshot = readSettings($conn, 'global', 'videolist_show_snapshot');
$ajson['data']['videolist_show_snapshot'] = $videolist_show_snapshot === '' ? true : $videolist_show_snapshot == 1;
$str = readSettings($conn, 'global', 'custom_video_dirs');
$custom_video_dirs = [];
if ($str && $arr = json_decode_x($str)) {
    $custom_video_dirs = $arr;
}
foreach ($custom_video_dirs as &$row) {
    $row['path_base64'] = base64_encode($row['path']);
}
unset($row);
$ajson['data']['custom_video_dirs'] = $custom_video_dirs;

if ($type == 0 || $type == 1) {
    $DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
    $conn = null;
    $url = "http://localhost:8988/api/videoDirs";
    $url .= "?startTime=$startTime&endTime=$endTime&type=$type&auth=".urlencode($DIPLUS_AUTH);
    $context = stream_context_create([
        'http' => [
            'timeout' => 5
        ]
    ]);
    $res = @file_get_contents($url, false, $context);
    if (!$res) {
        $ajson['message'] = '获取视频目录失败！';
        returnJson($ajson);
    }
    // 返回的文件列表是按时间倒序排列的
    $ajson['data']['dates'] = json_decode_x($res);
    $ajson['success'] = 1;
    returnJson($ajson);
}

// $type == 2, 原车行车记录仪
if ($type == 2) {
    $dates = [];
    $storages = getMountedStorage();
    foreach ($storages as $storage) {
        $directory = "$storage/Recorder/Normal";
        $mp4Files = glob("$directory/*.mp4");
        $pattern = '/.*\/(\d{4})-(\d{2})-(\d{2})/';
        foreach ($mp4Files as $file) {
            if (preg_match($pattern, $file, $matches)) {
                $date = $matches[1].$matches[2].$matches[3];
                if (!in_array($date, $dates)) {
                    $dates[] = $date;
                }
            }
        }
    }
    arsort($dates);
    $ajson['data']['dates'] = array_values($dates);
    $ajson['success'] = 1;
    returnJson($ajson);
}


// $type == 3, 迪加录屏
if ($type == 3) {
    $dates = [];
    $storages = getMountedStorage();
    foreach ($storages as $storage) {
        $directory = "$storage/AlarmVideo/S";
        $allItems = @scandir($directory, SCANDIR_SORT_DESCENDING);
        if (is_array($allItems)) {
            foreach ($allItems as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }
                if (preg_match('/^\d{8}$/', $item)) {
                    $dates[] = $item;
                }
            }
        }
    }
    $ajson['data']['dates'] = array_values($dates);
    $ajson['success'] = 1;
    returnJson($ajson);
}

// $type == 4-* 自定义
if (preg_match('/^4-(.+)/', $type, $matches)) {
    $directory = base64_decode($matches[1]);
    if (!is_dir($directory)) {
        returnJson($ajson);
    }

    $dates = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory));
    foreach ($iterator as $file) {
        $ext = $file->getExtension();
        if ($file->isFile() && ($ext === 'mp4' || $ext === 'mkv')) {
            $date = date("Ymd", $file->getCTime());
            if (!in_array($date, $dates)) {
                $dates[] = $date;
            }
        }
    }
    arsort($dates);
    $ajson['data']['dates'] = array_values($dates);
    $ajson['success'] = 1;
    returnJson($ajson);
}


$ajson['message'] = '获取文件夹失败！';
returnJson($ajson);
?>