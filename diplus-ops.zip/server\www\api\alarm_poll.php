<?php
// 哨兵事件轮询推送: 不依赖迪加自动化, 直接扫哨兵视频列表, 有人/有车+晃动达标即推送
// 用法: curl "http://127.0.0.1:8018/api/alarm_poll.php?mins=5"  (cron 每分钟调一次)
date_default_timezone_set('Asia/Shanghai'); // 车机 PHP 默认 UTC, 强制北京时间
require_once '../includes/phpshare.php';
require_once '../includes/db.php';
require_once '../includes/wechat.php';
require_once '../includes/image.php';
require_once '../includes/share.php';

header('Content-type: application/json; charset=utf-8');
$ajson = ['ok' => 0, 'msg' => '', 'pushed' => 0, 'skipped' => []];

$conn = db_conn();
$msgTo = readSettings($conn, 'global', 'msgTo');
if (!in_array($msgTo, ['wechat', 'dingding'])) { $ajson['msg'] = 'msgTo 未启用'; echo json_encode($ajson); exit; }

// 阈值: 晃动/振动与 alarm.php 一致(模板兜底 5/3); AI 置信度轮询用独立低阈值(人15%/车25%, 车普遍高置信度)
$tplP = json_decode_x(readSettings($conn, 'diplus', 'trigger_alarm_person'));
$tplC = json_decode_x(readSettings($conn, 'diplus', 'trigger_alarm_car'));
$shakeTh = (is_array($tplP) && isset($tplP['shakeG']) && $tplP['shakeG'] !== null) ? (float)$tplP['shakeG'] : 5;
$vibrateTh = (is_array($tplP) && isset($tplP['vibrateGyro']) && $tplP['vibrateGyro'] !== null) ? (float)$tplP['vibrateGyro'] : 3;
$personTh = 0.15;
$carTh = 0.25;
$mins = isset($_GET['mins']) ? max(1, (int)$_GET['mins']) : 5;
$window = $mins * 60 * 1000;

$DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
$dateStr = date('Ymd');
$now = time() * 1000;

// 已推记录(防重复)
$doneFile = '/data/data/com.termux/files/home/alarm_poll_done.txt';
$done = @file_get_contents($doneFile) ?: '';
$doneSet = array_filter(explode("\n", $done));

// 查哨兵视频列表
$url = "http://127.0.0.1:8988/api/videoFiles?type=0&dir=$dateStr&auth=" . urlencode($DIPLUS_AUTH);
$ctx = stream_context_create(['http' => ['timeout' => 8]]);
$res = @file_get_contents($url, false, $ctx);
$list = json_decode_x($res);
if (!is_array($list)) { $ajson['msg'] = 'videoFiles 获取失败'; echo json_encode($ajson); exit; }

$pushed = 0;
$skipped = [];
$serverIp = readSettings($conn, 'global', 'serverIp');
$cover_filename = readSettings($conn, 'global', 'cover_filename') ?: 'byd.jpg';
$WECHAT_ALARM = readSettings($conn, 'global', 'WECHAT_ALARM');

foreach ($list as $v) {
    if (!isset($v['startTime'])) continue;
    $st = (float)$v['startTime'];
    if ($now - $st > $window) continue;          // 窗口外
    $key = $v['key'] ?? '';
    if (!$key || in_array($key, $doneSet)) continue;
    $person = (int)($v['person'] ?? 0);
    $car = (int)($v['car'] ?? 0);
    if ($person == 0 && $car == 0) continue;      // 无事件
    $mG = (float)($v['motionG'] ?? 0);
    $mGyro = (float)($v['motionGyro'] ?? 0);
    // AI 置信度确认(与阈值一致)
    $pMax = 0; $cMax = 0;
    $info = json_decode_x(@file_get_contents("http://127.0.0.1:8988/api/videoInfo?key=" . urlencode($key) . "&auth=" . urlencode($DIPLUS_AUTH), false, $ctx));
    if ($info && isset($info['labels'])) {
        foreach ($info['labels'] as $row) {
            if (!isset($row['results'])) continue;
            foreach ($row['results'] as $res2) {
                if ($res2['className'] == 'person') $pMax = max($pMax, (float)$res2['score']);
                if ($res2['className'] == 'car') $cMax = max($cMax, (float)$res2['score']);
            }
        }
    }
    $label = '';
    if ($person > 0 && $pMax >= $personTh) $label = '有人';
    elseif ($car > 0 && $cMax >= $carTh) $label = '有车';
    if (!$label) {
        $skipped[] = '置信度不足 ' . date('H:i:s', (int)($st / 1000)) . " p$person($pMax) c$car($cMax)";
        continue;
    }
    // 对应类型的 motion 阈值
    $myTpl = ($label == '有人') ? $tplP : $tplC;
    $myShake = (is_array($myTpl) && isset($myTpl['shakeG']) && $myTpl['shakeG'] !== null) ? (float)$myTpl['shakeG'] : 5;
    $myVibrate = (is_array($myTpl) && isset($myTpl['vibrateGyro']) && $myTpl['vibrateGyro'] !== null) ? (float)$myTpl['vibrateGyro'] : 3;
    if (!(($mGyro >= $myShake) || ($mG >= $myVibrate))) {
        $skipped[] = $label . " motion不足 " . date('H:i:s', (int)($st / 1000)) . " p$person c$car gyro$mGyro g$mG(阈值$myShake/$myVibrate)";
        continue;
    }
    // 推送(微信news, 与 alarm.php 一致)
    $time = date('Y-m-d H:i:s', (int)($st / 1000));
    $conf = round(max($pMax, $cMax) * 100);
    $title = $label == '有人' ? 'BYD哨兵-有人' : 'BYD哨兵-有车';
    $text = $label . "靠近(可信度{$conf},晃动" . round($mGyro) . ",振动" . round($mG) . ")";
    $jumpUrl = "$serverIp/alarm_details.html?time=" . urlencode($time) . "&aiType=" . ($label == '有人' ? 1 : 2) . "&title=" . urlencode($title) . "&text=" . urlencode($text);
    $picUrl = "$serverIp/media/$cover_filename";
    $msgData = [
        "msgtype" => "news",
        "news" => ["articles" => [[
            "title" => $title,
            "description" => "$time\n$text",
            "url" => $jumpUrl,
            "picurl" => $picUrl
        ]]]
    ];
    if ($msgTo == 'wechat') {
        $ret = sendToWechatGroup($WECHAT_ALARM, $msgData);
        if ($ret !== true) { $skipped[] = "推送失败 $time: $ret"; continue; }
    } elseif ($msgTo == 'dingding') {
        $DINGDING_ALARM = readSettings($conn, 'global', 'DINGDING_ALARM');
        $DINGDING_ALARM_SECRET = readSettings($conn, 'global', 'DINGDING_ALARM_SECRET');
        $sendText = "#### $title\n\n$time\n\n$text\n\n[点击查看详情]($jumpUrl)";
        $ret = sendToDingdingGroup($DINGDING_ALARM, $DINGDING_ALARM_SECRET, ["msgtype" => "markdown", "markdown" => ["title" => $title, "text" => $sendText]]);
        if ($ret !== true) { $skipped[] = "推送失败 $time: $ret"; continue; }
    }
    file_put_contents($doneFile, $key . "\n", FILE_APPEND);
    $pushed++;
}

// 防膨胀
if (count($doneSet) > 500) {
    $arr = array_values(array_slice($doneSet, -300));
    file_put_contents($doneFile, implode("\n", $arr) . "\n");
}

// 每分钟同步行驶数据（20260929 恢复触发）
@file_get_contents("http://127.0.0.1:8018/api/save_driving_data.php?timestamp=" . time() * 1000, false, stream_context_create(['http' => ['timeout' => 5]]));

$ajson['ok'] = 1;
$ajson['msg'] = "done($msgTo) shake>=$shakeTh vibrate>=$vibrateTh person>=" . round($personTh * 100) . " car>=" . round($carTh * 100);
$ajson['pushed'] = $pushed;
$ajson['skipped'] = $skipped;
echo json_encode($ajson, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
