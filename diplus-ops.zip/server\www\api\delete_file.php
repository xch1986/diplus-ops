<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = [
    'success' => 0,
    'message' => '',
    'data' => []
];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统！';
    returnJson($ajson);
}

$key = $_GET["key"] ?? '';
if (!$key) {
	$ajson['message'] = '参数错误！';
    returnJson($ajson);
}

$filePath = base64_decode($key);
if (file_exists($filePath)) {
    @unlink($filePath);
}
$exists = file_exists($filePath);
$ajson['message'] = $exists ? '删除文件失败！' : '文件删除成功！';
$ajson['success'] = !$exists;
returnJson($ajson);
?>