<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '获取行程数据失败！未登录系统。';
    returnJson($ajson);
}
$dateFrom = $_GET["dateFrom"] ?? '';
$dateTo = $_GET["dateTo"] ?? '';

$dbPath = '/storage/emulated/0/vandiplus/db/van_bm_db';
$conn = db_conn($err, $dbPath);
if (!$conn) {
    $ajson['message'] = "打开数据库失败！$err";
    returnJson($ajson);
}

$p = [];
$aWhere = [ 'mileage_end > mileage_start' ];
$aWhere[] = "date(time_end / 1000, 'unixepoch', 'localtime') BETWEEN :dateFrom AND :dateTo";
$p[':dateFrom'] = $dateFrom;
$p[':dateTo'] = $dateTo;

$strWhere = implode(' AND ', $aWhere);
// DISTINCT 单个字段只适用于sqlite, 不适用于mysql
$sql = "SELECT date(time_end / 1000, 'unixepoch', 'localtime') AS travelDate,
    SUM(mileage_end - mileage_start) / 10.0 AS mileage,
    SUM(evMileage_end - evMileage_start) / 10.0 AS evMileage,
    ROUND(SUM(elecCon_end - elecCon_start), 2) AS elecCon,
    ROUND(SUM(fuelCon_end - fuelCon_start), 2) AS fuelCon
    FROM TripInfo
    WHERE $strWhere
    GROUP BY travelDate
";
$data = db_query_all($conn, $sql, $p);
if (!$data) {
    $ajson['message'] = '获取行程数据失败！';
    returnJson($ajson);    
}
$ajson['data']['monthlyTrip'] = $data;

$conn0 = db_conn();
$ajson['data']['fuel_price'] = (float) readSettings($conn0, 'global', 'fuel_price');
$ajson['data']['elec_price'] = (float) readSettings($conn0, 'global', 'elec_price');

$ajson['success'] = 1;
$ajson['message'] = '行程数据获取成功！';
returnJson($ajson);
?>