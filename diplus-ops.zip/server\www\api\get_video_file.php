<?php
date_default_timezone_set('Asia/Shanghai'); // 双保险: 车机 PHP 全局时区已修, 此文件独立保证
// https://apifox.com/apidoc/shared-c3ce5ff5-754f-438c-aef2-055d85aa0391
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
// 非本地访问需验证身份
if ($_SERVER['HTTP_HOST'] != 'localhost:8018' && $_SERVER['HTTP_HOST'] != '127.0.0.1:8018') {
    $login = login(false);
    if (!$login) {
        $ajson['success'] = -1;
        $ajson['message'] = '未登录系统！';
        returnJson($ajson);
    }
}

$conn = db_conn();
$DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
$ajson['data']['video_brightness'] = readSettings($conn, 'global', 'video_brightness') * 1 ?: 0;
$conn = null;

$time = @$_GET["time"];
if (!$time) {
	$ajson['message'] = '参数错误！';
    returnJson($ajson);
}
$aiType = isset($_GET['aiType']) ? $_GET['aiType'] : 1; // 0-忽略AI检测, 1-person, 2-car, 3-person+car

$timestamp = strtotime($time);
$str_date = date('Ymd', $timestamp);
$triggerTime = $timestamp * 1000;

$url = "http://127.0.0.1:8988/api/videoFiles?type=0&dir=$str_date&auth=".urlencode($DIPLUS_AUTH);
$context = stream_context_create([
    'http' => [
        'timeout' => 5
    ]
]);
$res = @file_get_contents($url, false, $context);
if (!$res) {
	$ajson['message'] = '读取视频文件失败！';
    returnJson($ajson);
}
// 返回的文件列表是按时间倒序排列的
// 匹配加 ±3 秒容差: 推送链接 time 是秒级, 视频 startTime 带毫秒, 严格 >= 会因毫秒差匹配失败
$resData = json_decode_x($res);
$videoFile = [];
foreach ($resData as $row) {
    if (($triggerTime + 3000) >= $row['startTime'] && ($triggerTime - 3000) <= $row['endTime']) {
        if (!$videoFile) {
            $videoFile = $row;
        } else {
            // 倒序列表: 取 endTime 最接近 triggerTime 的段(即 trigger 所在段)
            if (abs($row['endTime'] - $triggerTime) < abs($videoFile['endTime'] - $triggerTime)) {
                $videoFile = $row;
            }
        }
    }
}
if (!$videoFile) {
	$ajson['message'] = '读取视频文件失败！';
    returnJson($ajson);    
}

// 加个超时参数。
// 如果视频文件损坏迪加api返回时间会很长，不加超时需要等好几分钟
$context = stream_context_create([
    'http' => [
        'timeout' => 5
    ]
]);

$url = "http://127.0.0.1:8988/api/videoInfo?key=".$videoFile['key']."&auth=".urlencode($DIPLUS_AUTH);
$res = @file_get_contents($url, false, $context);
if (!$res) {
	$ajson['message'] = '读取视频文件失败！';
    returnJson($ajson);
}
$videoInfo = json_decode_x($res);
if (!$videoInfo) {
	$ajson['message'] = '读取视频文件失败！';
    returnJson($ajson);
}


// 有些视频没有cover，自己截一张
if (empty($videoInfo['cover'])) {
    $filePath = base64_decode($videoFile['key']);
    $videoInfo['cover'] = getVideoCover($filePath);
}
$videoFile['cover'] = $videoInfo['cover'];
$videoFile['triggerTimeMS'] = 0;

if ($aiType && isset($videoInfo['labels'])) {
    $events = getEvents($videoFile['startTime'], $videoInfo['labels']);
    $videoFile['events'] = $events;

    if (($aiType == 1 || $aiType == 3) && $events['person']) {
        $videoFile['triggerTimeMS'] = $events['person'][0];
    }
    if (($aiType == 2 || $aiType == 3) && $events['car']) {
        $videoFile['triggerTimeMS'] = $events['car'][0];
    }
}


// 晃动/振动逐秒标记: ms 格式 [秒, 晃动值, 振动值, 0, 0] 每5个一组
$motionGyro = [];
$motionG = [];
if (isset($videoInfo['ms']) && is_array($videoInfo['ms'])) {
    $cnt = count($videoInfo['ms']);
    for ($i = 0; $i + 4 < $cnt; $i += 5) {
        $sec = $videoInfo['ms'][$i] * 1000;
        if (!empty($videoInfo['ms'][$i+1])) $motionGyro[] = $sec;
        if (!empty($videoInfo['ms'][$i+2])) $motionG[] = $sec;
    }
}
$videoFile['events'] = isset($videoFile['events']) ? $videoFile['events'] : [];
$videoFile['events']['motionGyro'] = $motionGyro;
$videoFile['events']['motionG'] = $motionG;

// 获取位置数据
$dbPath = '/data/data/com.termux/files/home/db/driving_data.db';
$conn1 = db_conn($err, $dbPath);
if ($conn1) {
    $sql = "SELECT `location` FROM driving_data WHERE `timestamp` BETWEEN :startTime AND :endTime";
    $p = [
        ':startTime' => $videoFile['startTime'],
        ':endTime' => $videoFile['endTime']
    ];
    $row = db_query_row($conn1, $sql, $p);
    if ($row) {
        $location = json_decode_x($row['location']);
        if (is_numeric($location['longitude']) || is_numeric($location['latitude'])) {
            $videoFile['location'] = $location;
        }
    }
    $conn1 = null;
}

$ajson['data']['video_file'] = $videoFile;
$ajson['success'] = 1;
returnJson($ajson);
?>