<script setup>
import { GPS, getAddress, getLocalAddress, loadAMap, shortenAddress } from '/includes/map.js';

const isMobile = Vue.ref(window.innerWidth < 550);
const router = VueRouter.useRouter();
const route = VueRouter.useRoute();
const data = Vue.ref({
    time_start: parseFloat(route.query.time_start),
    time_end: parseFloat(route.query.time_end)
});
const trackingData = Vue.ref([]);
const currentPoint = Vue.ref();
let infoWindow;

let AMap;
let map = null;
let movingMarker = null;
let currentPolyline = null;
let currentMarkers = [];

Vue.onMounted(async () => {
    AMap = await loadAMap(['AMap.Scale', 'AMap.moveAnimation', 'AMap.Geocoder', 'AMap.ControlBar']);
    map = new AMap.Map('mapContainer', {
        viewMode: '3D',
        zoom: 17,
        rotateEnable: false
    });

    map.addControl(new AMap.Scale());
    const controlBar = new AMap.ControlBar({
        showZoomBar: true,
        showControlButton: true,
        position: {
            right: '10px',
            top: '10px'
        }
    });
    map.addControl(controlBar);

    infoWindow = new AMap.InfoWindow({
        content: '',
        anchor: 'top-left',
        closeWhenClickMap: true,
    });

    getTrackingData();
});


Vue.onUnmounted(() => {
    if (map) {
        // 必须停止动画否则会出错
        stopPathAnimation();
        map.clearMap();
        map.off();
        map.destroy();
        map = null;
    }
});

const showInfo = async (point) => {
    if (!point || !Object.keys(point).length) {
        return;
    }
    // console.log(point)
    let content = `<div class="info-window">`;
    content += `
        <div>
            ${point?.timestamp ? new Date(point.timestamp).Format('YYYY年M月D日 hh:mm:ss') : ''}
        </div>
    `;
    if (point.address) {
        content += `
            <div style="font-size: 0.9em;color: #333;font-weight: bold">
                <span class="iconfont icon-site1 dodgerblue"></span> ${point.address}
            </div>
        `;
    }
    content += `
        <table style="width:100%">
            <tr class="info-window-data">
                <td>${point?.speed}</td>
                <td>${point?.location?.altitude}</td>
                <td>${point?.battery_percent}%</td>
                <td>${point.fuel_percent}%</td>
            </tr>
            <tr>
                <td>速度</td>
                <td>海拔</td>
                <td>电量</td>
                <td>油量</td>
            </tr>
        </table>
    `;
    if (point.videoInfo?.snapshot_base64) {
        const vInfo = point.videoInfo;
        content += `
            <img
                class="info-window-snapshot"
                src="data:image/jpeg;base64,${point.videoInfo.snapshot_base64}"
                onclick="playVideo('${vInfo.snapshot_type}')"
            />
        `;
        content += `<div class="video-links">`;
        if (vInfo.diplus?.key) {
            content += `<div onclick="playVideo('diplus')">迪加</div>`;
        }
        if (vInfo.byd?.key) {
            content += `<div onclick="playVideo('byd')">原车</div>`;
        }
        content += `<div class="iconfont icon-step-backward" onclick="nextPoint(${point.timestamp}, -1)"></div>`;
        content += `<div class="iconfont icon-step-forward" onclick="nextPoint(${point.timestamp}, 1)"></div>`;
        content += `</div>`;
    }
    content += `</div>`;

    infoWindow.setContent(content);
    infoWindow.open(map, point.position);
    if (!point.address) {
        currentPoint.value.address = await getLocalAddress(AMap, point.position);
    }
    if (!point.snapshotRequested) {
        const res = await axios({
            url: 'api/get_recorder_snapshot.php',
            method: 'get',
            params: {
                timestamp: point.timestamp,
            }
        });
        currentPoint.value.snapshotRequested = true;
        if (res.data.success == 1) {
            currentPoint.value.videoInfo = res.data.data;
            showInfo(currentPoint.value);
        }
    }
}

// 创建标记点
const createMarkers = async (points) => {
    const markers = [];
    const clickRadius = 30; // 点击敏感区域半径（像素）
    points.forEach(async (point, index) => {
        const isStart = index === 0;
        const isEnd = index === points.length - 1;
        let marker;
        if (isStart || isEnd) {
            const icon = new AMap.Icon({
                size: new AMap.Size(40, 50),
                image: isStart ? 'media/route_start.png' : 'media/route_end.png',
                imageSize: new AMap.Size(40, 50),
            });
            marker = new AMap.Marker({
                position: point.position,
                icon: icon,
                offset: new AMap.Pixel(-13, -30)
            });
        } else {
            const rate = point.speed / 120;
            const content = `<div
                style="width: 4px;
                height: 4px;
                background: rgb(${255 * rate}, ${255 * (1 - rate)}, 0);
                border-radius: 50%;">
            </div>`;
            marker = new AMap.Marker({
                position: point.position,
                content: content,
                anchor: 'center',
            });
        }

        // 点击marker显示infoWindow
        marker.on('click', () => {
            currentPoint.value = point;
            showInfo(currentPoint.value);
        });
        // 添加timestamp便于后面查找
        marker.timestamp = point.timestamp;
        markers.push(marker);
        map.add(marker);
    });

    // 显示起点终点位置
    let address_start = await getAddress(AMap, points[0].position);
    address_start = address_start.regeocode.formattedAddress;
    let address_end = await getAddress(AMap, points[points.length - 1].position);
    address_end = address_end.regeocode.formattedAddress;
    [ address_start, address_end ] = shortenAddress(address_start, address_end);
    markers[0].setLabel({
        offset: new AMap.Pixel(0, 20),
        content: address_start,
    });
    markers[markers.length - 1].setLabel({
        offset: new AMap.Pixel(0, 20),
        content: address_end,
    });

    // 点击marker附近时显示infoWindow
    map.on('click', (e) => {
        currentPoint.value = null; // 先隐藏infoWindow
        const clickPos = map.lngLatToContainer(e.lnglat);
        let nearestMarker = null;
        let minDistance = Infinity;
        markers.forEach((marker) => {
            const markerPos = map.lngLatToContainer(marker.getPosition());
            const dx = markerPos.x - clickPos.x;
            const dy = markerPos.y - clickPos.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            if (distance < clickRadius && distance < minDistance) {
                minDistance = distance;
                nearestMarker = marker;
            }
        });
        if (nearestMarker) {
            const point = trackingData.value.find(row => row.timestamp === nearestMarker.timestamp);
            currentPoint.value = point;
            showInfo(currentPoint.value);
        }
    });
}

// 轨迹动画函数
function startPathAnimation(points) {
    stopPathAnimation();

    AMap.plugin(['AMap.MoveAnimation'], () => {
        movingMarker = new AMap.Marker({
            map: map,
            content: '<img src="media/car.png" style="height:30px"/>',
            autoRotation: true, // 启用自动转向
            anchor: 'center',
        });

        const path = points.map(p => p.position);
        movingMarker.moveAlong(path, {
            duration: 200,
        });
    });
}
function stopPathAnimation() {
    if (movingMarker) {
        movingMarker.stopMove();
        movingMarker.setMap(null);
        movingMarker = null;
    }
}
// 更新地图数据
function updateMapData(newData) {
    clearMapData();
    if (!Array.isArray(newData)) {
        console.error('Invalid data format: Expected array');
        return [];
    }

    // 创建轨迹线
    currentPolyline = new AMap.Polyline({
        map: map,
        path: trackingData.value.map(p => p.position),
        strokeColor: "#3366FF",
        strokeWeight: 4,
        showDir: true, // 显示方向箭头
        lineCap: 'round',
        lineJoin: 'round',
    });
   
    // 创建标记
    createMarkers(trackingData.value);

    // 显示完整轨迹
    map.setFitView();

    // 启动轨迹动画
    startPathAnimation(trackingData.value);
}
// 清除旧数据
function clearMapData() {
    if(currentPolyline) {
        currentPolyline.setMap(null);
        currentPolyline = null;
    }
    currentMarkers.forEach(marker => {
        marker.setMap(null);
        marker.off('click');
    });
    currentMarkers = [];
    
    stopPathAnimation();
}

const getTrackingData = async () => {
    const res = await axios({
        url: 'api/sum_tracking.php',
        method: 'get',
        params: {
            time_start: data.value.time_start,
            time_end: data.value.time_end
        }
    });
    if (res.data.success < 1) {
        if (res.data.success < 0) {
            ElementPlus.ElMessage.error(res.data.message);
            if (res.data.success == -1) {
                gotoLogin();
            }
        }
        document.querySelector('#mapContainer').style.display = 'none';
        data.value.showHelper = true;
        return;
    }
    trackingData.value = res.data.data.map(row => {
        let long = row.location.longitude;
        let lat = row.location.latitude;
        if (long && lat) {
            // WGS84坐标转GCJ-02坐标保存到 position 中
            const gpsPoint = GPS.gcj_encrypt(lat, long);
            row.position = [ gpsPoint.lon, gpsPoint.lat ];
            return row;
        }
    });
    updateMapData(trackingData.value);
}

const timestampToString = (timestamp) => {
    if (!timestamp) return '';
    return new Date(timestamp).Format('YYYY-MM-DD hh:mm');
}

window.playVideo = (snapshot_type) => {
    // console.log(currentPoint.value);
    const info = currentPoint.value.videoInfo[snapshot_type];
    let url = `play_video.html`;
    url += snapshot_type == 'diplus' ? '?type=1' : '?type=2';
    url += `&currentTime=${info.snapshot_time}`;
    url += `&startTime=${info.startTime}`;
    url += `&endTime=${info.endTime}`;
    url += `&key=${encodeURIComponent(info.key)}`;
    window.open(url, '_blank');
}
window.nextPoint = (currentTimestamp, step) => {
    const index = trackingData.value.findIndex(row => row.timestamp === currentTimestamp);
    if (index < 0) return;
    if (index > 0 && step == -1 || index < (trackingData.value.length - 1) && step == 1) {
        currentPoint.value = trackingData.value[index + step];
        showInfo(currentPoint.value);
    }
}
</script>

<template>
    <div class="container">
        <div class="tool-bar">
            <el-button type="primary" text @click="router.back()">
                <span class="iconfont icon-reply" style="font-size: 2em"></span>
            </el-button>
        </div>
        <div id="panel"></div>
        <div id="mapContainer"></div>

        <div v-if="data.showHelper" class="helper-container">
            <div class="tab-head">
                <div class="tab-head-title">行驶轨迹</div>
            </div>
            <h4>
                没有 {{ timestampToString(data.time_start) + ' - ' + timestampToString(data.time_end) }} 时段的行驶轨迹数据！
            </h4>
            <p>
                显示行驶轨迹需要满足以下条件:
                <ul>
                    <li>车机安装迪加1.3.7b8或以上版本</li>
                    <li>在迪加服务小程序中添加2条自动化</li>
                    <li>为避免数据过多影响加载速度，系统只保存最近2年的轨迹数据</li>
                </ul>
            </p>
        </div>
    </div>
</template>


<style>
.info-window {
    width: 200px;
    font-size: 0.9em;
}
.info-window td {
    width: 40px;
}
.info-window-data td {
    color: orange;
}
.info-window-snapshot {
    width: 100%;
    display: block;
    cursor: pointer;
}
.amap-marker-label {
    border: none;
    border-radius: 3px;
    box-shadow: 0 2px 6px 0 rgba(114, 124, 245, .5);
    color: dodgerblue;
    min-width: 120px;
    max-width: 300px;
    white-space: wrap;
}
.video-links {
    display: flex;
	flex-wrap: wrap;
	justify-content: space-between;
	gap: 10px;
	align-items: center;
    padding-top: 14px;
}
.video-links > div {
    cursor: pointer;
    color: dodgerblue;
}
</style>
<style scoped>
.helper-container li {
    word-break: break-all;
}
.tool-bar {
    position: absolute;
    z-index: 9;
    left: 0;
    top: 0;
}
.container {
    position: relative;
    margin: -10px;
}
#mapContainer {
    width: 100%;
    height: 800px;
}
.helper-container {
    padding: 50px 10px 10px 10px;
}
@media screen and (max-height: 900px) {
    #mapContainer {
        height: 600px;
    }
}
</style>