<?php
$cmd = 'export PATH=/data/data/com.termux/files/usr/bin:$PATH; export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib; cd /data/data/com.termux/files/home; setsid nohup /data/data/com.termux/files/usr/bin/openlist server > /data/data/com.termux/files/home/data/log/ol_php.log 2>&1 &';
shell_exec($cmd);
sleep(2);
echo "OL_START\n";
echo shell_exec('ps -A | grep -i openlist');
?>