<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '获取轨迹数据失败！未登录系统。';
    returnJson($ajson);
}
$time_start = $_GET["time_start"] ?? strtotime('-1 days') * 1000;
$time_end = $_GET["time_end"] ?? strtotime('today') * 1000;
if (!$time_start || !$time_end) {
    $ajson['success'] = -2;
    $ajson['message'] = '参数错误！';
    returnJson($ajson);    
}

$dbPath = '/storage/emulated/0/Termux/db.db';
$conn = db_conn($err, $dbPath);
if (!$conn) {
    $ajson['success'] = -3;
    $ajson['message'] = "打开数据库失败！$err";
    returnJson($ajson);
}

$sql = "SELECT `timestamp`, `location`, speed, gear, lane_keep_status, cruise_switch,
    acc_status, low_beam, high_beam, battery_percent, fuel_percent
    FROM driving_data
    WHERE `timestamp` BETWEEN :time_start AND :time_end";
$p = [
    ':time_start' => $time_start,
    ':time_end' => $time_end
];

$data = db_query_all($conn, $sql, $p, $err);
if (!$data) {
    $ajson['message'] = "没有轨迹数据！";
    returnJson($ajson);
}

// 第一条数据速度不为0说明正在行驶，尝试查找之前一条数据
if ($data[0]['speed'] > 0) {
    $sql = "SELECT `timestamp`, `location`, speed, gear, lane_keep_status, cruise_switch,
        acc_status, low_beam, high_beam, battery_percent, fuel_percent
        FROM driving_data
        WHERE `timestamp` < :timestamp ORDER BY `timestamp` DESC LIMIT 1";
    $p = [
        ':timestamp' => $data[0]['timestamp'],
    ];
    $row = db_query_row($conn, $sql, $p);
    if ($row) {
        $data = array_merge([$row], $data);
    }
}

// 最后一条数据速度不为0说明正在行驶，尝试查找之后一条数据
if (end($data)['speed'] > 0) {
    $sql = "SELECT `timestamp`, `location`, speed, gear, lane_keep_status, cruise_switch,
        acc_status, low_beam, high_beam, battery_percent, fuel_percent
        FROM driving_data
        WHERE `timestamp` > :timestamp LIMIT 1";
    $p = [
        ':timestamp' => end($data)['timestamp'],
    ];
    $row = db_query_row($conn, $sql, $p);
    if ($row) {
        $data = array_merge($data, [$row]);
    }
}

foreach ($data as $index => &$row) {
    $row['location'] = json_decode_x($row['location']);
    if (!is_numeric($row['location']['longitude']) || !is_numeric($row['location']['latitude'])) {
        unset($data[$index]);
    }
}
unset($row);

$ajson['data'] = array_values($data);
$ajson['success'] = 1;
$ajson['message'] = '轨迹数据获取成功！';
returnJson($ajson);
?>