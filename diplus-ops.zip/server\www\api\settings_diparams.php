<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';
require_once '../includes/diplus_config.php';
require_once '../includes/diplus_param_list.php';
require_once '../includes/driving_data_params.php';

$ajson = ['success' => 0, 'message' => '', 'data' => [], 'options' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统。';
    returnJson($ajson);
}

$conn = db_conn();
$post = json_decode_x(file_get_contents('php://input'));
if ($post) {
    writeSettings($conn, 'diplus', 'preset_params', json_encode_x($post['preset_params']));
    writeSettings($conn, 'global', 'autorefresh_params', $post['autorefresh_params']);
    $diplus_params = $post['diplus_params'];
    writeSettings($conn, 'diplus', 'diplus_params', json_encode_x($diplus_params));

    $save_param_interval = $post['save_param_interval'] ?? 5;
    writeSettings($conn, 'diplus', 'save_param_interval', $save_param_interval);
    $ajson['message'] = '数据保存成功！';

    $DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
    $res = setXDSaveDrivingData($save_param_interval, $DIPLUS_AUTH);
    if (!$res) {
        $ajson['message'] .= '保存车况数据小迪扩展设置失败！';
    }

    $res = setTriggerSaveParams($diplus_params, $DIPLUS_AUTH);
    if (!$res) {
        $ajson['message'] .= '配置监听车况数据自动化失败！';
    }

    $ajson['success'] = 1;
    returnJson($ajson);
}

$params = array_map(
    fn($v) => mb_substr($v, 1, mb_strlen($v, 'utf-8') - 2, 'utf-8'),
    $DRIVING_DATA_PARAMS
);
$FIXED_DRIVING_PARAMS = array_values($params);
$ajson['options']['FIXED_DRIVING_PARAMS'] = $FIXED_DRIVING_PARAMS;
$ajson['options']['DIPLUS_PARAM_LIST'] = array_map(fn($v) => $v['label'], $DIPLUS_PARAM_LIST);

$returnData = [];
$returnData['preset_params'] = json_decode_x(readSettings($conn, 'diplus', 'preset_params'));
if (!isset($returnData['preset_params']['show_position'])) {
    $returnData['preset_params']['show_position'] = true;
}
if (!isset($returnData['preset_params']['tire_pressure'])) {
    $returnData['preset_params']['tire_pressure'] = [
        'show' => true,
        'lowerLimit' => 220,
        'upperLimit' => 290
    ];
}

$diplus_params = json_decode_x(readSettings($conn, 'diplus', 'diplus_params'));
foreach ($diplus_params as &$param) {
    if (in_array($param['name'], $FIXED_DRIVING_PARAMS)) {
        $param['save'] = true;
    }
}
unset($param);
$returnData['diplus_params'] = $diplus_params;

$returnData['autorefresh_params'] = readSettings($conn, 'global', 'autorefresh_params') == 1;
$returnData['save_param_interval'] = (int)readSettings($conn, 'diplus', 'save_param_interval') ?: 5;
$ajson['data'] = $returnData;



$ajson['success'] = 1;
returnJson($ajson);

?>