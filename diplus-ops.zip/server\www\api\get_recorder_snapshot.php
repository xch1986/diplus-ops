<?php
// https://apifox.com/apidoc/shared-c3ce5ff5-754f-438c-aef2-055d85aa0391
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];

$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统！';
    returnJson($ajson);
}

$retData = [];
$conn = db_conn();
$DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
$retData['snapshot_type'] = readSettings($conn, 'global', 'snapshot') ?: 'diplus';
$conn = null;

$timestamp = @$_GET["timestamp"];
if (!$timestamp) {
	$ajson['message'] = '参数错误！';
    returnJson($ajson);
}

// 迪加记录仪视频
$retData['diplus'] = getDiplusVideoFile($timestamp, $DIPLUS_AUTH);

// 原车记录仪视频
$retData['byd'] = getBydVideoFile($timestamp);

if (!$retData['diplus'] && !$retData['byd']) {
	$ajson['message'] = '读取视频文件失败！';
    returnJson($ajson);    
}

$filePath = '';
if ($retData['snapshot_type'] === 'diplus' && !$retData['diplus']) {
    $retData['snapshot_type'] = 'byd';
} else if ($retData['snapshot_type'] === 'byd' && !$retData['byd']) {
    $retData['snapshot_type'] = 'diplus';
}

if ($retData['snapshot_type'] === 'diplus') {
    $filePath = base64_decode($retData['diplus']['key']);
    $retData['snapshot_base64'] = getVideoCover($filePath, 320, $retData['diplus']['snapshot_time']);
} else {
    $filePath = base64_decode($retData['byd']['key']);
    $retData['snapshot_base64'] = getVideoCover($filePath, 320, $retData['byd']['snapshot_time']);
}
if (!$retData['snapshot_base64']) {
    $ajson['message'] = '获取视频截图失败！';
    returnJson($ajson);
}

$ajson['data'] = $retData;
$ajson['success'] = 1;
returnJson($ajson);


// 迪加记录仪视频
function getDiplusVideoFile($timestamp, $DIPLUS_AUTH) {
    $videoFile = [];
    $str_date = date('Ymd', $timestamp / 1000);
    $url = "http://localhost:8988/api/videoFiles?type=1&dir=$str_date&auth=".urlencode($DIPLUS_AUTH);
    $context = stream_context_create([
        'http' => [
            'timeout' => 5
        ]
    ]);
    $res = @file_get_contents($url, false, $context);
    if ($res) {
        // 返回的文件列表是按时间倒序排列的
        $resData = json_decode_x($res);
        foreach ($resData as $row) {
            if ($timestamp >= $row['startTime'] && $timestamp <= $row['endTime']) {
                $videoFile = $row;
                break;
            }
        }
    }
    if ($videoFile && @$videoFile['startTime']) {
        $videoFile['snapshot_time'] = round(($timestamp - $videoFile['startTime']) / 1000);
    }
    return $videoFile;
}

// 比亚迪原车记录仪视频
function getBydVideoFile($timestamp) {
    $videoFile = [];
    $mp4Files = [];
    // 文件名中的时间通常比实际视频时间晚1秒
    $date = date('Y-m-d', $timestamp / 1000 + 1);
    $storages = getMountedStorage();
    foreach ($storages as $storage) {
        $directory = "$storage/Recorder/Normal";
        $files = glob("$directory/$date-*.mp4");
        if ($files) {
            $mp4Files = array_merge($mp4Files, $files);
        }
    }
    arsort($mp4Files);

    $pattern = '/(\d{4}-\d{2}-\d{2})-(\d{2})-(\d{2})-(\d{2})/';
    foreach ($mp4Files as $file) {
        if (preg_match($pattern, $file, $matches)) {
            $datetime = $matches[1].' '.$matches[2].':'.$matches[3].':'.$matches[4];
            $startTime =  strtotime($datetime) * 1000 - 1000;
            if ($timestamp >= $startTime) {
                // 原车记录仪2分钟一个文件，时间差不应超过2分钟
                if (($timestamp - $startTime) < 120000) {
                    $videoFile = [
                        'key' => base64_encode($file),
                        'startTime' => $startTime,
                        'endTime' => filemtime($file) * 1000,
                        'storage' => 1
                    ];
                }
                break;
            }
        }
    }
    if ($videoFile) {
        $videoFile['snapshot_time'] = round(($timestamp - $videoFile['startTime']) / 1000);
    }
    return $videoFile;
}
?>