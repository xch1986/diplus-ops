<?php
// https://apifox.com/apidoc/shared-c3ce5ff5-754f-438c-aef2-055d85aa0391
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/image.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统！';
    returnJson($ajson);
}

/**
 * $type
 * 0 - 熄火哨兵
 * 1 - 全景记录仪
 * 2 - 原车行车记录仪
 * 3 - 迪加录屏
 * 4-* - 自定义文件夹
 */
$type = $_GET['type'] ?? '';
$key = @$_GET['key'] ?? '';
$step = @$_GET['step'] ?? 0;
$startTime = $_GET['startTime'] ?? 0;
if ($type == '' || !$step || !$startTime || !$key) {
	$ajson['message'] = '参数错误！';
    returnJson($ajson);
}
$dateStr = date('Ymd', round($startTime / 1000));
$currentFilePath = base64_decode($key);

// 迪加哨兵/全景记录仪
if ($type == 0 || $type == 1) {
    $conn = db_conn();
    $DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
    $data = getType01Files($type, $dateStr, $DIPLUS_AUTH);
    if (!$data) {
        $ajson['message'] = '获取当天的视频文件列表失败！';
        returnJson($ajson);
    }
    $index = arraySearch2D($data, 'key', $key);
    if ($index === false) {
        $ajson['message'] = '获取视频文件信息失败！';
        returnJson($ajson);
    }

    // 上一个就是数组后一个
    if ($step == -1) {
        if ($index < (count($data) - 1)) {
            $ajson['data'] = $data[$index + 1];
        } else { // 查找前一天的视频
            $preDateStr = date('Ymd', round($startTime / 1000) - 24 * 60 * 60);
            $data = getType01Files($type, $preDateStr, $DIPLUS_AUTH);
            if (!$data) {
                $ajson['message'] = '没有更早的视频了！';
                returnJson($ajson);
            }
            $ajson['data'] = $data[0];
        }

    } else { // $step == 1 下一个就是数组前一个
        if ($index > 0) {
            $ajson['data'] = $data[$index - 1];
        } else { // 查找后一天的视频
            $nextDateStr = date('Ymd', round($startTime / 1000) + 24 * 60 * 60);
            $data = getType01Files($type, $nextDateStr, $DIPLUS_AUTH);
            if (!$data) {
                $ajson['message'] = '没有更新的视频了！';
                returnJson($ajson);
            }
            $ajson['data'] = end($data);
        }
    }

    $url = "http://localhost:8988/api/videoInfo?key=".$ajson['data']['key']."&auth=".urlencode($DIPLUS_AUTH);
    $res = @file_get_contents($url, false, $context);
    $videoInfo = json_decode_x($res);
    if ($videoInfo) {
        $maxBrightness = readSettings($conn, 'global', 'video_brightness');
        if ($type == 0 && $maxBrightness && @$videoInfo['cover']) {
            $avgBrightness = getAverageBrightness($videoInfo['cover'], 'base64');
            if ($avgBrightness && $avgBrightness < $maxBrightness) {
                $adjustment = min($maxBrightness - $avgBrightness, 30);
                $ajson['data']['brightnessFactor'] = round(($avgBrightness + $adjustment) / $avgBrightness, 2);
            }
        }       

        $ajson['data']['coverMs'] = $videoInfo['coverMs'];
        if (isset($videoInfo['labels'])) {
            $events = getEvents($ajson['data']['startTime'], $videoInfo['labels']);
            $ajson['data']['events'] = $events;
        }
    }
    $ajson['success'] = 1;
    returnJson($ajson);
}


// $type == 2, 原车行车记录仪
if ($type == 2) {
    $date = date('Y-m-d', strtotime($dateStr));
    $videoFiles = getType2Files($date);
    $index = array_search($currentFilePath, $videoFiles);
    if ($index === false) {
        $ajson['message'] = '获取视频文件信息失败！';
        returnJson($ajson);
    }

    $foundFile = '';
    if ($step == -1) { // 上一个
        if ($index > 0 ) {
            $foundFile = $videoFiles[$index - 1];
        } else { // 查找前一天的视频
            $preDateStr = date('Y-m-d', round($startTime / 1000) - 24 * 60 * 60);
            $videoFiles = getType2Files($preDateStr);
            if (!$videoFiles) {
                $ajson['message'] = '没有更早的视频了！';
                returnJson($ajson);
            }
            $foundFile = end($videoFiles);
        }

    } else { // $step == 1 下一个
        if ($index < (count($videoFiles) - 1)) {
            $foundFile = $videoFiles[$index + 1];
        } else { // 查找后一天的视频
            $nextDateStr = date('Y-m-d', round($startTime / 1000) + 24 * 60 * 60);
            $videoFiles = getType2Files($nextDateStr);
            if (!$videoFiles) {
                $ajson['message'] = '没有更新的视频了！';
                returnJson($ajson);
            }
            $foundFile = $videoFiles[0];
        }
    }

    $ajson['data']['key'] = base64_encode($foundFile);
    $pattern = '/(\d{4}-\d{2}-\d{2})-(\d{2})-(\d{2})-(\d{2})/';
    if (preg_match($pattern, $foundFile, $matches)) {
        $datetime = $matches[1].' '.$matches[2].':'.$matches[3].':'.$matches[4];
        $startTime =  strtotime($datetime) * 1000 - 1000;
        $ajson['data']['startTime'] = $startTime;
        $ajson['data']['endTime'] = filemtime($foundFile) * 1000;
    }

    $ajson['success'] = 1;
    returnJson($ajson);
}


// $type == 3, 迪加录屏
if ($type == 3) {
    $videoFiles = getType3Files($dateStr);
    $index = array_search($currentFilePath, $videoFiles);
    if ($index === false) {
        $ajson['message'] = '获取视频文件信息失败！';
        returnJson($ajson);
    }

    $foundFile = '';
    if ($step == -1) { // 上一个
        if ($index > 0 ) {
            $foundFile = $videoFiles[$index - 1];
        } else { // 查找前一天的视频
            $preDateStr = date('Ymd', round($startTime / 1000) - 24 * 60 * 60);
            $videoFiles = getType3Files($preDateStr);
            if (!$videoFiles) {
                $ajson['message'] = '没有更早的视频了！';
                returnJson($ajson);
            }
            $foundFile = end($videoFiles);
        }

    } else { // $step == 1 下一个
        if ($index < (count($videoFiles) - 1)) {
            $foundFile = $videoFiles[$index + 1];
        } else { // 查找后一天的视频
            $nextDateStr = date('Ymd', round($startTime / 1000) + 24 * 60 * 60);
            $videoFiles = getType3Files($nextDateStr);
            if (!$videoFiles) {
                $ajson['message'] = '没有更新的视频了！';
                returnJson($ajson);
            }
            $foundFile = $videoFiles[0];
        }
    }

    $ajson['data']['key'] = base64_encode($foundFile);
    $pattern = '/\/(\d{13})_(\d{13})/';
    if (preg_match($pattern, $foundFile, $matches)) {
        $ajson['data']['startTime'] = (int)$matches[1];
        $ajson['data']['endTime'] = (int)$matches[2];
    }

    $ajson['success'] = 1;
    returnJson($ajson);
}


// $type == 4 自定义
// if ($type == 4) {
if (preg_match('/^4-(.+)/', $type, $matches)) {
    $directory = base64_decode($matches[1]);
    if (!is_dir($directory)) {
        returnJson($ajson);
    }

    $videoFiles = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory));
    foreach ($iterator as $file) {
        $ext = $file->getExtension();
        if ($file->isFile() && ($ext === 'mp4' || $ext === 'mkv')) {
            $pathname = $file->getPathname();
            $ctime = $file->getCTime();
            $videoFiles[$ctime] = $pathname;
        }
    }
    krsort($videoFiles);
    $videoFiles = array_values($videoFiles);
    $index = array_search($currentFilePath, $videoFiles);
    if ($index === false) {
        $ajson['message'] = '获取视频文件信息失败！';
        returnJson($ajson);
    }

    $foundFile = '';
    if ($step == -1) { // 上一个
        if ($index > 0 ) {
            $foundFile = $videoFiles[$index - 1];
        } else {
            $ajson['message'] = '没有更早的视频了！';
            returnJson($ajson);
        }
    } else { // $step == 1 下一个
        if ($index < (count($videoFiles) - 1)) {
            $foundFile = $videoFiles[$index + 1];
        } else {
            $ajson['message'] = '没有更新的视频了！';
            returnJson($ajson);
        }
    }

    $ajson['data']['key'] = base64_encode($foundFile);
    $ajson['data']['startTime'] = filectime($foundFile) * 1000;
    $ajson['data']['endTime'] = filemtime($foundFile) * 1000;
    $ajson['success'] = 1;
    returnJson($ajson);
}


$ajson['message'] = '获取视频文件失败！';
returnJson($ajson);



// 查找某一天的迪加哨兵或行车记录仪视频文件
// 返回的文件列表是按时间倒序排列的
function getType01Files($type, $dateStr, $DIPLUS_AUTH) {
    $url = "http://localhost:8988/api/videoFiles?type=$type&dir=$dateStr&auth=".urlencode($DIPLUS_AUTH);
    $context = stream_context_create([
        'http' => [
            'timeout' => 5
        ]
    ]);
    $res = @file_get_contents($url, false, $context);
    if (!$res) {
        return [];
    }
    return json_decode_x($res); 
}

// 查找某一天的原车记录仪视频文件
function getType2Files($date) {
    $data = [];
    $pattern = '/(\d{4}-\d{2}-\d{2})-(\d{2})-(\d{2})-(\d{2})/';
    $storages = getMountedStorage();
    foreach ($storages as $storage) {
        $files = glob("$storage/Recorder/Normal/$date-*.mp4");
        if ($files) {
            $data = array_merge($data, $files);
        }
    }
    if (!$data) return [];
    foreach ($data as $k => $file) {
        if (!preg_match($pattern, $file)) {
            unset($data[$k]);
        }
    }
    $data = array_values($data);
    asort($data);
    return $data;
}


// 查找某一天的迪加录屏视频文件
function getType3Files($dateStr) {
    $data = [];
    $pattern = '/\/(\d{13})_(\d{13})/';
    $storages = getMountedStorage();
    foreach ($storages as $storage) {
        $files = glob("$storage/AlarmVideo/S/$dateStr/*.mp4");
        if ($files) {
            $data = array_merge($data, $files);
        }
    }
    if (!$data) return [];
    foreach ($data as $k => $file) {
        if (!preg_match($pattern, $file)) {
            unset($data[$k]);
        }
    }
    $data = array_values($data);
    asort($data);
    return $data;
}
?>