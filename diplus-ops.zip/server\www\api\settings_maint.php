<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$action = $_GET['action'] ?? '';
$date = $_GET['date'] ?? '';
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统';
    returnJson($ajson);
}
if ($action == 'getTripInfo' && !$date) {
    $ajson['message'] = '参数错误!';
    returnJson($ajson);    
}


if ($action == 'getTripInfo') {
    $dbPath = '/data/data/com.termux/files/home/db/van_bm_db';
    $conn2 = db_conn($err, $dbPath);
    if (!$conn2) {
        $ajson['message'] = "获取里程信息失败！$err";
        returnJson($ajson);      
    }
    $p = [];
    $p[':date'] = date('Y-m-d', strtotime($date));
    $sql = "SELECT mileage_end / 10.0 AS mileage, evMileage_end / 10.0 AS evMileage
        FROM TripInfo
        WHERE date(time_end / 1000, 'unixepoch', 'localtime') = :date
        LIMIT 1
    ";
    $row = db_query_row($conn2, $sql, $p);
    $conn2 = null;
    if (!$row) {
        $ajson['message'] = '获取里程信息失败！没有当天的行程记录。';
        returnJson($ajson); 
    }
    $ajson['data'] = $row;
    $ajson['success'] = 1;
    returnJson($ajson);
}


$conn = db_conn();
$post = json_decode_x(file_get_contents('php://input'));
if ($post) {
    $maint = $post;
    $old = json_decode_x(readSettings($conn, 'global', 'maint'));
    // 最近保养日期、里程有变化，清除已发送提醒标识
    if (@$maint['lastest_date'] != @$old['lastest_date'] || @$maint['lastest_mileage'] != @$old['lastest_mileage']) {
        $maint['noti_sent'] = '';
    }
    writeSettings($conn, 'global', 'maint', json_encode_x($maint));
	$ajson['message'] = '数据保存成功！';
    $ajson['success'] = 1;
    returnJson($ajson);
}

$returnData = [];
$returnData = json_decode_x(readSettings($conn, 'global', 'maint'));
if (!$returnData) {
    $returnData = [
        'month_interval' => 12,
        'mileage_interval' => 20000,
    ];
}

$ajson['data'] = $returnData;
$ajson['success'] = 1;
returnJson($ajson);
?>