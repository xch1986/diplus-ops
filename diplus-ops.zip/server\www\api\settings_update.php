<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';
require_once '../includes/sse.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$action = $_GET['action'] ?? 'getData';
$login = login(false);
if (!$login) {
    if ($action == 'update') {
        sse(-1, '未登录系统');
        exit;
    } else {
        $ajson['message'] = '未登录系统';
        returnJson($ajson);
    }
}

$conn = db_conn();
set_time_limit(600);

// 添加环境变量，否则command -v xxx 等命令不能返回正确结果
putenv('PATH=/data/data/com.termux/files/usr/bin:' . getenv('PATH'));
$home = $_ENV['HOME'];

// 更新termux系统软件包
if ($action == 'upgradePackages') {
    exec('pkg upgrade -y 2>&1', $output);
    $msg = implode('<br/>', $output);
    $ajson['msg'] = $msg;
    if (strpos($msg, 'All packages are up to date') !== false) {
        $ajson['success'] = 1;
        $ajson['message'] = '没有需要更新的软件包！';
    } else {
        $patten = "/(\d+) upgraded.*(\d+) not upgraded/i";
        if (preg_match($patten, $msg, $m)) {
            $ajson['message'] = "已更新: {$m[1]}, 未更新: {$m[2]}";
            $ajson['success'] = $m[2] == 0;
        } else {
            $ajson['message'] = "更新失败！";
        }
    }
    returnJson($ajson);
}


$update_url = 'https://raw.gitcode.com/qq_43458985/diplus-www/raw/main/update.txt';
$str = trim(@file_get_contents($update_url));
if (!$str) {
    if ($action == 'getData') {
        $ajson['message'] = '获取更新信息失败！请检查网络连接。';
        returnJson($ajson);
    } else {
        $sseData['msg'] = '获取更新信息失败！请检查网络连接。';
        sse(-2, $sseData);
        exit;
    }
}
list($latest_version, $latest_update) = explode("\n", $str, 2);

if ($action == 'getData') {
    $returnData = [];
    $returnData['latest_version'] = $latest_version;
    $returnData['latest_update'] = $latest_update;
    $ajson['data'] = $returnData;
    $ajson['success'] = 1;
    returnJson($ajson);
}


if ($action == 'update') {
    $install_url = 'https://raw.gitcode.com/qq_43458985/diplus-www/raw/main/scripts/install.sh';
    $sseData['msg'] = '下载安装脚本 ...';
    sse(3, $sseData);
    $install_file = "$home/install.sh";
    if (file_exists($install_file)) {
        unlink($install_file);
    }
    file_put_contents($install_file, @file_get_contents($install_url));
    if (!file_exists($install_file)) {
        $sseData['msg'] = "下载安装脚本失败，系统未更新！";
        sse(-3, $sseData);
        exit;
    }

    $tar_url = 'https://raw.gitcode.com/qq_43458985/diplus-www/raw/main/tars/home.tar';
    $sseData = [
        'msg' => '',
        'progress' => ''
    ];
    $sseData['msg'] = '下载更新压缩包 ...';
    sse(4, $sseData);
    $path = "$home/home.tar";
    if (file_exists($path)) {
        unlink($path);
    }
    $fp = fopen($path, 'w+');
    $ch = curl_init($tar_url);
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // 启用重定向
    curl_setopt($ch, CURLOPT_NOPROGRESS, false);
    curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, function($resource, $download_size, $downloaded) {
        if ($download_size > 0) {
            $progress = intval(($downloaded / $download_size) * 100);
            $sseData['msg'] = "下载进度 {$progress}%";
            $sseData['progress'] = $progress;
            sse(4, $sseData);
        }
    });

    // 开始下载
    $result = curl_exec($ch);
    if ($result === false || !file_exists($path)) {
        $sseData['msg'] = "下载失败: " . curl_error($ch);
        sse(-5, $sseData);
        curl_close($ch);
        fclose($fp);
        exit;
    }
    curl_close($ch);
    fclose($fp);

    if (!file_exists($path)) {
        $sseData['msg'] = "下载压缩包失败，系统未更新!";
        sse(-5, $sseData);
        exit;
    }

    $sseData['msg'] = "压缩包下载成功，正在更新系统 ...";
    sse(6, $sseData);

    exec(`bash $install_file --do update`, $output, $return);

    $version = readSettings($conn, 'global', 'version');
    if ($version != $latest_version) {
        // 安装输出保存至日志。
        $errInfo = date('Y-m-d H:i:s')."\n".implode("\n", $output);
        file_put_contents("$home/system_update_log.txt", $errInfo);
        $sseData['msg'] = "系统更新失败！详情: ~/system_update_log.txt";
        sse(-8, $sseData);
        exit; 
    }

    $sseData['msg'] = "系统已更新至 {$latest_version}，正在重启Termux，请稍后刷新页面查看系统信息。";
    sse(999, $sseData);
    restart_termux();
    exit;
}
?>