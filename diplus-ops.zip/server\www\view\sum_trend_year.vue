<script>
export default {
    // 定义name包含keep-alive，离开本页面再次返回时不刷新页面
    // 只在onActivated中更新数据
    name: 'sum_monthlyTrip_keep-alive'
}
</script>
<script setup>
import echarts from '/includes/vue-components/echarts.vue';
import elSelectX from '/includes/vue-components/el-select-x.vue';

const router = VueRouter.useRouter();
const route = VueRouter.useRoute();
const data = Vue.ref([]);
const formData = Vue.ref({
    date: new Date(route.query.date ?? new Date().Format('YYYY-01-01')),
    params: []
});
let str = route.query.params;
if (str) {
    formData.value.params = typeof str === 'string' ? [str] : str;
} else {
    str = localStorage.getItem('sum_trend_year.params');
    formData.value.params = str ? JSON.parse(str) : [];
}
const options = Vue.ref({});
const isMobile = Vue.ref(window.innerWidth < 550);

const getData = async () => {
    const res = await axios({
        url: 'api/sum_trend_year.php',
        method: 'get',
        params: {
            date: formData.value.date.Format('YYYY'),
            params: formData.value.params
        }
    });

    if (res.data.success < 1) {
        ElementPlus.ElMessage.error(res.data.message);
        if (res.data.success == -1) {
            gotoLogin();
        }
        return;
    }
    data.value = res.data.data;
    options.value = res.data.options;
    localStorage.setItem('sum_trend_year.params', JSON.stringify(formData.value.params));
}
const paramOptions = Vue.computed(() => {
    return options.value?.params?.length ? options.value.params.map(row => row.label) : [];
});

const setYear = (val) => {
    if (val === 0) {
        formData.value.date = new Date();
    } else {
        // 直接setFullYear修改不会触发watch，这里转一下再赋值
        const d = new Date(formData.value.date.toDateString());
        d.setFullYear(d.getFullYear() + val);
        formData.value.date = d;
    }
}

// 只有keep-alive的页面生命周期中有onActivated
Vue.onActivated(() => {
    getData();
});

Vue.watch(formData.value, () => {
    getData();
});

const chart_option = Vue.computed(() => {
	if (!data.value?.length || !options.value?.params?.length) return {};
    let chartData = {
        demensions:  [ { name: 'date', type: 'time' } ],
        series: []
    };
    for (let p of options.value.params) {
        if (formData.value.params.includes(p.label)) {
            chartData.demensions.push(p.value);
            chartData.series.push({
                name: p.label,
                type: 'line',
                encode: { x: 'date', y: p.value }
            });
        }
    }
    return {
		legend: {},
		grid: {
			left: '0',
			right: '0',
			containLabel: true
		},
		tooltip : { trigger: 'axis' },
		dataset: {
            source: data.value,
            dimensions: chartData.demensions
		},
        xAxis: {
            type: 'time',
            axisLabel: {
                formatter: function(value, index) {
                    return new Date(value).Format("MM-DD");
                }
            }
        },
		yAxis: {
			type: 'value',
		},
		series: chartData.series,
        dataZoom: [
            {
                type: 'slider', // slider 型 dataZoom 组件
                start: 0,
                end: 100
            },
            {
                type: 'inside', // inside 型支持鼠标缩放
                start: 0,
                end: 100
            }
        ],
	};
});

const onClickChart = async (params) => {
    router.push({
        path: '/trendDay',
        query: {
            date: params.date,
            params: formData.value.params
        }
    });
};
</script>

<template>
    <div class="tab-head">
        <el-space size="large" class="tab-head-left">
            <div class="tab-head-title">一年趋势</div>
        </el-space>
        <el-space size="large">
            <el-button type="primary" plain @click="setYear(-1)"><</el-button>
            <el-date-picker v-model="formData.date" type="year" :editable="false" style="width: 120px" format="YYYY年"/>
            <el-button type="primary" plain @click="setYear(1)">></el-button>
        </el-space>
    </div>
    <Teleport to=".tab-head-left" :disabled="isMobile">
        <el-select-x
            v-model="formData.params"
            :options="paramOptions"
            multiple placeholder="请选择要显示的数据"
            style="min-width: 200px"
        />
    </Teleport>

	<div class="slide">
		<echarts :option="chart_option" :on="{ event: 'click', callback: onClickChart }"/>
	</div>

</template>

<style scoped>
.echarts {
    min-width: 600px;
    height: 600px !important;
    padding: 30px 0 60px 0;
}
@media screen and (max-height: 800px) {
    .echarts {
        height: 400px !important;
    }
}
</style>