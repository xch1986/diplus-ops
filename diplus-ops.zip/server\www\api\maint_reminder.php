<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once __DIR__.'/../includes/phpshare.php';
require_once __DIR__.'/../includes/db.php';
require_once __DIR__.'/../includes/wechat.php';
require_once __DIR__.'/../includes/dingding.php';
// phph直接运行此脚本必须设置时区
date_default_timezone_set('Asia/Shanghai');

$ajson = [ 'success' => 0, 'message' => '' ];

$conn = db_conn();
$msgTo = readSettings($conn, 'global', 'msgTo');
if (!in_array($msgTo, ['wechat', 'dingding'])) {
  	$ajson['message'] = "发送提醒失败！未启用接收信息。";
	returnJson($ajson);
}

$maint = json_decode_x(readSettings($conn, 'global', 'maint'));
if (!@$maint['send_maint_noti']
    || (!@$maint['month_interval'] || !@$maint['lastest_date']) && (!@$maint['mileage_interval'] || !@$maint['lastest_mileage'])
) {
    $ajson['message'] = "未启用保养提醒或设置不正确。";
	returnJson($ajson);
}

if (@$maint['noti_sent']) {
    $ajson['message'] = "本次保养提醒已于".$maint['noti_sent']."发送过，不再重复发送。";
	returnJson($ajson);
}

$content = '';
if (@$maint['month_interval'] && @$maint['lastest_date']) {
    $month_interval = $maint['month_interval'];
    $lastest_date = $maint['lastest_date'];
    $next_time = strtotime("+$month_interval months", strtotime($lastest_date));
    $next_date = date('Y-m-d', $next_time);
    if (($next_time - time()) < (3600 * 24 * 10)) {
        $content .= "请在 $next_date 前完成保养，完成保养后请到系统内确认并输入最近保养日期。";
    }
}

if (@$maint['mileage_interval'] && @$maint['lastest_mileage']) {
    $next_mileage = round($maint['lastest_mileage'] + $maint['mileage_interval']);
    $dbPath = '/data/data/com.termux/files/home/db/van_bm_db';
    $conn2 = db_conn($err, $dbPath);
    $sql = "SELECT mileage_end / 10.0 AS mileage FROM TripInfo ORDER BY time_end DESC LIMIT 1";
    $row = db_query_row($conn2, $sql);
    if ($row && ($next_mileage - $row['mileage']) < 100) {
        $mileage = (int)$row['mileage'];
        $content .= "请在总里程 $next_mileage 之前完成保养，当前里程 {$mileage}，完成保养后请到系统内确认并输入最近保养日期和里程数。";
    }
}

if (!$content) {
    $ajson['message'] = "没有需要发送的提醒。";
	returnJson($ajson);    
}

$serverIp = readSettings($conn, 'global', 'serverIp');
$jumpUrl = "$serverIp/settings.html#/maint";

if ($msgTo == 'wechat') {
	$WECHAT_MSG = readSettings($conn, 'global', 'WECHAT_MSG');
    $msgData = [
		"msgtype" => "news",
		"news" => [
			"articles" => [
				[
					"title" => '比亚迪-保养提醒',
					"description" => $content,
					"url" => $jumpUrl,
				]
			]
		]
	];
	$ret = sendToWechatGroup($WECHAT_MSG, $msgData);
	if ($ret !== true) {
		$ajson['message'] = "发送保养提醒失败！$ret";
		returnJson($ajson);
	}
	$ajson['success'] = 1;
}

if ($msgTo == 'dingding') {
	$content = str_replace("\n", "\n\n", $content);
	$DINGDING_MSG = readSettings($conn, 'global', 'DINGDING_MSG');
	$DINGDING_MSG_SECRET = readSettings($conn, 'global', 'DINGDING_MSG_SECRET');
    $msgData = [
        "msgtype" => "link", 
        "link" => [
            "text" => $content, 
            "title" => '比亚迪-保养提醒', 
            "messageUrl" => $jumpUrl
        ]
    ];
	$ret = sendToDingdingGroup($DINGDING_MSG, $DINGDING_MSG_SECRET, $msgData);
	if ($ret !== true) {
		$ajson['message'] = "发送保养提醒失败！$ret";
		returnJson($ajson);
	}
	$ajson['success'] = 1;
}

if ($ajson['success']) {
	$ajson['message'] = "保养提醒发送成功！";
	$maint['noti_sent'] = date('Y-m-d');
	writeSettings($conn, 'global', 'maint', json_encode_x($maint));
} else {
	$ajson['message'] .= "未发送任何信息！";
}
returnJson($ajson);
?>
