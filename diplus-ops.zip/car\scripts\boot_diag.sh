#!/system/bin/sh
LOG=/data/data/com.termux/files/home/boot_diag.log
{
  echo "===== boot_diag $(date '+%Y-%m-%d %H:%M:%S') ====="
  echo "uptime: $(cat /proc/uptime 2>/dev/null | cut -d' ' -f1)"
  echo "termux_enabled: $(dumpsys package com.termux 2>/dev/null | grep -oE 'enabled=[0-9]' | head -1)"
  echo "dija_enabled: $(dumpsys package com.van.diplus 2>/dev/null | grep -oE 'enabled=[0-9]' | head -1)"
  echo "gateway_ping: $(ping -c 1 -W 2 192.168.43.1 >/dev/null 2>&1 && echo OK || echo FAIL)"
  echo "wifi_ip: $(ip addr show wlan0 2>/dev/null | grep -oE 'inet [0-9.]+' | head -1)"
  echo "emulated0: $(ls /storage/emulated/0/vandiplus >/dev/null 2>&1 && echo OK || echo MISSING)"
  echo "sd_mount: $(ls /storage/85D5-14FD >/dev/null 2>&1 && echo OK || echo MISSING)"
  echo "selinux: $(getenforce 2>/dev/null)"
  echo "sdcard_proc: $(ps -A 2>/dev/null | grep -c sdcard)"
  for P in 8018 5244 16601 8988; do
    echo "port_$P: $(curl -s -o /dev/null -w %{http_code} --max-time 3 http://127.0.0.1:$P/ 2>/dev/null)"
  done
  echo "===== end ====="
} >> $LOG 2>&1
