# 运维指南（脱敏版）

> 原始上下文含真实账号/密码/隧道地址，仅存于本机私有文档，不入库。
> 以下为通用运维操作与故障排查方法，所有示例凭据均为占位符。

## 1. 远程操作车机

### 通道一：UFI 设备（推荐，双保险）

车机连 UFI 热点，UFI 上运行 UFI-TOOLS（第三方项目 [kanoqwq/UFI-TOOLS](https://github.com/kanoqwq/UFI-TOOLS)）提供 Web 控制台，内置 root shell 与 adb：

```
浏览器 → UFI-TOOLS 控制台（口令登录）
页内 fetch POST /api/root_shell
  headers: Content-Type: application/json + Authorization=<会话token>
  body: {"command":"...","timeout_ms":...}
```

adb 通道（UFI 上执行）：

```bash
export HOME=/data/local/tmp
export ANDROID_ADB_LOG_PATH=/data/local/tmp/adb.0.log
ADB=/data/data/com.minikano.f50_sms/files/adb
C=<车机IP>:5555
$ADB connect $C
$ADB -s $C shell "echo <base64> | base64 -d | su -c sh"
```

> 深嵌套引号易 500：命令先 base64 再 decode 执行。每条 adb 命令加 `< /dev/null`。

### 通道二：SSH

```
ssh -p <frp映射的ssh端口> root@<frps地址>
```

### 通道三：OpenList 文件管理

```
http://<frps地址>:<openlist映射端口>/
```

## 2. 关键路径速查

| 项目 | 路径 |
|---|---|
| Magisk 模块 | `/data/adb/modules/diplus-keepalive/` |
| daemon 日志 | `/data/data/com.termux/files/home/daemon.log` |
| 开机自检日志 | `/data/data/com.termux/files/home/boot_diag.log` |
| frp 配置/日志 | `/data/data/com.termux/files/home/frp/frpc.{toml,log,pid}` |
| Web 根目录 | `/data/data/com.termux/files/home/www/` |
| nginx 配置 | `/data/data/com.termux/files/home/nginx/nginx.conf` |
| php-fpm 配置 | `/data/data/com.termux/files/usr/etc/php-fpm.conf` |
| SQLite 数据库 | `/data/data/com.termux/files/home/db/db.db` |
| crontab | `/data/data/com.termux/files/usr/var/spool/cron/crontabs/root` |
| 迪加配置 | `/storage/emulated/0/vandiplus/` |
| daemon/诊断 PID | `/data/local/tmp/diplus-daemon.pid`、`/data/local/tmp/boot_diag.sh` |

## 3. 常见故障排查

### 3.1 服务失联（外网打不开）

```bash
# 1) 检查 daemon 是否在跑
ps -A | grep diplus-daemon
# 2) 检查本机端口
for P in 8018 5244 16601 8988; do curl -s -o /dev/null -w "$P:%{http_code} " --max-time 3 http://127.0.0.1:$P/; done; echo
# 3) 手动拉起
sh /data/local/tmp/start_daemon.sh
# 4) 查日志
tail -50 /data/data/com.termux/files/home/daemon.log
```

### 3.2 Termux 被系统禁用（历史失联根因）

```bash
dumpsys package com.termux | grep -E 'enabled='
pm enable com.termux
```

### 3.3 内部存储 emulated 视图损坏（哨兵目录消失）

daemon v5.3 已内置 fuse 自愈 v3：开机 240s 宽限 → SELinux 放行 → `sm mount emulated` → bind 完整视图（120s 冷却）。
手动干预：

```bash
setenforce 0                          # 临时放行 SELinux
sm unmount emulated; sleep 2; sm mount emulated
ls /storage/emulated/0/vandiplus/     # 验证
```

> ⚠️ 切勿 `stop/start vold`——会打断内部存储并可能致中控黑屏（历史教训）。

### 3.4 SD/记录仪未挂载（哨兵视频缺失）

```bash
ls /storage/85D5-14FD                 # SD 挂载点（按实际）
# USB host 模式重上电
echo host > /sys/devices/platform/soc/4e00000.ssusb/mode
# USB/SCSI 重扫
for h in /sys/class/scsi_host/host*; do echo "- - -" > $h/scan; done
```

> 不重启 vold（同上原因）；daemon 已内置 300s 冷却的自动恢复。

### 3.5 迪加 8988 数据口静默

```bash
pm enable com.van.diplus
am startservice -n com.van.diplus/.service.MainService
am startservice -n com.van.diplus/.service.SignedLogicHostService
```

daemon v5.3 已内置（300s 冷却自动恢复）。

### 3.6 frp 公网 IP 变更

frps 域名解析变化后，`frpc.toml` 注释里的公网 IP 可能过时。用域名解析结果访问：

```bash
nslookup <frps域名>
# 用解析出的 IP 访问映射端口
```

## 4. 防复发机制（为什么这版不再失联）

| 失联根因 | 对策 |
|---|---|
| Termux 被禁用(enable=0) | service.sh 开机 `pm enable com.termux` |
| 进程被杀 | watchdog/daemon `oom_score_adj=-1000` + `nice -20` 抗杀 |
| daemon 意外死亡 | watchdog 60s 拉起 + crontab 每分钟兜底 |
| php-fpm 502 | daemon 502 探测 → 重建 |
| 内部存储视图损坏 | fuse 自愈 v3（SELinux 放行 + sm mount + bind） |
| SD/USB hub 掉电 | USB host 重上电 + USB/SCSI 重扫（不重启 vold） |
| 下电后不恢复 | 开机宽限 240s 内不碰存储，避免干扰启动致黑屏 |
| 迪加 app 被杀 | 8988 探测 → 恢复 app 服务 |

## 5. 用户铁律（运维习惯）

- 只改点名范围，重要改动先备份（`.bak` 后缀）
- 不碰 frpc.toml / lucky 等敏感配置的真实值
- 不做危险 root 折腾；车机无刷机包，无恢复手段
- 主动测试验证，别光问；改完必须说明
