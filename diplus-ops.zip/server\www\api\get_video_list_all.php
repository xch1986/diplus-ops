<?php
// https://apifox.com/apidoc/shared-c3ce5ff5-754f-438c-aef2-055d85aa0391
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/share.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '未登录系统！';
    returnJson($ajson);
}

$dateStr = $_GET["dateStr"] ?? '';
$type = $_GET['type'] ?? 0;
if (!$dateStr) {
	$ajson['message'] = '参数错误！';
    returnJson($ajson);
}

/**
 * $type
 * 0 - 熄火哨兵
 * 1 - 全景记录仪
 * 2 - 原车行车记录仪
 * 3 - 迪加录屏
 * 4-* - 自定义文件夹
 */

if ($type == 0 || $type == 1) {
    $conn = db_conn();
    $DIPLUS_AUTH = readSettings($conn, 'global', 'DIPLUS_AUTH');
    $conn = null;
    $url = "http://localhost:8988/api/videoFiles?type=$type&dir=$dateStr&auth=".urlencode($DIPLUS_AUTH);
    $context = stream_context_create([
        'http' => [
            'timeout' => 5
        ]
    ]);
    $res = @file_get_contents($url, false, $context);
    if (!$res) {
        $ajson['message'] = '读取文件列表失败！';
        returnJson($ajson);
    }
    // 返回的文件列表是按时间倒序排列的
    $data = json_decode_x($res);
    if (!$data) {
        $ajson['message'] = '读取文件列表失败！';
        returnJson($ajson);    
    }
    $ajson['data'] = $data;
    $ajson['success'] = 1;
    returnJson($ajson);
}


// $type == 2, 原车行车记录仪
if ($type == 2) {
    $mp4Files = [];
    $date = date('Y-m-d', strtotime($dateStr));
    $storages = getMountedStorage();
    foreach ($storages as $storage) {
        $directory = "$storage/Recorder/Normal";
        $files = glob("$directory/$date-*.mp4");
        if ($files) {
            $mp4Files = array_merge($mp4Files, $files);
        }
    }
    arsort($mp4Files);

    $data = [];
    $pattern = '/(\d{4}-\d{2}-\d{2})-(\d{2})-(\d{2})-(\d{2})/';
    foreach ($mp4Files as $file) {
        if (preg_match($pattern, $file, $matches)) {
            $row = [
                'storage' => 1,
                'key' => base64_encode($file)
            ];
            $time = $matches[1].' '.$matches[2].':'.$matches[3].':'.$matches[4];
            $row['startTime'] = strtotime($time) * 1000;
            $row['endTime'] = filemtime($file) * 1000;
            $data[] = $row;
        }
    }
    $ajson['data'] = $data;
    $ajson['success'] = 1;
    returnJson($ajson);
}


// $type == 3, 迪加录屏
if ($type == 3) {
    $mp4Files = [];
    $storages = getMountedStorage();
    foreach ($storages as $storage) {
        $directory = "$storage/AlarmVideo/S/$dateStr";
        $files = glob("$directory/*.mp4");
        if ($files) {
            $mp4Files = array_merge($mp4Files, $files);
        }
    }
    arsort($mp4Files);

    $data = [];
    $pattern = '/\/(\d{13})_(\d{13})/';
    foreach ($mp4Files as $file) {
        if (preg_match($pattern, $file, $matches)) {
            $storage = 0;
            if (strpos($file, '/usb') !== false) {
                $storage = 3;
            }
            $row = [
                'storage' => $storage,
                'key' => base64_encode($file)
            ];
            $row['startTime'] = $matches[1] * 1;
            $row['endTime'] = $matches[2] * 1;
            $data[] = $row;
        }
    }
    $ajson['data'] = $data;
    $ajson['success'] = 1;
    returnJson($ajson);
}


// $type == 4 自定义
// if ($type == 4) {
if (preg_match('/^4-(.+)/', $type, $matches)) {
    $directory = base64_decode($matches[1]);
    if (!is_dir($directory)) {
        returnJson($ajson);
    }

    $data = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory));
    foreach ($iterator as $file) {
        $ext = $file->getExtension();
        if ($file->isFile() && ($ext === 'mp4' || $ext === 'mkv')) {
            $pathname = $file->getPathname();
            $ctime = $file->getCTime();
            $date = date("Ymd", $ctime);
            if ($date == $dateStr) {
                $data[$ctime] = [
                    'storage' => 1,
                    'key' => base64_encode($pathname),
                    'startTime' => $ctime * 1000
                ];
            }
        }
    }
    krsort($data);
    $ajson['data'] = array_values($data);
    $ajson['success'] = 1;
    returnJson($ajson);
}


$ajson['message'] = '获取视频文件失败！';
returnJson($ajson);
?>