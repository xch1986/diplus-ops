<?php
header('Content-Type: text/plain');
$p = "/storage/85D5-14FD/Recorder/Normal/A/20260907/1788748234752_1788748299892.0_0_0_23.mp4";
echo "readable: "; var_dump(is_readable($p));
echo "file: "; var_dump(is_file($p));
echo "uid: " . (function_exists('posix_getuid') ? posix_getuid() : 'na') . "\n";
echo "realpath: "; var_dump(realpath($p));
$h = @fopen($p, 'rb');
echo "fopen: "; var_dump($h !== false);
if ($h) { echo "first16: " . bin2hex(fread($h, 16)) . "\n"; fclose($h); }
$ctx = @file_get_contents('/proc/self/attr/current');
echo "ctx: " . $ctx . "\n";
$t = @file_get_contents('/proc/self/status');
$t = preg_replace('/^.*?(Uid:.*?\n).*$/s', '$1', $t);
echo $t;
