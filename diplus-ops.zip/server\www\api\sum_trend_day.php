<?php
header('Content-type: application/json; charset=utf-8');
header("Cache-Control: no-cache");
require_once '../includes/phpshare.php';
require_once '../includes/db.php';

$ajson = ['success' => 0, 'message' => '', 'data' => [], 'options' => []];
$login = login(false);
if (!$login) {
    $ajson['success'] = -1;
    $ajson['message'] = '获取车况数据失败！未登录系统。';
    returnJson($ajson);
}
$date = @$_GET["date"] ?? date('Y-m-d');
$params = @$_GET['params'] ?: [];

$conn = db_conn();
$diplus_params = json_decode_x(readSettings($conn, 'diplus', 'diplus_params'));

$dbPath = '/storage/emulated/0/Termux/db.db';
$conn1 = db_conn($err, $dbPath);
if (!$conn1) {
    $ajson['message'] = "打开数据库失败！$err";
    returnJson($ajson);
}

$options['params'] = [
    [ 'label' => '里程', 'value' => 'mileage' ],
    [ 'label' => '车速', 'value' => 'speed' ],
    [ 'label' => '刹车深度', 'value' => 'brake_depth' ],
    [ 'label' => '加速踏板深度', 'value' => 'accelerator_depth' ],
    [ 'label' => '左前轮气压', 'value' => 'tire_pressure_fl' ],
    [ 'label' => '右前轮气压', 'value' => 'tire_pressure_fr' ],
    [ 'label' => '左后轮气压', 'value' => 'tire_pressure_rl' ],
    [ 'label' => '右后轮气压', 'value' => 'tire_pressure_rr' ],
    [ 'label' => '总电耗', 'value' => 'total_power_consumption' ],
    [ 'label' => '电量百分比', 'value' => 'battery_percent' ],
    [ 'label' => '总燃油消耗', 'value' => 'total_fuel_consumption' ],
    [ 'label' => '油量百分比', 'value' => 'fuel_percent' ],
];
$paramNames = array_column($options['params'], 'label');

// 添加自定义参数中需要保存的参数
foreach ($diplus_params as $param) {
    if ($param['dataType'] == 'number' && @$param['save'] && !in_array($param['name'], $paramNames)) {
        $options['params'][] = [
            'label' => $param['name'],
            'value' => $param['name']
        ];
    }
}
$ajson['options'] = $options;

if ($params) {
    $p[':date'] = $date;
    $aFields = [
        "strftime('%Y-%m-%d %H:%M:%S', timestamp / 1000, 'unixepoch', 'localtime') AS date",
        'location'
    ];
    foreach ($params as $param) {
        switch ($param) {
            case '里程':
                $aFields[] = "mileage / 10 AS mileage";
                break;
            case '车速':
                $aFields[] = "speed";
                break;
            case '刹车深度':
                $aFields[] = "brake_depth";
                break;
            case '加速踏板深度':
                $aFields[] = "accelerator_depth";
                break;
            case '左前轮气压':
                $aFields[] = "tire_pressure_fl";
                break;
            case '右前轮气压':
                $aFields[] = "tire_pressure_fr";
                break;
            case '左后轮气压':
                $aFields[] = "tire_pressure_rl";
                break;
            case '右后轮气压':
                $aFields[] = "tire_pressure_rr";
                break;
            case '总电耗':
                $aFields[] = "total_power_consumption";
                break;
            case '电量百分比':
                $aFields[] = "battery_percent";
                break;
            case '总燃油消耗':
                $aFields[] = "total_fuel_consumption";
                break;
            case '油量百分比':
                $aFields[] = "fuel_percent";
                break;
            default:
                $aFields[] = "CAST(json_extract(custom, '$.\"$param\"') AS REAL) AS $param";
        }
    }
    $strFields = implode(', ', $aFields);
    $sql = "SELECT $strFields FROM driving_data
        WHERE strftime('%Y-%m-%d', timestamp / 1000, 'unixepoch', 'localtime') = :date
    ";
    $data = db_query_all($conn1, $sql, $p);
    if (!$data) {
        $ajson['message'] = '获取车况数据失败！';
        returnJson($ajson);    
    }
    foreach ($data as &$row) {
        $row['location'] = json_decode_x($row['location']);
    }
    unset($row);
    $ajson['data'] = $data;
}

$ajson['success'] = 1;
$ajson['message'] = '车况数据获取成功！';
returnJson($ajson);
?>