#!/bin/bash
# lucky 自启 (内含 FileBrowser 文件浏览)
LOG=/data/data/com.termux/files/home/lucky_boot.log
home="/data/data/com.termux/files/home"
tmpd="/data/data/com.termux/files/usr/tmp"
if [ ! -f "$home/lucky/lucky" ]; then
    echo "$(date) binary missing" >> $LOG
    exit
fi
if /data/data/com.termux/files/usr/bin/pgrep -f "lucky -cd" > /dev/null; then
    echo "$(date) already running, skip" >> $LOG
    exit
fi
rm -f "$tmpd/lucky.control.sock" "$tmpd/lucky.control.token" "$tmpd/lucky.run.msg"
/data/data/com.termux/files/usr/bin/nohup /data/data/com.termux/files/usr/bin/env TMPDIR=$tmpd LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib PATH=/data/data/com.termux/files/usr/bin HOME=/data/data/com.termux/files/home PREFIX=/data/data/com.termux/files/usr $home/lucky/lucky -cd $home/lucky > /dev/null 2>&1 &
sleep 2
if /data/data/com.termux/files/usr/bin/pgrep -f "lucky -cd" > /dev/null; then
    echo "$(date) started OK" >> $LOG
else
    echo "$(date) start FAILED" >> $LOG
fi
